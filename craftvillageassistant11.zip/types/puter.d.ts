interface PuterAI {
  chat: (prompt: string, options?: any) => Promise<any>
  txt2img: (prompt: string) => Promise<HTMLImageElement>
  img2txt: (imageUrl: string) => Promise<string>
  txt2speech: (text: string, language?: string) => Promise<HTMLAudioElement>
}

interface PuterFS {
  write: (path: string, content: string) => Promise<any>
  read: (path: string) => Promise<Blob>
  upload: (files: FileList | File[]) => Promise<any>
}

interface PuterKV {
  set: (key: string, value: string) => Promise<void>
  get: (key: string) => Promise<string | null>
  del: (key: string) => Promise<void>
  list: (pattern: string, withValues?: boolean) => Promise<any>
  incr: (key: string, by?: number) => Promise<number>
}

interface PuterAuth {
  signIn: () => Promise<void>
  signOut: () => Promise<void>
  isSignedIn: () => boolean
  getUser: () => Promise<{ username: string; [key: string]: any }>
}

interface Puter {
  ai: PuterAI
  fs: PuterFS
  kv: PuterKV
  auth: PuterAuth
  print: (...args: any[]) => void
  randName: () => string
}

declare global {
  interface Window {
    puter: Puter
  }
}

export {}
