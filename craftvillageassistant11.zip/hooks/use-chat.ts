"use client"

import type React from "react"
import { useState, useCallback, useEffect } from "react"

interface Message {
  role: string
  content: string | any
}

// Mock responses for when the API is unavailable
const mockResponses = {
  vi: [
    "Xin chào! Tôi là trợ lý AI Nghệ Nhân Số. Tôi có thể giúp gì cho bạn về làng nghề truyền thống Việt Nam?",
    "Làng nghề truyền thống Việt Nam có lịch sử phát triển lâu đời, với nhiều sản phẩm thủ công mỹ nghệ nổi tiếng như gốm Bát Tràng, lụa Vạn Phúc, và tranh dân gian Đông Hồ.",
    "Để phát triển thương hiệu cho sản phẩm làng nghề, bạn cần xây dựng câu chuyện về nguồn gốc, quy trình sản xuất, và giá trị văn hóa của sản phẩm.",
    "Chụp ảnh sản phẩm đẹp là rất quan trọng khi bán hàng online. Bạn nên sử dụng ánh sáng tự nhiên, nền đơn giản, và chụp nhiều góc độ khác nhau.",
    "Bạn muốn tôi hỗ trợ gì tiếp theo không ạ?",
  ],
  en: [
    "Hello! I'm the Digital Artisan AI Assistant. How can I help you with Vietnamese traditional craft villages?",
    "Vietnamese traditional craft villages have a long history, with many famous handicraft products such as Bat Trang pottery, Van Phuc silk, and Dong Ho folk paintings.",
    "To develop a brand for craft village products, you need to build a story about the origin, production process, and cultural value of the product.",
    "Taking good product photos is very important when selling online. You should use natural light, simple backgrounds, and capture multiple angles.",
    "Is there anything else I can help you with?",
  ],
}

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [selectedModel, setSelectedModel] = useState("gpt-4o")
  const [language, setLanguage] = useState("vi") // Default to Vietnamese
  const [error, setError] = useState<string | null>(null)
  const [useFallback, setUseFallback] = useState(false)
  const [scriptLoaded, setScriptLoaded] = useState(false)
  const [scriptError, setScriptError] = useState(false)
  const [isLoadingScript, setIsLoadingScript] = useState(false)
  const [retryCount, setRetryCount] = useState(0)

  // Function to load Puter.js script
  const loadPuterScript = useCallback(() => {
    // Skip if already loaded or loading
    if (typeof window === "undefined" || window.puter || isLoadingScript) {
      if (window.puter) setScriptLoaded(true)
      return
    }

    setIsLoadingScript(true)
    setScriptError(false)

    try {
      // Create a new script element
      const script = document.createElement("script")
      script.src = "https://js.puter.com/v2/"
      script.async = true

      // Add event handlers
      script.onload = () => {
        console.log("Puter.js loaded successfully")
        setScriptLoaded(true)
        setScriptError(false)
        setIsLoadingScript(false)
        setUseFallback(false)
      }

      script.onerror = (e) => {
        console.error("Failed to load Puter.js", e)
        setScriptLoaded(false)
        setScriptError(true)
        setIsLoadingScript(false)
        setUseFallback(true)
      }

      // Append the script to the document
      document.body.appendChild(script)
    } catch (err) {
      console.error("Error setting up Puter.js:", err)
      setScriptError(true)
      setScriptLoaded(false)
      setIsLoadingScript(false)
      setUseFallback(true)
    }
  }, [isLoadingScript])

  // Try to load Puter.js on component mount
  useEffect(() => {
    // Check if Puter is already available
    if (typeof window !== "undefined" && window.puter) {
      setScriptLoaded(true)
      return
    }

    // Load the script
    loadPuterScript()
  }, [loadPuterScript, retryCount])

  // Function to retry loading the script
  const retryScriptLoad = useCallback(() => {
    setRetryCount((prev) => prev + 1)
  }, [])

  // Load messages from localStorage on initial load
  useEffect(() => {
    try {
      const savedMessages = localStorage.getItem("chatMessages")
      const savedModel = localStorage.getItem("selectedModel")
      const savedLanguage = localStorage.getItem("language")

      if (savedMessages) {
        setMessages(JSON.parse(savedMessages))
      }

      if (savedModel) {
        setSelectedModel(savedModel)
      }

      if (savedLanguage) {
        setLanguage(savedLanguage)
      }
    } catch (e) {
      console.error("Error loading saved chat:", e)
    }
  }, [])

  // Save messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 0) {
      try {
        localStorage.setItem("chatMessages", JSON.stringify(messages))
      } catch (e) {
        console.error("Error saving chat:", e)
      }
    }
  }, [messages])

  // Save model selection to localStorage
  useEffect(() => {
    localStorage.setItem("selectedModel", selectedModel)
  }, [selectedModel])

  // Save language selection to localStorage
  useEffect(() => {
    localStorage.setItem("language", language)
  }, [language])

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }, [])

  const toggleLanguage = useCallback(() => {
    setLanguage((prev) => (prev === "vi" ? "en" : "vi"))
  }, [])

  const handleModelChange = useCallback((model: string) => {
    setSelectedModel(model)
  }, [])

  // Function to get a random mock response
  const getMockResponse = useCallback(() => {
    const responses = language === "vi" ? mockResponses.vi : mockResponses.en
    const randomIndex = Math.floor(Math.random() * responses.length)
    return responses[randomIndex]
  }, [language])

  // Function to safely extract text from response
  const extractResponseText = useCallback((response: any): string => {
    if (typeof response === "string") {
      return response
    } else if (response && typeof response === "object") {
      // Check if it's a DeepSeek response format
      if (response.message && response.message.content) {
        return response.message.content
      }

      // Try to extract text from object (OpenAI format)
      if (response.message && typeof response.message === "string") {
        return response.message
      } else if (response.content && typeof response.content === "string") {
        return response.content
      } else if (response.text && typeof response.text === "string") {
        return response.text
      } else if (response.toString && typeof response.toString === "function") {
        const str = response.toString()
        return str === "[object Object]" ? JSON.stringify(response) : str
      } else {
        return JSON.stringify(response)
      }
    } else if (response === null || response === undefined) {
      return ""
    } else {
      return String(response)
    }
  }, [])

  const handleSubmit = useCallback(
    async (e: { preventDefault: () => void }, formData?: FormData) => {
      e.preventDefault()
      setError(null)

      const userMessage = formData ? (formData.get("message") as string) : input

      if (!userMessage.trim()) return

      // Add user message to chat
      const newUserMessage = { role: "user", content: userMessage }
      setMessages((prev) => [...prev, newUserMessage])
      setInput("")
      setIsLoading(true)

      try {
        // Use fallback if Puter.js isn't available or there was an error loading it
        if (useFallback || scriptError || !scriptLoaded) {
          // Use mock response if in fallback mode
          setTimeout(() => {
            const mockResponse = getMockResponse()
            setMessages((prev) => [...prev, { role: "assistant", content: mockResponse }])
            setIsLoading(false)
          }, 1000) // Simulate API delay
          return
        }

        // Try to use Puter.js if available
        if (typeof window !== "undefined" && window.puter && window.puter.ai && window.puter.ai.chat) {
          try {
            // Create a system prompt that includes language preference and context
            const systemPrompt =
              language === "vi"
                ? "Bạn là trợ lý AI Nghệ Nhân Số, chuyên về làng nghề truyền thống Việt Nam. Trả lời bằng tiếng Việt."
                : "You are the Digital Artisan AI Assistant, specialized in Vietnamese traditional craft villages. Answer in English."

            // Call Puter.js API
            const result = await window.puter.ai.chat(userMessage, {
              model: selectedModel,
              systemPrompt: systemPrompt,
            })

            // Extract text from response
            const responseText = extractResponseText(result)

            // Add response to messages
            setMessages((prev) => [...prev, { role: "assistant", content: responseText }])
            return
          } catch (puterError) {
            console.error("Puter.js error:", puterError)
            // If Puter.js fails, use fallback
            setUseFallback(true)
            const mockResponse = getMockResponse()
            setMessages((prev) => [...prev, { role: "assistant", content: mockResponse }])
            return
          }
        }

        // Call the API with the selected model
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            messages: [...messages, newUserMessage],
            model: selectedModel,
            language,
          }),
        })

        if (!response.ok) {
          // If API fails, switch to fallback mode
          setUseFallback(true)
          throw new Error(`Server responded with ${response.status}: ${response.statusText || "Internal server error"}`)
        }

        // Parse the response
        let responseData
        try {
          responseData = await response.json()
        } catch (jsonError) {
          // If not valid JSON, try to get text
          const responseText = await response.text()
          responseData = { content: responseText }
        }

        // Extract text from response
        const responseText = extractResponseText(responseData)

        // Add response to messages
        setMessages((prev) => [...prev, { role: "assistant", content: responseText }])
      } catch (error) {
        console.error("Error:", error)

        // Use fallback response on error
        const mockResponse = getMockResponse()
        setMessages((prev) => [...prev, { role: "assistant", content: mockResponse }])

        // Set error state with detailed message
        setError(
          language === "vi"
            ? "Đã xảy ra lỗi khi kết nối với máy chủ. Đang sử dụng chế độ dự phòng."
            : "An error occurred when connecting to the server. Using fallback mode.",
        )
      } finally {
        setIsLoading(false)
      }
    },
    [
      input,
      messages,
      selectedModel,
      language,
      useFallback,
      getMockResponse,
      extractResponseText,
      scriptLoaded,
      scriptError,
    ],
  )

  const clearChat = useCallback(() => {
    setMessages([])
    localStorage.removeItem("chatMessages")
    setError(null)
  }, [])

  return {
    messages,
    input,
    isLoading,
    selectedModel,
    language,
    error,
    scriptError,
    isLoadingScript,
    handleInputChange,
    handleSubmit,
    handleModelChange,
    toggleLanguage,
    clearChat,
    retryScriptLoad,
  }
}
