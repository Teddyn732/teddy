"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Languages } from "lucide-react"
import { BusinessPlanGenerator } from "@/components/business-plan-generator"
import { BusinessTemplates } from "@/components/business-templates"
import { useRouter } from "next/navigation"

export default function BusinessPlanPage() {
  const [language, setLanguage] = useState("vi") // Default to Vietnamese
  const router = useRouter()
  const isVietnamese = language === "vi"

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "vi" ? "en" : "vi"))
  }

  const handleGeneratePlan = (prompt: string) => {
    // Store the prompt in localStorage
    localStorage.setItem("businessPlanPrompt", prompt)
    // Navigate to the chat page
    router.push("/tro-ly-ai")
  }

  return (
    <div className="min-h-screen bg-cream flex flex-col">
      <header className="bg-white border-b border-earth-200 py-3 px-4 sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/tro-ly-ai" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5 text-earth-700" />
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="Làng Nghề Việt Logo" className="h-8 w-8" />
              <h1 className="text-xl font-bold text-earth-900">Làng Nghề Việt</h1>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2" onClick={toggleLanguage}>
              <Languages className="h-4 w-4" />
              <span className="hidden md:inline">{isVietnamese ? "Tiếng Việt" : "English"}</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-earth-900 mb-6">
            {isVietnamese ? "Công cụ lập kế hoạch kinh doanh" : "Business Planning Tools"}
          </h1>

          <p className="text-earth-700 mb-8">
            {isVietnamese
              ? "Sử dụng công cụ này để tạo kế hoạch kinh doanh chuyên nghiệp cho doanh nghiệp làng nghề của bạn. Bạn có thể tạo kế hoạch tùy chỉnh hoặc sử dụng các mẫu có sẵn."
              : "Use this tool to create a professional business plan for your craft business. You can create a custom plan or use pre-made templates."}
          </p>

          <Tabs defaultValue="generator" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="generator" className="text-lg py-3">
                {isVietnamese ? "Tạo kế hoạch" : "Plan Generator"}
              </TabsTrigger>
              <TabsTrigger value="templates" className="text-lg py-3">
                {isVietnamese ? "Mẫu kinh doanh" : "Business Templates"}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="generator">
              <BusinessPlanGenerator language={language} onGenerate={handleGeneratePlan} />
            </TabsContent>

            <TabsContent value="templates">
              <div className="space-y-6">
                <p className="text-earth-700">
                  {isVietnamese
                    ? "Chọn một trong các mẫu dưới đây để bắt đầu. Trợ lý AI sẽ hướng dẫn bạn qua quá trình tạo kế hoạch."
                    : "Choose one of the templates below to get started. The AI assistant will guide you through the process."}
                </p>

                <BusinessTemplates language={language} onSelect={handleGeneratePlan} />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
