"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2 } from "lucide-react"

declare global {
  interface Window {
    puter?: {
      ai?: {
        chat?: (prompt: string, options?: any) => Promise<any>
      }
    }
  }
}

export default function DeepSeekDemoPage() {
  const [prompt, setPrompt] = useState("Giải thích về làng nghề truyền thống Việt Nam và tầm quan trọng của chúng")
  const [chatResponse, setChatResponse] = useState("")
  const [reasonerResponse, setReasonerResponse] = useState("")
  const [isLoadingChat, setIsLoadingChat] = useState(false)
  const [isLoadingReasoner, setIsLoadingReasoner] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [scriptLoaded, setScriptLoaded] = useState(false)

  // Load Puter.js script
  useEffect(() => {
    if (typeof window !== "undefined" && !window.puter) {
      try {
        const script = document.createElement("script")
        script.src = "https://js.puter.com/v2/"
        script.async = true
        script.onload = () => setScriptLoaded(true)
        script.onerror = () => {
          console.error("Failed to load Puter.js")
          setScriptLoaded(false)
        }
        document.body.appendChild(script)

        return () => {
          document.body.removeChild(script)
        }
      } catch (err) {
        console.error("Error loading Puter.js:", err)
      }
    } else if (window.puter) {
      setScriptLoaded(true)
    }
  }, [])

  const generateResponses = async () => {
    if (!prompt.trim() || !scriptLoaded) return

    setError(null)
    setChatResponse("")
    setReasonerResponse("")

    // Generate DeepSeek Chat response
    setIsLoadingChat(true)
    try {
      if (window.puter && window.puter.ai && window.puter.ai.chat) {
        const chatStreamResponse = await window.puter.ai.chat(prompt, {
          model: "deepseek-chat",
          stream: true,
        })

        let fullChatResponse = ""
        for await (const part of chatStreamResponse) {
          if (part?.text) {
            fullChatResponse += part.text
            setChatResponse(fullChatResponse)
          }
        }
      }
    } catch (error) {
      console.error("Error with DeepSeek Chat:", error)
      setError("Lỗi khi tạo phản hồi từ DeepSeek Chat")
    } finally {
      setIsLoadingChat(false)
    }

    // Generate DeepSeek Reasoner response
    setIsLoadingReasoner(true)
    try {
      if (window.puter && window.puter.ai && window.puter.ai.chat) {
        const reasonerStreamResponse = await window.puter.ai.chat(prompt, {
          model: "deepseek-reasoner",
          stream: true,
        })

        let fullReasonerResponse = ""
        for await (const part of reasonerStreamResponse) {
          if (part?.text) {
            fullReasonerResponse += part.text
            setReasonerResponse(fullReasonerResponse)
          }
        }
      }
    } catch (error) {
      console.error("Error with DeepSeek Reasoner:", error)
      setError("Lỗi khi tạo phản hồi từ DeepSeek Reasoner")
    } finally {
      setIsLoadingReasoner(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-4">DeepSeek AI Demo</h1>
      <p className="text-center mb-8">So sánh phản hồi từ DeepSeek Chat và DeepSeek Reasoner</p>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Nhập câu hỏi của bạn</CardTitle>
          <CardDescription>
            Nhập câu hỏi hoặc yêu cầu để xem cách hai mô hình DeepSeek phản hồi khác nhau
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Nhập câu hỏi của bạn..."
            className="min-h-[100px]"
          />
        </CardContent>
        <CardFooter>
          <Button
            onClick={generateResponses}
            disabled={isLoadingChat || isLoadingReasoner || !prompt.trim() || !scriptLoaded}
          >
            {isLoadingChat || isLoadingReasoner ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang tạo phản hồi...
              </>
            ) : (
              "Tạo phản hồi"
            )}
          </Button>
        </CardFooter>
      </Card>

      {error && <div className="bg-red-50 p-4 rounded-lg text-red-500 mb-8">{error}</div>}

      <Tabs defaultValue="compare" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="compare">So sánh</TabsTrigger>
          <TabsTrigger value="chat">DeepSeek Chat</TabsTrigger>
          <TabsTrigger value="reasoner">DeepSeek Reasoner</TabsTrigger>
        </TabsList>

        <TabsContent value="compare">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>DeepSeek Chat</CardTitle>
                <CardDescription>Tối ưu cho hội thoại tổng quát</CardDescription>
              </CardHeader>
              <CardContent className="h-[500px] overflow-y-auto">
                {isLoadingChat ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : chatResponse ? (
                  <div className="whitespace-pre-wrap">{chatResponse}</div>
                ) : (
                  <div className="text-gray-400 text-center h-full flex items-center justify-center">
                    Nhấn "Tạo phản hồi" để xem kết quả
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>DeepSeek Reasoner</CardTitle>
                <CardDescription>Tối ưu cho suy luận và phân tích phức tạp</CardDescription>
              </CardHeader>
              <CardContent className="h-[500px] overflow-y-auto">
                {isLoadingReasoner ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : reasonerResponse ? (
                  <div className="whitespace-pre-wrap">{reasonerResponse}</div>
                ) : (
                  <div className="text-gray-400 text-center h-full flex items-center justify-center">
                    Nhấn "Tạo phản hồi" để xem kết quả
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="chat">
          <Card>
            <CardHeader>
              <CardTitle>DeepSeek Chat</CardTitle>
              <CardDescription>Tối ưu cho hội thoại tổng quát</CardDescription>
            </CardHeader>
            <CardContent className="h-[600px] overflow-y-auto">
              {isLoadingChat ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : chatResponse ? (
                <div className="whitespace-pre-wrap">{chatResponse}</div>
              ) : (
                <div className="text-gray-400 text-center h-full flex items-center justify-center">
                  Nhấn "Tạo phản hồi" để xem kết quả
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reasoner">
          <Card>
            <CardHeader>
              <CardTitle>DeepSeek Reasoner</CardTitle>
              <CardDescription>Tối ưu cho suy luận và phân tích phức tạp</CardDescription>
            </CardHeader>
            <CardContent className="h-[600px] overflow-y-auto">
              {isLoadingReasoner ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : reasonerResponse ? (
                <div className="whitespace-pre-wrap">{reasonerResponse}</div>
              ) : (
                <div className="text-gray-400 text-center h-full flex items-center justify-center">
                  Nhấn "Tạo phản hồi" để xem kết quả
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
