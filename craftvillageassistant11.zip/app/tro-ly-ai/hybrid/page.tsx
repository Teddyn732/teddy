"use client"
import HybridAIAssistant from "@/components/hybrid-ai-assistant"

export default function HybridAIPage() {
  return (
    <main className="container mx-auto py-6">
      <HybridAIAssistant />
    </main>
  )
}
