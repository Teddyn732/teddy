"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import UltimateAIAssistant from "@/components/ultimate-ai-assistant"

export default function AIAssistantPage() {
  const [activeTab, setActiveTab] = useState("assistant")

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-2">Trợ Lý AI Toàn Năng</h1>
      <p className="text-center text-gray-500 mb-8">Trợ lý thông minh hỗ trợ phát triển làng nghề truyền thống</p>

      {/* Information alert removed */}

      <Tabs defaultValue="assistant" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="assistant">Trợ Lý AI</TabsTrigger>
          <TabsTrigger value="info">Thông tin</TabsTrigger>
        </TabsList>
        <TabsContent value="assistant">
          <UltimateAIAssistant />
        </TabsContent>
        <TabsContent value="info">
          <Card>
            <CardHeader>
              <CardTitle>Về Trợ Lý AI Toàn Năng</CardTitle>
              <CardDescription>Công cụ hỗ trợ phát triển làng nghề truyền thống</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Trợ Lý AI Toàn Năng là công cụ thông minh được phát triển để hỗ trợ các nghệ nhân, doanh nghiệp và cộng
                đồng làng nghề truyền thống Việt Nam.
              </p>

              <h3 className="text-lg font-medium">Tính năng chính:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Tư vấn phát triển thương hiệu cho sản phẩm làng nghề</li>
                <li>Hướng dẫn kỹ thuật chụp ảnh và trình bày sản phẩm</li>
                <li>Cung cấp thông tin về các làng nghề truyền thống</li>
                <li>Tư vấn chiến lược kinh doanh và tiếp thị</li>
                <li>Hỗ trợ kết nối với thị trường trong nước và quốc tế</li>
                <li>Tạo hình ảnh cho sản phẩm và marketing</li>
                <li>Chuyển văn bản thành giọng nói cho nội dung quảng bá</li>
                <li>Hỗ trợ nhiều mô hình AI (OpenAI, Claude, DeepSeek)</li>
              </ul>

              <h3 className="text-lg font-medium mt-4">Chế độ dự phòng:</h3>
              <p>
                Khi không thể kết nối với dịch vụ AI, trợ lý sẽ chuyển sang chế độ dự phòng với các câu trả lời mẫu.
                Điều này đảm bảo bạn luôn nhận được phản hồi, ngay cả khi có vấn đề về kết nối.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
