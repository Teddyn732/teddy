"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

declare global {
  interface Window {
    puter?: {
      ai?: {
        chat?: (prompt: string, options?: any) => Promise<any>
      }
    }
  }
}

export default function ClaudeDemo() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [response, setResponse] = useState<string>("")
  const [selectedModel, setSelectedModel] = useState("claude-3-7-sonnet")
  const [scriptLoaded, setScriptLoaded] = useState(false)
  const [isStreaming, setIsStreaming] = useState(false)
  const responseRef = useRef<HTMLDivElement>(null)

  // Load Puter.js script
  useEffect(() => {
    if (typeof window !== "undefined" && !window.puter) {
      try {
        const script = document.createElement("script")
        script.src = "https://js.puter.com/v2/"
        script.async = true
        script.onload = () => setScriptLoaded(true)
        script.onerror = () => {
          console.error("Failed to load Puter.js")
          setScriptLoaded(false)
        }
        document.body.appendChild(script)

        return () => {
          document.body.removeChild(script)
        }
      } catch (err) {
        console.error("Error loading Puter.js:", err)
      }
    } else if (window.puter) {
      setScriptLoaded(true)
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    setIsLoading(true)
    setError(null)
    setResponse("")

    try {
      if (window.puter && window.puter.ai && window.puter.ai.chat && scriptLoaded) {
        if (isStreaming) {
          // Stream the response
          const streamResponse = await window.puter.ai.chat(prompt, {
            model: selectedModel,
            stream: true,
            systemPrompt: "Bạn là trợ lý AI Nghệ Nhân Số, chuyên về làng nghề truyền thống Việt Nam.",
          })

          // Handle streaming
          for await (const part of streamResponse) {
            if (part && part.text) {
              setResponse((prev) => prev + part.text)
            }
          }
        } else {
          // Get the full response at once
          const result = await window.puter.ai.chat(prompt, {
            model: selectedModel,
            systemPrompt: "Bạn là trợ lý AI Nghệ Nhân Số, chuyên về làng nghề truyền thống Việt Nam.",
          })

          // Handle Claude-specific response format
          if (result && result.message && result.message.content) {
            if (Array.isArray(result.message.content) && result.message.content.length > 0) {
              const firstContent = result.message.content[0]
              if (firstContent && firstContent.text) {
                setResponse(firstContent.text)
              }
            } else if (typeof result.message.content === "string") {
              setResponse(result.message.content)
            }
          } else if (typeof result === "string") {
            setResponse(result)
          } else if (result && typeof result === "object") {
            setResponse(JSON.stringify(result))
          }
        }
      } else {
        throw new Error("Puter.js không khả dụng")
      }
    } catch (err: any) {
      console.error("Error:", err)
      setError(err.message || "Đã xảy ra lỗi")
    } finally {
      setIsLoading(false)
      // Scroll to response
      setTimeout(() => {
        responseRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Claude AI Demo</h1>

      <Card className="w-full max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle>Trải nghiệm Claude AI</CardTitle>
          <div className="flex items-center gap-4 mt-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">Model:</span>
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Chọn model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="claude-3-5-sonnet">Claude 3.5 Sonnet</SelectItem>
                  <SelectItem value="claude-3-7-sonnet">Claude 3.7 Sonnet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">Streaming:</span>
              <input
                type="checkbox"
                checked={isStreaming}
                onChange={() => setIsStreaming(!isStreaming)}
                className="h-4 w-4"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Textarea
              placeholder="Nhập câu hỏi của bạn về làng nghề truyền thống..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[100px]"
              disabled={isLoading}
            />

            <Button type="submit" disabled={isLoading || !prompt.trim()} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                </>
              ) : (
                "Gửi"
              )}
            </Button>
          </form>

          {error && <div className="bg-red-50 p-3 rounded-lg text-red-500 text-sm mt-4">Lỗi: {error}</div>}

          {response && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium mb-2">Phản hồi:</h3>
              <div className="whitespace-pre-wrap">{response}</div>
            </div>
          )}

          <div ref={responseRef} />
        </CardContent>
        <CardFooter className="text-sm text-gray-500">Powered by Claude AI thông qua Puter.js</CardFooter>
      </Card>
    </div>
  )
}
