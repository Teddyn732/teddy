"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { Send, Mic, ImageIcon, BarChart3, ShoppingBag, BookOpen, Lightbulb, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useChat } from "@/hooks/use-chat"
import { ChatMessage } from "@/components/chat-message"
import { SuggestionButton } from "@/components/suggestion-button"

export default function ChatPage() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat()
  const messagesEndRef = useRef(null)
  const [activeTab, setActiveTab] = useState("chat")

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const suggestions = [
    {
      title: "Tối ưu hóa quy trình sản xuất",
      description: "Giúp tôi cải thiện quy trình sản xuất gốm sứ",
      category: "operations",
    },
    {
      title: "Chiến lược thương hiệu",
      description: "Làm thế nào để xây dựng thương hiệu cho sản phẩm thủ công mỹ nghệ của tôi?",
      category: "marketing",
    },
    {
      title: "Kế hoạch kinh doanh",
      description: "Tạo kế hoạch kinh doanh cho làng nghề dệt lụa",
      category: "business",
    },
    {
      title: "Thiết kế logo",
      description: "Thiết kế logo cho cửa hàng đồ gỗ mỹ nghệ của tôi",
      category: "design",
    },
    {
      title: "Phân tích thị trường",
      description: "Phân tích xu hướng thị trường cho sản phẩm mây tre đan",
      category: "business",
    },
    {
      title: "Chiến lược giá",
      description: "Giúp tôi định giá sản phẩm thủ công mỹ nghệ",
      category: "marketing",
    },
  ]

  const handleSuggestionClick = (suggestion) => {
    const form = new FormData()
    form.append("message", suggestion.description)
    handleSubmit({ preventDefault: () => {} }, form)
  }

  return (
    <div className="min-h-screen bg-amber-50 flex flex-col">
      <header className="bg-white border-b border-amber-200 py-3 px-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5 text-amber-700" />
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="Craft Village AI Assistant Logo" className="h-8 w-8" />
              <h1 className="text-xl font-bold text-amber-900">Craft Village AI</h1>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="border-amber-700 text-amber-700">
              Lưu cuộc trò chuyện
            </Button>
            <Button variant="ghost" className="text-amber-900">
              Hỗ trợ
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-64 bg-white border-r border-amber-200 p-4 hidden md:block">
          <h2 className="font-bold text-amber-900 mb-4">Công cụ</h2>
          <nav className="space-y-2">
            <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("chat")}>
              <Lightbulb className="mr-2 h-5 w-5 text-amber-700" />
              Trợ lý AI
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("operations")}>
              <BarChart3 className="mr-2 h-5 w-5 text-amber-700" />
              Hệ thống hóa
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("marketing")}>
              <ShoppingBag className="mr-2 h-5 w-5 text-amber-700" />
              Thương mại hóa
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={() => setActiveTab("business")}>
              <BookOpen className="mr-2 h-5 w-5 text-amber-700" />
              Kinh doanh
            </Button>
          </nav>

          <div className="mt-8">
            <h2 className="font-bold text-amber-900 mb-4">Cuộc trò chuyện gần đây</h2>
            <div className="space-y-2">
              <Button variant="ghost" className="w-full justify-start text-sm">
                Kế hoạch kinh doanh gốm Bát Tràng
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm">
                Chiến lược tiếp thị cho đồ mây tre đan
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm">
                Tối ưu hóa quy trình sản xuất lụa
              </Button>
            </div>
          </div>
        </aside>

        <main className="flex-1 flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <div className="bg-white border-b border-amber-200 px-4 py-2">
              <TabsList className="grid grid-cols-4 bg-amber-100">
                <TabsTrigger value="chat" className="data-[state=active]:bg-amber-700 data-[state=active]:text-white">
                  Trợ lý AI
                </TabsTrigger>
                <TabsTrigger
                  value="operations"
                  className="data-[state=active]:bg-amber-700 data-[state=active]:text-white"
                >
                  Hệ thống hóa
                </TabsTrigger>
                <TabsTrigger
                  value="marketing"
                  className="data-[state=active]:bg-amber-700 data-[state=active]:text-white"
                >
                  Thương mại hóa
                </TabsTrigger>
                <TabsTrigger
                  value="business"
                  className="data-[state=active]:bg-amber-700 data-[state=active]:text-white"
                >
                  Kinh doanh
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="chat" className="flex-1 flex flex-col p-0 m-0">
              <div className="flex-1 overflow-y-auto p-4">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center">
                    <div className="max-w-md text-center animate-fade-in">
                      <img src="/welcome-image.svg" alt="Welcome" className="w-32 h-32 mx-auto mb-6 animate-slide-up" />
                      <h2 className="text-2xl font-bold text-amber-900 mb-4 animate-slide-up">
                        Chào mừng đến với Trợ lý AI Làng nghề
                      </h2>
                      <p className="text-amber-800 mb-8 animate-slide-up">
                        Tôi có thể giúp bạn tối ưu hóa sản xuất, thương mại hóa sản phẩm và phát triển kinh doanh. Hãy
                        đặt câu hỏi hoặc chọn một gợi ý bên dưới.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 stagger-children">
                        {suggestions.slice(0, 4).map((suggestion, index) => (
                          <div key={index} className="animate-slide-up">
                            <SuggestionButton
                              title={suggestion.title}
                              description={suggestion.description}
                              onClick={() => handleSuggestionClick(suggestion)}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {messages.map((message, index) => (
                      <div key={index} className={`animate-fade-in`} style={{ animationDelay: `${index * 0.1}s` }}>
                        <ChatMessage message={message} />
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              <div className="border-t border-amber-200 bg-white p-4">
                <form onSubmit={handleSubmit} className="flex gap-2">
                  <Button type="button" size="icon" variant="outline" className="border-amber-300">
                    <Mic className="h-5 w-5 text-amber-700" />
                  </Button>
                  <Button type="button" size="icon" variant="outline" className="border-amber-300">
                    <ImageIcon className="h-5 w-5 text-amber-700" />
                  </Button>
                  <Input
                    name="message"
                    value={input}
                    onChange={handleInputChange}
                    placeholder="Nhập câu hỏi của bạn..."
                    className="flex-1 border-amber-300 focus-visible:ring-amber-500"
                  />
                  <Button
                    type="submit"
                    size="icon"
                    disabled={isLoading}
                    className="bg-amber-700 hover:bg-amber-800 text-white"
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </form>
              </div>
            </TabsContent>

            <TabsContent value="operations" className="flex-1 p-6 overflow-y-auto">
              <h2 className="text-2xl font-bold text-amber-900 mb-6">Hệ thống hóa hoạt động</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Phân tích quy trình sản xuất</h3>
                  <p className="text-amber-800 mb-4">
                    Xác định và tối ưu hóa các giai đoạn sản xuất để cải thiện hiệu quả và chất lượng sản phẩm.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Bắt đầu phân tích</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Quản lý hàng tồn kho</h3>
                  <p className="text-amber-800 mb-4">
                    Thiết lập hệ thống quản lý hàng tồn kho cơ bản để theo dõi nguyên liệu và sản phẩm.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo hệ thống quản lý</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Tối ưu hóa quy trình làm việc</h3>
                  <p className="text-amber-800 mb-4">
                    Cải thiện quy trình làm việc để giảm thời gian và chi phí sản xuất.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tối ưu hóa quy trình</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Dự báo nhu cầu</h3>
                  <p className="text-amber-800 mb-4">
                    Phân tích dữ liệu bán hàng để dự báo nhu cầu và lập kế hoạch sản xuất.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo dự báo</Button>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="marketing" className="flex-1 p-6 overflow-y-auto">
              <h2 className="text-2xl font-bold text-amber-900 mb-6">Thương mại hóa sản phẩm</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Xây dựng thương hiệu</h3>
                  <p className="text-amber-800 mb-4">
                    Phát triển chiến lược thương hiệu và nhận diện thương hiệu cho sản phẩm thủ công mỹ nghệ.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo thương hiệu</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Bán hàng trực tuyến</h3>
                  <p className="text-amber-800 mb-4">
                    Thiết lập và quản lý cửa hàng trực tuyến trên các nền tảng thương mại điện tử.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Bắt đầu bán hàng online</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Mô hình định giá</h3>
                  <p className="text-amber-800 mb-4">
                    Phát triển chiến lược định giá cạnh tranh dựa trên chi phí, giá trị và thị trường.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo mô hình giá</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Tiếp thị số</h3>
                  <p className="text-amber-800 mb-4">
                    Phát triển chiến lược tiếp thị số để tiếp cận khách hàng mục tiêu.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo chiến lược tiếp thị</Button>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="business" className="flex-1 p-6 overflow-y-auto">
              <h2 className="text-2xl font-bold text-amber-900 mb-6">Xây dựng kinh doanh</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Kế hoạch kinh doanh</h3>
                  <p className="text-amber-800 mb-4">
                    Tạo kế hoạch kinh doanh toàn diện cho doanh nghiệp thủ công mỹ nghệ của bạn.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo kế hoạch</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Quản lý tài chính</h3>
                  <p className="text-amber-800 mb-4">Học cách quản lý tài chính cơ bản cho doanh nghiệp nhỏ.</p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Bắt đầu học</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Quản lý khách hàng</h3>
                  <p className="text-amber-800 mb-4">
                    Phát triển chiến lược quản lý khách hàng để xây dựng mối quan hệ lâu dài.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Tạo chiến lược</Button>
                </Card>
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-amber-900 mb-4">Phân tích thị trường</h3>
                  <p className="text-amber-800 mb-4">
                    Phân tích xu hướng thị trường và cạnh tranh để xác định cơ hội kinh doanh.
                  </p>
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">Bắt đầu phân tích</Button>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
