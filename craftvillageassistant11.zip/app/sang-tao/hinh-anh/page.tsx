"use client"

import { useState } from "react"
import ImageGenerator from "@/components/image-generator"

export default function ImageGeneratorPage() {
  const [language, setLanguage] = useState("vi")

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-2">
        {language === "vi" ? "Công cụ tạo hình ảnh AI" : "AI Image Generator"}
      </h1>
      <p className="text-center mb-8">
        {language === "vi"
          ? "Tạo hình ảnh cho sản phẩm làng nghề, thiết kế, và quảng cáo"
          : "Create images for craft products, designs, and advertisements"}
      </p>

      <div className="flex justify-center mb-4">
        <button
          onClick={() => setLanguage("vi")}
          className={`px-4 py-2 rounded-l-md ${language === "vi" ? "bg-primary text-white" : "bg-gray-100"}`}
        >
          Tiếng Việt
        </button>
        <button
          onClick={() => setLanguage("en")}
          className={`px-4 py-2 rounded-r-md ${language === "en" ? "bg-primary text-white" : "bg-gray-100"}`}
        >
          English
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <ImageGenerator language={language} />
        </div>

        <div>
          <div className="bg-gray-50 p-6 rounded-lg h-full">
            <h2 className="text-xl font-semibold mb-4">
              {language === "vi" ? "Gợi ý mô tả hình ảnh" : "Image prompt suggestions"}
            </h2>

            <div className="space-y-4">
              <div className="bg-white p-4 rounded-md shadow-sm">
                <h3 className="font-medium mb-2">
                  {language === "vi" ? "Sản phẩm gốm Bát Tràng" : "Bat Trang pottery products"}
                </h3>
                <p className="text-sm text-gray-600">
                  {language === "vi"
                    ? "Bộ ấm trà gốm Bát Tràng màu xanh ngọc với hoa văn sen truyền thống, chụp từ góc 45 độ trên nền gỗ tự nhiên"
                    : "A turquoise Bat Trang ceramic tea set with traditional lotus patterns, shot from a 45-degree angle on a natural wooden background"}
                </p>
              </div>

              <div className="bg-white p-4 rounded-md shadow-sm">
                <h3 className="font-medium mb-2">
                  {language === "vi" ? "Sản phẩm lụa Vạn Phúc" : "Van Phuc silk products"}
                </h3>
                <p className="text-sm text-gray-600">
                  {language === "vi"
                    ? "Khăn lụa Vạn Phúc màu đỏ thẫm với họa tiết hoa đào, được trải nhẹ nhàng trên bàn màu trắng với ánh sáng tự nhiên"
                    : "A deep red Van Phuc silk scarf with peach blossom patterns, gently laid out on a white table with natural lighting"}
                </p>
              </div>

              <div className="bg-white p-4 rounded-md shadow-sm">
                <h3 className="font-medium mb-2">{language === "vi" ? "Tranh Đông Hồ" : "Dong Ho folk painting"}</h3>
                <p className="text-sm text-gray-600">
                  {language === "vi"
                    ? "Tranh dân gian Đông Hồ 'Đám cưới chuột' với màu sắc tươi sáng truyền thống, được treo trên tường gạch đỏ"
                    : "A traditional Dong Ho folk painting 'Mouse Wedding' with bright traditional colors, hung on a red brick wall"}
                </p>
              </div>

              <div className="bg-white p-4 rounded-md shadow-sm">
                <h3 className="font-medium mb-2">
                  {language === "vi" ? "Sản phẩm mây tre đan" : "Bamboo and rattan products"}
                </h3>
                <p className="text-sm text-gray-600">
                  {language === "vi"
                    ? "Bộ giỏ mây tre đan thủ công với nhiều kích cỡ khác nhau, xếp chồng lên nhau, chụp từ trên cao với ánh sáng tự nhiên"
                    : "A set of handcrafted bamboo and rattan baskets in various sizes, stacked on top of each other, shot from above with natural lighting"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
