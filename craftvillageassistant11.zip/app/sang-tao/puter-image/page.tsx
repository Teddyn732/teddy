import { PuterImageGenerator } from "@/components/puter-image-generator"

export default function PuterImagePage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Tạo hình ảnh với Puter AI</h1>
      <p className="text-center text-muted-foreground mb-8">
        Sử dụng công nghệ Puter AI để tạo hình ảnh sản phẩm làng nghề mà không cần API key
      </p>

      <div className="max-w-2xl mx-auto">
        <PuterImageGenerator />
      </div>
    </div>
  )
}
