import PuterImageGenerator from "@/components/puter-image-generator"

export default function SangTaoPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Sáng tạo với AI</h1>
      <p className="text-center mb-8">
        Sử dụng AI để tạo hình ảnh và thiết kế mới dựa trên các mô típ truyền thống của làng nghề Việt Nam.
      </p>
      <PuterImageGenerator />
    </div>
  )
}
