import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { HeroSection } from "@/components/hero-section"
import { FeatureSection } from "@/components/feature-section"
import { CraftCategorySection } from "@/components/craft-category-section"
import { HowItWorksSection } from "@/components/how-it-works-section"
import { TestimonialSection } from "@/components/testimonial-section"
import { StatsSection } from "@/components/stats-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-cream">
      {/* Header */}
      <header className="bg-white border-b border-amber-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <img src="/logo.svg" alt="Làng Nghề Việt Logo" className="h-12 w-12" />
              <div>
                <h1 className="text-2xl font-bold text-earth-800">Làng Nghề Việt</h1>
                <p className="text-sm text-earth-600">AI đồng hành cùng làng nghề</p>
              </div>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/gioi-thieu" className="text-earth-700 hover:text-earth-900 font-medium transition-colors">
                Giới thiệu
              </Link>
              <Link href="/tro-ly-ai" className="text-earth-700 hover:text-earth-900 font-medium transition-colors">
                Trợ lý AI
              </Link>
              <Link href="/kho-kien-thuc" className="text-earth-700 hover:text-earth-900 font-medium transition-colors">
                Kho kiến thức
              </Link>
              <Link href="/cau-chuyen" className="text-earth-700 hover:text-earth-900 font-medium transition-colors">
                Câu chuyện thành công
              </Link>
              <Link href="/cong-dong" className="text-earth-700 hover:text-earth-900 font-medium transition-colors">
                Cộng đồng
              </Link>
              <Link
                href="/tai-khoan/cai-dat"
                className="text-earth-700 hover:text-earth-900 font-medium transition-colors"
              >
                Cài đặt
              </Link>
              <Link href="/puter-demo" className="text-earth-700 hover:text-earth-900 font-medium transition-colors">
                Puter Demo
              </Link>
            </nav>
            <div className="flex items-center gap-3">
              <Button variant="outline" className="border-earth-600 text-earth-700 hover:bg-earth-50">
                Đăng nhập
              </Button>
              <Button className="bg-terracotta hover:bg-terracotta-600 text-white">Đăng ký</Button>
              <button className="md:hidden">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-earth-800"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main>
        <HeroSection />
        <CraftCategorySection />
        <FeatureSection />
        <HowItWorksSection />
        <TestimonialSection />
        <StatsSection />

        {/* CTA */}
        <section className="bg-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-earth-900 mb-6">Sẵn sàng phát triển làng nghề của bạn?</h2>
            <p className="text-xl text-earth-700 mb-8 max-w-2xl mx-auto">
              Bắt đầu hành trình chuyển đổi số và phát triển bền vững cùng Trợ lý AI Làng Nghề Việt
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-terracotta hover:bg-terracotta-600 text-white text-lg px-8 py-6 hover-lift transition-all"
              >
                <Link href="/tro-ly-ai" className="flex items-center">
                  Bắt đầu miễn phí <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-earth-600 text-earth-700 hover:bg-earth-50 text-lg px-8 py-6 hover-lift transition-all"
              >
                <Link href="/lien-he" className="flex items-center">
                  Liên hệ hỗ trợ <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
