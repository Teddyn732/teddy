import CraftVillageInfo from "@/components/craft-village-info"

const craftVillages = [
  {
    name: "Làng gốm Bát Tràng",
    description:
      "Làng gốm Bát Tràng có lịch sử hơn 700 năm, nổi tiếng với các sản phẩm gốm sứ cao cấp. Nghề gốm Bát Tràng được hình thành từ thời Lý và phát triển mạnh vào thời Trần. Các sản phẩm nổi tiếng gồm bát, đĩa, bình hoa, đồ thờ cúng với họa tiết rồng, phượng, hoa sen.",
    location: "Hà Nội",
    craftType: "Gốm sứ",
    foundedYear: 1352,
    imageUrl: "/placeholder.svg?height=200&width=400&text=Bát+Tràng",
  },
  {
    name: "Làng lụa Vạn Phúc",
    description:
      "Làng lụa Vạn Phúc (Hà Đông, Hà Nội) có lịch sử hơn 1,200 năm, nổi tiếng với nghề dệt lụa truyền thống. Lụa Vạn Phúc mềm mại, bền màu, với các họa tiết truyền thống như hoa, lá, chim muông. Sản phẩm nổi tiếng gồm lụa vân, lụa the, lụa đũi, lụa tơ tằm.",
    location: "Hà Nội",
    craftType: "Dệt lụa",
    foundedYear: 1107,
    imageUrl: "/placeholder.svg?height=200&width=400&text=Vạn+Phúc",
  },
  {
    name: "Làng tranh Đông Hồ",
    description:
      "Làng tranh Đông Hồ (Bắc Ninh) nổi tiếng với nghề làm tranh dân gian in từ ván khắc gỗ. Tranh Đông Hồ có lịch sử từ thế kỷ 16, với đặc trưng là giấy điệp màu vàng, màu sắc tự nhiên từ nguyên liệu như lá cây, đất son, than, vỏ cây. Các chủ đề phổ biến gồm Đám cưới chuột, Vinh hoa phú quý, Gà đàn.",
    location: "Bắc Ninh",
    craftType: "Tranh dân gian",
    foundedYear: 1600,
    imageUrl: "/placeholder.svg?height=200&width=400&text=Đông+Hồ",
  },
]

export default function KhamPhaPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Khám Phá Làng Nghề Việt Nam</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {craftVillages.map((village, index) => (
          <CraftVillageInfo key={index} {...village} />
        ))}
      </div>
    </div>
  )
}
