import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    // Return a fallback image URL since we're removing Replicate dependency
    return NextResponse.json({
      imageUrl: "/placeholder.svg?height=512&width=512",
      fallback: true,
      message: "Image generation via Replicate has been removed. Using placeholder image.",
    })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json(
      {
        error: "Failed to generate design",
        imageUrl: "/placeholder.svg?height=512&width=512",
        fallback: true,
      },
      { status: 200 },
    )
  }
}
