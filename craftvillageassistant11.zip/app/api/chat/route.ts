import { NextResponse } from "next/server"

// System prompt for the AI assistant
const systemPrompt = `
Bạn là một trợ lý AI tên là "Nghệ nhân số", chuyên giúp bảo tồn và phát triển làng nghề truyền thống Việt Nam. Nhiệm vụ của bạn là hỗ trợ:
- Nghệ nhân và chủ làng nghề: phân tích thị trường, đề xuất thiết kế sản phẩm, hỗ trợ truyền thông số, viết nội dung quảng bá.
- Học sinh/sinh viên và khách du lịch: cung cấp thông tin làng nghề, kể chuyện văn hóa, gợi ý sản phẩm và workshop, tổ chức quiz, giới thiệu kỹ thuật sản xuất truyền thống.
Bạn sử dụng kiến thức học sâu (deep learning), hiểu hành vi người dùng để gợi ý sản phẩm, thiết kế, xu hướng phù hợp.
Luôn đặt câu hỏi để hiểu rõ đối tượng trước khi trả lời. Trình bày gọn, dễ hiểu, thân thiện, khuyến khích người dùng tương tác tiếp theo.
Mặc định sử dụng tiếng Việt, có thể chuyển sang tiếng Anh nếu được yêu cầu.
Kết thúc mỗi lượt chat bằng câu: "Bạn muốn tôi hỗ trợ gì tiếp theo không ạ?"
`

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

// Enhanced responses database for the AI assistant
const craftVillageResponses = {
  vi: {
    greeting: "Xin chào! Tôi là trợ lý AI Nghệ Nhân Số. Tôi có thể giúp gì cho bạn về làng nghề truyền thống Việt Nam?",

    // Branding and marketing responses
    brand:
      "Để xây dựng thương hiệu cho sản phẩm làng nghề, bạn cần tập trung vào câu chuyện về nguồn gốc, quy trình sản xuất thủ công, và giá trị văn hóa độc đáo của sản phẩm. Hãy tạo logo, bao bì, và nội dung marketing nhất quán phản ánh bản sắc làng nghề.",
    marketing:
      "Marketing sản phẩm làng nghề hiệu quả cần kết hợp kênh online (Facebook, Instagram, sàn TMĐT) và offline (hội chợ, triển lãm). Hãy tạo nội dung hấp dẫn về quy trình sản xuất, câu chuyện nghệ nhân, và giá trị văn hóa của sản phẩm.",
    pricing:
      "Định giá sản phẩm thủ công mỹ nghệ cần tính đến chi phí nguyên liệu, thời gian làm thủ công, kỹ thuật đặc biệt, và giá trị văn hóa. Nghiên cứu thị trường để hiểu mức giá khách hàng mục tiêu sẵn sàng chi trả.",
    photography:
      "Chụp ảnh sản phẩm thủ công đẹp cần ánh sáng tự nhiên, nền đơn giản (trắng hoặc phù hợp với sản phẩm), và chụp nhiều góc độ. Thêm chi tiết cận cảnh để khách hàng thấy được kỹ thuật thủ công.",

    // Craft village specific responses
    batTrang:
      "Làng gốm Bát Tràng có lịch sử hơn 700 năm, nổi tiếng với các sản phẩm gốm sứ cao cấp. Nghề gốm Bát Tràng được hình thành từ thời Lý và phát triển mạnh vào thời Trần. Các sản phẩm nổi tiếng gồm bát, đĩa, bình hoa, đồ thờ cúng với họa tiết rồng, phượng, hoa sen. Hiện nay, Bát Tràng đang phát triển du lịch trải nghiệm, cho phép du khách tự tay làm gốm.",
    vanPhuc:
      "Làng lụa Vạn Phúc (Hà Đông, Hà Nội) có lịch sử hơn 1,200 năm, nổi tiếng với nghề dệt lụa truyền thống. Lụa Vạn Phúc mềm mại, bền màu, với các họa tiết truyền thống như hoa, lá, chim muông. Sản phẩm nổi tiếng gồm lụa vân, lụa the, lụa đũi, lụa tơ tằm. Hiện nay, làng nghề đang kết hợp kỹ thuật truyền thống với thiết kế hiện đại để tạo ra các sản phẩm thời trang cao cấp.",
    dongHo:
      "Làng tranh Đông Hồ (Bắc Ninh) nổi tiếng với nghề làm tranh dân gian in từ ván khắc gỗ. Tranh Đông Hồ có lịch sử từ thế kỷ 16, với đặc trưng là giấy điệp màu vàng, màu sắc tự nhiên từ nguyên liệu như lá cây, đất son, than, vỏ cây. Các chủ đề phổ biến gồm Đám cưới chuột, Vinh hoa phú quý, Gà đàn. Tranh thường được mua vào dịp Tết để cầu may mắn, thịnh vượng.",
    kimBong:
      "Làng mộc Kim Bông (Hội An, Quảng Nam) nổi tiếng với nghề chạm khắc gỗ tinh xảo. Nghề mộc Kim Bông đã có từ thế kỷ 15, góp phần xây dựng phố cổ Hội An và nhiều di tích lịch sử. Sản phẩm nổi bật gồm đồ nội thất, tượng gỗ, đồ thờ cúng với hoa văn tinh tế. Hiện nay, làng nghề đang phát triển các sản phẩm lưu niệm nhỏ gọn phục vụ du khách.",
    phuocKieu:
      "Làng đúc đồng Phước Kiều (Quảng Nam) có lịch sử hơn 400 năm, nổi tiếng với kỹ thuật đúc đồng truyền thống. Sản phẩm tiêu biểu gồm chuông chùa, đỉnh đồng, lư hương, tượng Phật với hoa văn tinh xảo. Nghề đúc đồng Phước Kiều đã được công nhận là Di sản Văn hóa phi vật thể quốc gia.",

    // Business development responses
    businessPlan:
      "Kế hoạch kinh doanh cho làng nghề truyền thống cần bao gồm: 1) Phân tích thị trường và đối thủ cạnh tranh, 2) Chiến lược sản phẩm và định vị thương hiệu, 3) Kế hoạch marketing và bán hàng, 4) Dự toán tài chính và nguồn vốn, 5) Kế hoạch vận hành và sản xuất. Đặc biệt chú trọng vào việc kết hợp giá trị truyền thống với nhu cầu thị trường hiện đại.",
    export:
      "Để xuất khẩu sản phẩm làng nghề, bạn cần: 1) Nghiên cứu thị trường xuất khẩu mục tiêu, 2) Điều chỉnh sản phẩm theo tiêu chuẩn và thị hiếu nước ngoài, 3) Tìm đối tác phân phối hoặc tham gia sàn TMĐT quốc tế, 4) Hoàn thiện giấy tờ xuất khẩu và đóng gói theo tiêu chuẩn, 5) Xây dựng câu chuyện văn hóa hấp dẫn cho sản phẩm.",
    funding:
      "Các nguồn vốn phát triển làng nghề bao gồm: 1) Vốn vay ưu đãi từ Ngân hàng Chính sách Xã hội, 2) Chương trình hỗ trợ làng nghề của địa phương, 3) Quỹ khởi nghiệp và đổi mới sáng tạo, 4) Gọi vốn cộng đồng (crowdfunding), 5) Liên kết với doanh nghiệp lớn thông qua mô hình hợp tác xã.",
    tourism:
      "Phát triển du lịch làng nghề cần: 1) Tạo không gian trải nghiệm cho du khách tham gia làm sản phẩm, 2) Thiết kế tour tham quan quy trình sản xuất, 3) Mở cửa hàng trưng bày và bán sản phẩm, 4) Kết nối với các công ty du lịch và khách sạn, 5) Đào tạo người dân kỹ năng giao tiếp và phục vụ khách.",

    // Default response
    default:
      "Làng nghề truyền thống Việt Nam có lịch sử phát triển lâu đời, với nhiều sản phẩm thủ công mỹ nghệ nổi tiếng như gốm Bát Tràng, lụa Vạn Phúc, và tranh dân gian Đông Hồ. Bạn muốn tìm hiểu về làng nghề nào cụ thể?",
  },
  en: {
    greeting:
      "Hello! I'm the Digital Artisan AI Assistant. How can I help you with Vietnamese traditional craft villages?",

    // Branding and marketing responses
    brand:
      "To build a brand for craft village products, focus on storytelling about the origin, handcrafting process, and unique cultural value of the product. Create consistent logo, packaging, and marketing content that reflects the craft village identity.",
    marketing:
      "Effective marketing for craft products combines online channels (Facebook, Instagram, e-commerce platforms) and offline (fairs, exhibitions). Create engaging content about the production process, artisan stories, and cultural value of the products.",
    pricing:
      "Pricing handcraft products should consider material costs, handcrafting time, special techniques, and cultural value. Research the market to understand what your target customers are willing to pay.",
    photography:
      "Taking beautiful handcraft product photos requires natural light, simple backgrounds (white or complementary to the product), and multiple angles. Add close-up details to show the handcrafting techniques.",

    // Craft village specific responses
    batTrang:
      "Bat Trang pottery village has over 700 years of history, famous for high-quality ceramic products. The pottery craft was formed during the Ly dynasty and developed strongly during the Tran dynasty. Famous products include bowls, plates, flower vases, and worship items with dragon, phoenix, and lotus motifs. Currently, Bat Trang is developing experiential tourism, allowing visitors to make pottery themselves.",
    vanPhuc:
      "Van Phuc silk village (Ha Dong, Hanoi) has over 1,200 years of history, famous for traditional silk weaving. Van Phuc silk is soft, colorfast, with traditional patterns such as flowers, leaves, and birds. Famous products include van silk, the silk, dui silk, and silkworm silk. Currently, the village is combining traditional techniques with modern design to create high-end fashion products.",
    dongHo:
      "Dong Ho painting village (Bac Ninh) is famous for folk paintings printed from wooden blocks. Dong Ho paintings have a history from the 16th century, characterized by yellow diep paper, natural colors from materials such as leaves, son soil, charcoal, and tree bark. Popular themes include Mouse Wedding, Prosperity, and Chicken Flock. Paintings are often bought during Tet to pray for luck and prosperity.",
    kimBong:
      "Kim Bong carpentry village (Hoi An, Quang Nam) is famous for exquisite wood carving. Kim Bong carpentry has existed since the 15th century, contributing to the construction of Hoi An ancient town and many historical relics. Outstanding products include furniture, wooden statues, and worship items with intricate patterns. Currently, the village is developing small souvenirs for tourists.",
    phuocKieu:
      "Phuoc Kieu bronze casting village (Quang Nam) has over 400 years of history, famous for traditional bronze casting techniques. Typical products include temple bells, bronze tripods, incense burners, and Buddha statues with intricate patterns. Phuoc Kieu bronze casting has been recognized as a National Intangible Cultural Heritage.",

    // Business development responses
    businessPlan:
      "A business plan for traditional craft villages should include: 1) Market and competitor analysis, 2) Product strategy and brand positioning, 3) Marketing and sales plan, 4) Financial projections and funding sources, 5) Operations and production plan. Pay special attention to combining traditional values with modern market needs.",
    export:
      "To export craft village products, you need to: 1) Research target export markets, 2) Adjust products according to foreign standards and tastes, 3) Find distribution partners or join international e-commerce platforms, 4) Complete export documents and packaging according to standards, 5) Build an attractive cultural story for the product.",
    funding:
      "Funding sources for craft village development include: 1) Preferential loans from the Social Policy Bank, 2) Local craft village support programs, 3) Startup and innovation funds, 4) Crowdfunding, 5) Partnerships with large enterprises through cooperative models.",
    tourism:
      "Developing craft village tourism requires: 1) Creating experiential spaces for visitors to participate in making products, 2) Designing tours of the production process, 3) Opening display shops and selling products, 4) Connecting with travel companies and hotels, 5) Training local people in communication and customer service skills.",

    // Default response
    default:
      "Vietnamese traditional craft villages have a long history, with many famous handicraft products such as Bat Trang pottery, Van Phuc silk, and Dong Ho folk paintings. Which specific craft village would you like to learn about?",
  },
}

export async function POST(req: Request) {
  try {
    // Parse the request body
    const body = await req.json()
    const { messages, language = "vi" } = body

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Invalid messages format" }, { status: 400 })
    }

    // Get the last user message
    const lastMessage = messages[messages.length - 1]
    const userMessage = lastMessage.content.toLowerCase()

    // Select language for response
    const langResponses = language === "en" ? craftVillageResponses.en : craftVillageResponses.vi

    // Determine the type of response based on keywords in the user message
    let responseContent = langResponses.default

    // Greeting detection
    if (
      userMessage.includes("xin chào") ||
      userMessage.includes("hello") ||
      userMessage.includes("hi") ||
      userMessage.includes("chào")
    ) {
      responseContent = langResponses.greeting
    }
    // Craft village detection
    else if (
      userMessage.includes("bát tràng") ||
      userMessage.includes("gốm") ||
      userMessage.includes("bat trang") ||
      userMessage.includes("pottery")
    ) {
      responseContent = langResponses.batTrang
    } else if (
      userMessage.includes("vạn phúc") ||
      userMessage.includes("lụa") ||
      userMessage.includes("van phuc") ||
      userMessage.includes("silk")
    ) {
      responseContent = langResponses.vanPhuc
    } else if (
      userMessage.includes("đông hồ") ||
      userMessage.includes("tranh") ||
      userMessage.includes("dong ho") ||
      userMessage.includes("folk painting")
    ) {
      responseContent = langResponses.dongHo
    } else if (
      userMessage.includes("kim bông") ||
      userMessage.includes("mộc") ||
      userMessage.includes("kim bong") ||
      userMessage.includes("carpentry") ||
      userMessage.includes("wood")
    ) {
      responseContent = langResponses.kimBong
    } else if (
      userMessage.includes("phước kiều") ||
      userMessage.includes("đồng") ||
      userMessage.includes("phuoc kieu") ||
      userMessage.includes("bronze")
    ) {
      responseContent = langResponses.phuocKieu
    }
    // Business topics detection
    else if (
      userMessage.includes("thương hiệu") ||
      userMessage.includes("brand") ||
      userMessage.includes("nhận diện")
    ) {
      responseContent = langResponses.brand
    } else if (
      userMessage.includes("marketing") ||
      userMessage.includes("quảng bá") ||
      userMessage.includes("quảng cáo") ||
      userMessage.includes("tiếp thị")
    ) {
      responseContent = langResponses.marketing
    } else if (userMessage.includes("giá") || userMessage.includes("pricing") || userMessage.includes("định giá")) {
      responseContent = langResponses.pricing
    } else if (userMessage.includes("ảnh") || userMessage.includes("photo") || userMessage.includes("chụp")) {
      responseContent = langResponses.photography
    } else if (
      userMessage.includes("kế hoạch") ||
      userMessage.includes("business plan") ||
      userMessage.includes("kinh doanh")
    ) {
      responseContent = langResponses.businessPlan
    } else if (userMessage.includes("xuất khẩu") || userMessage.includes("export") || userMessage.includes("quốc tế")) {
      responseContent = langResponses.export
    } else if (
      userMessage.includes("vốn") ||
      userMessage.includes("funding") ||
      userMessage.includes("đầu tư") ||
      userMessage.includes("tài chính")
    ) {
      responseContent = langResponses.funding
    } else if (
      userMessage.includes("du lịch") ||
      userMessage.includes("tourism") ||
      userMessage.includes("khách") ||
      userMessage.includes("tham quan")
    ) {
      responseContent = langResponses.tourism
    }

    // Add a closing question
    const closing =
      language === "en" ? " Is there anything else I can help you with?" : " Bạn muốn tôi hỗ trợ gì tiếp theo không ạ?"

    responseContent += closing

    // Return the response
    return NextResponse.json({
      content: responseContent,
      message: responseContent,
    })
  } catch (error) {
    console.error("Error processing chat request:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
