import { NextResponse } from "next/server"

// This function loads the Puter.js script if it's not already loaded
async function loadPuterScript() {
  if (typeof window !== "undefined") return true // We're on the client side

  // In a server component, we need to use a different approach
  try {
    // Use dynamic import for node-fetch in server environment
    const { default: fetch } = await import("node-fetch")

    // Make a request to the Puter API directly
    const response = await fetch("https://api.puter.com/v2/ai/txt2img", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: "Test prompt",
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to connect to Puter API")
    }

    return true
  } catch (error) {
    console.error("Error connecting to Puter API:", error)
    return false
  }
}

export async function POST(req: Request) {
  try {
    const { craftType, style, elements, description } = await req.json()

    // Check if we can connect to Puter API
    const puterAvailable = await loadPuterScript()

    if (!puterAvailable) {
      // Return a fallback image if Puter is not available
      return NextResponse.json({
        imageUrl: "/placeholder.svg?height=512&width=512",
        fallback: true,
        message: "Using placeholder image. Puter API not available.",
      })
    }

    // Craft-specific prompts
    const craftPrompts = {
      "gom-su": "Vietnamese ceramic pottery with intricate blue patterns",
      "det-may": "Vietnamese traditional textile with detailed embroidery",
      "may-tre": "Vietnamese bamboo and rattan crafts with woven patterns",
      "son-mai": "Vietnamese lacquerware with gold leaf details",
      "thu-cong": "Vietnamese traditional handicraft",
    }

    // Style modifiers
    const styleModifiers = {
      traditional: "authentic traditional Vietnamese style, historical patterns",
      modern: "modern interpretation of Vietnamese craft, contemporary design",
      fusion: "fusion of traditional Vietnamese elements with contemporary design",
    }

    // Build the prompt
    const basePrompt = craftPrompts[craftType as keyof typeof craftPrompts] || craftPrompts["thu-cong"]
    const styleModifier = styleModifiers[style as keyof typeof styleModifiers] || styleModifiers["traditional"]

    const prompt = `Generate a detailed design for ${basePrompt}. ${styleModifier}. 
                    Include these elements: ${elements.join(", ")}. 
                    Additional details: ${description}. 
                    High quality, detailed texture, professional product photography style.`

    // Use node-fetch to make a request to the Puter API
    const { default: fetch } = await import("node-fetch")
    const response = await fetch("https://api.puter.com/v2/ai/txt2img", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: prompt,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to generate image with Puter API")
    }

    const data = await response.json()

    // Return the image URL
    return NextResponse.json({
      imageUrl: data.url || "/placeholder.svg?height=512&width=512",
      puterGenerated: true,
    })
  } catch (error) {
    console.error("Error generating design:", error)
    return NextResponse.json(
      {
        error: "Failed to generate design",
        imageUrl: "/placeholder.svg?height=512&width=512",
        fallback: true,
      },
      { status: 200 }, // Return 200 with fallback image instead of 500
    )
  }
}
