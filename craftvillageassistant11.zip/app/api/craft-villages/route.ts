import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Sample data to use when Supabase is not available
const sampleVillages = [
  {
    id: 1,
    name: "Làng gốm Bát Tràng",
    craftType: "Gốm sứ",
    description: "Làng gốm nổi tiếng với lịch sử hơn 700 năm, chuyên sản xuất đồ gốm sứ cao cấp.",
    latitude: 21.0157,
    longitude: 105.9131,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    name: "Làng lụa Vạn Phúc",
    craftType: "Dệt may",
    description: "Làng nghề dệt lụa truyền thống với các sản phẩm lụa cao cấp.",
    latitude: 20.9775,
    longitude: 105.7539,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    name: "Làng mây tre đan Phú Vinh",
    craftType: "Mây tre",
    description: "Làng nghề chuyên sản xuất các sản phẩm thủ công từ mây tre đan.",
    latitude: 20.8157,
    longitude: 105.7131,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 4,
    name: "Làng tranh Đông Hồ",
    craftType: "Tranh dân gian",
    description: "Làng nghề nổi tiếng với nghề làm tranh dân gian truyền thống.",
    latitude: 21.0785,
    longitude: 106.0842,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 5,
    name: "Làng sơn mài Hạ Thái",
    craftType: "Sơn mài",
    description: "Làng nghề chuyên sản xuất các sản phẩm sơn mài truyền thống.",
    latitude: 20.9557,
    longitude: 105.8231,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
]

// GET all craft villages
export async function GET() {
  try {
    // Check if Supabase is configured
    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn("Supabase not configured, returning sample data")
      return NextResponse.json(sampleVillages)
    }

    // Fetch craft villages from Supabase
    const { data, error } = await supabase
      .from("craft_villages")
      .select("id, name, craft_type as craftType, description, latitude, longitude, image_url as imageUrl")

    if (error) {
      console.error("Error fetching craft villages:", error)
      return NextResponse.json(sampleVillages)
    }

    // If no data, return sample data
    if (!data || data.length === 0) {
      return NextResponse.json(sampleVillages)
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error in craft villages API:", error)
    return NextResponse.json(sampleVillages)
  }
}

// CREATE a new craft village
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!supabaseUrl || !supabaseAnonKey) {
      return NextResponse.json({ error: "Supabase not configured" }, { status: 500 })
    }

    const body = await request.json()
    const { name, craftType, description, latitude, longitude, imageUrl } = body

    // Insert new craft village into Supabase
    const { data, error } = await supabase
      .from("craft_villages")
      .insert([
        {
          name,
          craft_type: craftType,
          description,
          latitude,
          longitude,
          image_url: imageUrl || "/placeholder.svg?height=200&width=300",
        },
      ])
      .select()

    if (error) {
      console.error("Error creating craft village:", error)
      return NextResponse.json({ error: "Failed to create craft village" }, { status: 500 })
    }

    return NextResponse.json(data[0])
  } catch (error) {
    console.error("Error in craft villages API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
