import { NextResponse } from "next/server"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

declare global {
  interface Window {
    puter?: {
      ai?: {
        chat?: (prompt: string, options?: any) => Promise<any>
      }
    }
  }
}

export async function POST(req: Request) {
  try {
    // Parse the request body
    const body = await req.json()
    const { prompt } = body

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Process with OpenAI API
    try {
      // You can implement your OpenAI API call here
      // For now, we'll return a simple response
      return NextResponse.json({
        content: `Response to: ${prompt}\n\nThis is a placeholder response from the AI API. In production, this would be a response from the OpenAI API.`,
      })
    } catch (error) {
      console.error("Error processing AI request:", error)
      return NextResponse.json({ error: "Failed to process AI request" }, { status: 500 })
    }
  } catch (error) {
    console.error("Error parsing request:", error)
    return NextResponse.json({ error: "Invalid request format" }, { status: 400 })
  }
}
