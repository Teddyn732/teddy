import { UserPreferences } from "@/components/user-preferences"
import { CraftFileManager } from "@/components/craft-file-manager"

export default function SettingsPage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold text-earth-800 mb-8">Cài đặt tài khoản</h1>

      <div className="grid grid-cols-1 gap-8 mb-8">
        <UserPreferences />
      </div>

      <h2 className="text-2xl font-bold text-earth-800 mb-4">Quản lý tệp</h2>
      <div className="grid grid-cols-1 gap-8">
        <CraftFileManager />
      </div>
    </div>
  )
}
