"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, Plus, Pencil, Trash2, MapPin } from "lucide-react"
import { CraftVillageMap } from "@/components/features/map/craft-village-map"

interface CraftVillage {
  id: number
  name: string
  craft_type: string
  description: string
  latitude: number
  longitude: number
  image_url: string
  created_at?: string
  updated_at?: string
}

export default function CraftVillagesPage() {
  const [villages, setVillages] = useState<CraftVillage[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [editingVillage, setEditingVillage] = useState<CraftVillage | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("list")
  const router = useRouter()

  // Form state
  const [formData, setFormData] = useState<Omit<CraftVillage, "id" | "created_at" | "updated_at">>({
    name: "",
    craft_type: "",
    description: "",
    latitude: 0,
    longitude: 0,
    image_url: "",
  })

  // Fetch craft villages
  useEffect(() => {
    async function fetchVillages() {
      try {
        setLoading(true)
        const response = await fetch("/api/craft-villages")

        if (!response.ok) {
          throw new Error(`Error: ${response.status}`)
        }

        const data = await response.json()
        setVillages(data)
      } catch (err) {
        setError("Không thể tải dữ liệu làng nghề. Vui lòng thử lại sau.")
        console.error("Error fetching villages:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchVillages()
  }, [])

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: name === "latitude" || name === "longitude" ? Number.parseFloat(value) || 0 : value,
    }))
  }

  // Open edit dialog
  const handleEdit = (village: CraftVillage) => {
    setEditingVillage(village)
    setFormData({
      name: village.name,
      craft_type: village.craft_type,
      description: village.description || "",
      latitude: village.latitude,
      longitude: village.longitude,
      image_url: village.image_url || "",
    })
    setIsDialogOpen(true)
  }

  // Open delete dialog
  const handleDeleteClick = (village: CraftVillage) => {
    setEditingVillage(village)
    setIsDeleteDialogOpen(true)
  }

  // Reset form
  const resetForm = () => {
    setFormData({
      name: "",
      craft_type: "",
      description: "",
      latitude: 0,
      longitude: 0,
      image_url: "",
    })
    setEditingVillage(null)
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const url = editingVillage ? `/api/craft-villages/${editingVillage.id}` : "/api/craft-villages"

      const method = editingVillage ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      // Refresh the list
      const refreshResponse = await fetch("/api/craft-villages")
      const refreshedData = await refreshResponse.json()
      setVillages(refreshedData)

      // Close dialog and reset form
      setIsDialogOpen(false)
      resetForm()
    } catch (err) {
      console.error("Error saving village:", err)
      setError("Không thể lưu dữ liệu làng nghề. Vui lòng thử lại sau.")
    } finally {
      setLoading(false)
    }
  }

  // Handle delete
  const handleDelete = async () => {
    if (!editingVillage) return

    setLoading(true)

    try {
      const response = await fetch(`/api/craft-villages/${editingVillage.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      // Remove from local state
      setVillages((prev) => prev.filter((v) => v.id !== editingVillage.id))

      // Close dialog
      setIsDeleteDialogOpen(false)
      setEditingVillage(null)
    } catch (err) {
      console.error("Error deleting village:", err)
      setError("Không thể xóa làng nghề. Vui lòng thử lại sau.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Quản lý làng nghề</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="list">Danh sách</TabsTrigger>
          <TabsTrigger value="map">Bản đồ</TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Danh sách làng nghề</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  onClick={() => {
                    resetForm()
                    setIsDialogOpen(true)
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Thêm làng nghề
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[550px]">
                <DialogHeader>
                  <DialogTitle>{editingVillage ? "Chỉnh sửa" : "Thêm"} làng nghề</DialogTitle>
                  <DialogDescription>Nhập thông tin chi tiết về làng nghề.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Tên làng nghề
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="col-span-3"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="craft_type" className="text-right">
                        Loại nghề
                      </Label>
                      <Input
                        id="craft_type"
                        name="craft_type"
                        value={formData.craft_type}
                        onChange={handleInputChange}
                        className="col-span-3"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="description" className="text-right">
                        Mô tả
                      </Label>
                      <Textarea
                        id="description"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        className="col-span-3"
                        rows={3}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="latitude" className="text-right">
                        Vĩ độ
                      </Label>
                      <Input
                        id="latitude"
                        name="latitude"
                        type="number"
                        step="any"
                        value={formData.latitude}
                        onChange={handleInputChange}
                        className="col-span-3"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="longitude" className="text-right">
                        Kinh độ
                      </Label>
                      <Input
                        id="longitude"
                        name="longitude"
                        type="number"
                        step="any"
                        value={formData.longitude}
                        onChange={handleInputChange}
                        className="col-span-3"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="image_url" className="text-right">
                        URL hình ảnh
                      </Label>
                      <Input
                        id="image_url"
                        name="image_url"
                        value={formData.image_url}
                        onChange={handleInputChange}
                        className="col-span-3"
                        placeholder="/placeholder.svg?height=200&width=300"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={loading}>
                      {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      {editingVillage ? "Cập nhật" : "Thêm"} làng nghề
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
              <span className="block sm:inline">{error}</span>
            </div>
          )}

          {loading && !villages.length ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Tên làng nghề</TableHead>
                      <TableHead>Loại nghề</TableHead>
                      <TableHead>Vị trí</TableHead>
                      <TableHead className="text-right">Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {villages.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center">
                          Không có dữ liệu làng nghề
                        </TableCell>
                      </TableRow>
                    ) : (
                      villages.map((village) => (
                        <TableRow key={village.id}>
                          <TableCell className="font-medium">{village.id}</TableCell>
                          <TableCell>{village.name}</TableCell>
                          <TableCell>{village.craft_type}</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">
                                {village.latitude.toFixed(4)}, {village.longitude.toFixed(4)}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="sm" onClick={() => handleEdit(village)}>
                                <Pencil className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                              <Button variant="outline" size="sm" onClick={() => handleDeleteClick(village)}>
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="map">
          <Card>
            <CardHeader>
              <CardTitle>Bản đồ làng nghề</CardTitle>
              <CardDescription>Xem vị trí các làng nghề trên bản đồ</CardDescription>
            </CardHeader>
            <CardContent>
              <CraftVillageMap />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete confirmation dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Xác nhận xóa</AlertDialogTitle>
            <AlertDialogDescription>
              Bạn có chắc chắn muốn xóa làng nghề "{editingVillage?.name}"? Hành động này không thể hoàn tác.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Hủy</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Xóa
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
