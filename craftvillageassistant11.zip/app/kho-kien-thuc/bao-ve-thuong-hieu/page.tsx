"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, Printer, Share2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function BaoVeThuongHieuPage() {
  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-white border-b border-earth-200 py-3 px-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5 text-earth-700" />
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="Làng Nghề Việt Logo" className="h-8 w-8" />
              <h1 className="text-xl font-bold text-earth-900">Làng Nghề Việt</h1>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Printer className="h-4 w-4" />
              <span className="hidden md:inline">In tài liệu</span>
            </Button>
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Download className="h-4 w-4" />
              <span className="hidden md:inline">Tải xuống</span>
            </Button>
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Share2 className="h-4 w-4" />
              <span className="hidden md:inline">Chia sẻ</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <aside className="w-full md:w-64 shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-earth-100 p-4 sticky top-4">
              <h3 className="font-bold text-earth-900 mb-4 text-lg">Mục lục</h3>
              <nav className="space-y-1">
                <Link
                  href="#gioi-thieu"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Giới thiệu
                </Link>
                <Link
                  href="#tinh-hinh"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Tình hình xâm phạm thương hiệu
                </Link>
                <Link
                  href="#rao-can"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Rào cản chống xâm phạm
                </Link>
                <Link
                  href="#dang-ky"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đăng ký xác lập quyền SHCN
                </Link>
                <Link
                  href="#giai-quyet"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Giải quyết khi bị xâm phạm
                </Link>
              </nav>
            </div>
          </aside>

          <main className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-earth-100 p-6 md:p-8">
              <h1 className="text-3xl font-bold text-earth-900 mb-6">BẢO VỆ VÀ KHAI THÁC THƯƠNG HIỆU</h1>

              <Tabs defaultValue="noi-dung">
                <TabsList className="mb-6">
                  <TabsTrigger value="noi-dung">Nội dung</TabsTrigger>
                  <TabsTrigger value="bai-tap">Bài tập thực hành</TabsTrigger>
                  <TabsTrigger value="tai-lieu">Tài liệu tham khảo</TabsTrigger>
                </TabsList>

                <TabsContent value="noi-dung" className="learning-content">
                  <section id="gioi-thieu" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Nội dung</h2>
                    <ol className="list-decimal pl-6 space-y-2 mb-4">
                      <li>Tình hình xâm phạm thương hiệu tại Việt Nam</li>
                      <li>Rào cản chống xâm phạm thương hiệu</li>
                      <li>Đăng ký xác lập quyền SHCN</li>
                      <li>Giải quyết, đối phó khi quyền SHCN bị xâm phạm</li>
                    </ol>
                  </section>

                  <section id="tinh-hinh" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">
                      Tình hình xâm phạm thương hiệu tại Việt Nam
                    </h2>

                    <p className="mb-4">
                      Các công ty Việt Nam, thường hay lơ là trong đăng ký bảo hộ thương hiệu của mình, đưa đến các bất
                      lợi như mất thương hiệu, quyền sử dụng thương hiệu bị xâm phạm trên thị trường quốc tế.
                    </p>

                    <p className="mb-4">
                      Theo thống kê của Trung tâm nghiên cứu và phát triển truyền thông khoa học và công nghệ (CESTC),
                      các lực lượng chức năng đã xử lý tới 1.460 vụ xâm phạm quyền sở hữu trí tuệ trong năm 2020.
                    </p>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Một số vụ việc điển hình</h3>

                      <div className="mb-4">
                        <h4 className="font-bold text-earth-700">Nước mắm Phú Quốc</h4>
                        <p className="text-earth-700 mb-2">
                          Công ty Viet Huong Fish sauce, Hoa Kỳ (có trụ sở tại Hoa Kỳ), được cơ quan đăng ký nhãn hiệu
                          Hoa Kỳ cấp nhãn hiệu nước mắm Phú Quốc từ năm 1982. Trên các sản phẩm nước mắm của công ty này
                          từ năm 1982 tới nay sử dụng nhãn hiệu "Nước mắm Phú Quốc" có hình bản đồ VN và đảo Phú Quốc.
                        </p>
                      </div>

                      <div className="mb-4">
                        <h4 className="font-bold text-earth-700">Cà phê Buôn Ma Thuột và Đắk Lắk</h4>
                        <p className="text-earth-700 mb-2">
                          Chỉ dẫn địa lý cà phê Buôn Ma Thuột đã bị Cty Guangzhou Buon Ma Thuot Coffee Co., Ltd có văn
                          phòng đặt tại Quảng Châu (Quảng Đông, Trung Quốc), đăng ký độc quyền nhãn hiệu thời hạn 10
                          năm, bắt đầu từ 2010 và 2011 cho một số loại sản phẩm trên toàn lãnh thổ Trung Quốc.
                        </p>
                      </div>

                      <div className="mb-4">
                        <h4 className="font-bold text-earth-700">Kẹo dừa Bến Tre</h4>
                        <p className="text-earth-700 mb-2">
                          Năm 1998, khi đang có doanh số tiêu thụ tại thị trường Trung Quốc rất cao, nhãn hiệu kẹo dừa
                          Bến Tre của bà Nguyễn Thị Tỏ (tức Hai Tỏ) bỗng sụt giảm nghiêm trọng. Qua dò hỏi bà được biết
                          trên thị trường đang có sản phẩm kẹo dừa giả, nhái kẹo dừa Bến Tre.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-bold text-earth-700">Cà phê Trung Nguyên</h4>
                        <p className="text-earth-700 mb-2">
                          Tháng 7/2000, Thương hiệu cà phê Trung Nguyên – thương hiệu được đánh giá là nổi bật nhất của
                          cà phê Việt Nam đã bị một công ty của Mỹ là Rice Field nhanh chân đăng ký trước tại Cơ quan
                          Sáng chế và Nhãn hiệu Hoa Kỳ (USPTO).
                        </p>
                      </div>
                    </div>
                  </section>

                  <section id="rao-can" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Rào cản chống xâm phạm thương hiệu</h2>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <img
                        src="/images/brand-protection-barriers.png"
                        alt="Rào cản chống xâm phạm thương hiệu"
                        className="w-full max-w-md mx-auto my-4"
                      />

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">1. Rào cản kỹ thuật</h3>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Tạo rào cản kỹ thuật bên ngoài</li>
                            <li>Tạo rào cản kỹ thuật - hình ảnh thương hiệu</li>
                          </ul>
                          <p className="mt-3 text-earth-700">
                            Chú trọng tính độc đáo, khác biệt khi thiết kế các hệ thống các yếu tố thương hiệu: Tên,
                            logo, slogan độc đáo, khó trùng lặp.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">2. Rào cản kinh tế - tâm lý</h3>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Mở rộng hệ thống phân phối và bán lẻ hàng hóa</li>
                            <li>Quản lý, xây dựng tốt mối quan hệ với các đại lý, cửa hàng bán lẻ</li>
                            <li>Xây dựng và duy trì lòng trung thành đối với thương hiệu</li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">3. Rào cản pháp lý</h3>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Đăng ký để được pháp luật bảo hộ độc quyền quyền SHCN theo qui định</li>
                            <li>Đăng ký sớm</li>
                            <li>Đăng ký rộng</li>
                            <li>Đăng ký dự phòng</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section id="dang-ky" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đăng ký xác lập quyền SHCN</h2>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Đối tượng được bảo hộ</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Nhãn hiệu hàng hóa</li>
                        <li>Kiểu dáng công nghiệp</li>
                        <li>Sáng chế</li>
                        <li>Giải pháp hữu ích</li>
                        <li>Tên gọi xuất xứ hàng hóa</li>
                        <li>Chỉ dẫn địa lý</li>
                        <li>Tên thương mại</li>
                      </ul>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Thời gian bảo hộ</h3>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="bg-earth-100">
                              <th className="border border-earth-200 p-2 text-left">Yếu tố</th>
                              <th className="border border-earth-200 p-2 text-left">Thời gian bảo hộ</th>
                              <th className="border border-earth-200 p-2 text-left">Số lần được gia hạn</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td className="border border-earth-200 p-2">Nhãn hiệu hàng hóa</td>
                              <td className="border border-earth-200 p-2">10 năm</td>
                              <td className="border border-earth-200 p-2">Nhiều lần</td>
                            </tr>
                            <tr>
                              <td className="border border-earth-200 p-2">Kiểu dáng công nghiệp</td>
                              <td className="border border-earth-200 p-2">5 năm</td>
                              <td className="border border-earth-200 p-2">2 lần</td>
                            </tr>
                            <tr>
                              <td className="border border-earth-200 p-2">Sáng chế</td>
                              <td className="border border-earth-200 p-2">20 năm</td>
                              <td className="border border-earth-200 p-2">Không gia hạn</td>
                            </tr>
                            <tr>
                              <td className="border border-earth-200 p-2">Giải pháp hữu ích</td>
                              <td className="border border-earth-200 p-2">10 năm</td>
                              <td className="border border-earth-200 p-2">Không gia hạn</td>
                            </tr>
                            <tr>
                              <td className="border border-earth-200 p-2">Tên gọi xuất xứ hàng hóa</td>
                              <td className="border border-earth-200 p-2">10 năm</td>
                              <td className="border border-earth-200 p-2">Nhiều lần</td>
                            </tr>
                            <tr>
                              <td className="border border-earth-200 p-2">Chỉ dẫn địa lý</td>
                              <td className="border border-earth-200 p-2">Vĩnh viễn</td>
                              <td className="border border-earth-200 p-2"></td>
                            </tr>
                            <tr>
                              <td className="border border-earth-200 p-2">Tên thương mại</td>
                              <td className="border border-earth-200 p-2">Suốt thời gian hoạt động của DN</td>
                              <td className="border border-earth-200 p-2"></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Nguyên tắc khi xem xét bảo hộ</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Có đăng ký, được cấp văn bằng thì mới được pháp luật của nước sở tại bảo hộ</li>
                        <li>Đăng ký ở đâu thì chỉ được bảo hộ ở đó</li>
                        <li>
                          Muốn được bảo hộ thì phải có tính mới, độc đáo, khác biệt hẳn với những đặc tính của các SP/DV
                          cùng loại trên thị trường
                        </li>
                        <li>Ai đăng ký trước thì được ưu tiên trước</li>
                        <li>Nhà nước có quyền từ chối đơn, nếu thấy không hợp lệ</li>
                        <li>Nhà nước chỉ bảo hộ những gì đã đăng ký xin bảo hộ</li>
                      </ul>
                      <p className="font-medium mt-3 text-earth-700">Đăng ký sớm, đăng ký rộng, đăng ký dự phòng</p>
                    </div>
                  </section>

                  <section id="giai-quyet" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">
                      Giải quyết, đối phó khi quyền SHCN bị xâm phạm
                    </h2>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Các hình thức tranh chấp - vi phạm</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <h4 className="font-bold text-earth-700 mb-2">Tranh chấp quyền sở hữu</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Trong quá trình xem xét đơn</li>
                            <li>Sau khi 1 hoặc nhiều DN đã được cấp VB bảo hộ</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-700 mb-2">Vi phạm quyền sử dụng</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Hàng nhái, hàng giả</li>
                            <li>
                              Hàng có chất lượng tương đương và mẫu mã giống như mặt hàng của một cơ sở đã đăng ký
                            </li>
                            <li>Hàng mang nhãn hiệu cùng với mặt hàng đã đăng ký nhưng chất lượng thấp hơn</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-700 mb-2">Vi phạm quyền định đoạt</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Không có hợp đồng chuyển nhượng, chuyển giao</li>
                            <li>Không tuân thủ các điều khoản của hợp đồng</li>
                            <li>
                              Lợi dụng sơ hở, bên được chuyển giao/ủy quyền đi đăng ký để chiếm quyền sở hữu của chủ SH
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Hình thức xử lý vi phạm</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <h4 className="font-bold text-earth-700 mb-2">Các biện pháp hành chính</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Thanh tra, kiểm tra</li>
                            <li>Cảnh cáo hoặc phạt tiền</li>
                            <li>Tước quyền sử dụng giấy phép kinh doanh</li>
                            <li>Tịch thu tang vật, phương tiện vi phạm</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-700 mb-2">Các chế tài dân sự</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Chấm dứt hành vi vi phạm</li>
                            <li>Bồi thường thiệt hại</li>
                            <li>Cải chính</li>
                            <li>Xin lỗi công khai</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-700 mb-2">Các chế tài hình sự</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Phạt tiền</li>
                            <li>Cải tạo không giam giữ</li>
                            <li>Phạt tù</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200">
                      <h3 className="font-bold text-earth-800 mb-3">Biện pháp xử lý khi bị vi phạm</h3>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>
                          <span className="font-medium">Tha thứ cho hành vi vi phạm:</span> nếu tỉ lệ thiệt hại về thu
                          nhập bán hàng hoặc lợi nhuận không đáng kể, không có chiều hướng gia tăng, và việc vi phạm
                          không ảnh hưởng đến uy tín của DN.
                        </li>
                        <li>
                          <span className="font-medium">Gởi thư cảnh báo:</span> nếu hành vi vi phạm là không cố ý
                          (trong một số trường hợp, việc cảnh báo lại tạo cơ hội cho họ có thời gian che giấu, hủy bỏ
                          chứng cứ).
                        </li>
                        <li>
                          <span className="font-medium">Đưa ra các giải pháp thương lượng:</span> giải quyết tranh chấp
                          bằng con đường trọng tài, hòa giải.
                        </li>
                        <li>
                          <span className="font-medium">Giải quyết bằng các biện pháp hành chánh.</span>
                        </li>
                        <li>
                          <span className="font-medium">Đưa vụ kiện ra Tòa:</span> hoặc các văn phòng SHTT có thẩm quyền
                          của chính quyền địa phương.
                        </li>
                      </ol>
                    </div>
                  </section>
                </TabsContent>

                <TabsContent value="bai-tap">
                  <div className="learning-content">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Bài tập thực hành</h2>
                    <p className="mb-4">
                      Hãy chọn một thương hiệu làng nghề truyền thống Việt Nam và thực hiện các yêu cầu sau:
                    </p>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">
                        Yêu cầu 1: Phân tích nguy cơ xâm phạm thương hiệu
                      </h3>
                      <p className="mb-3">
                        Phân tích các nguy cơ xâm phạm thương hiệu mà làng nghề đã chọn có thể gặp phải:
                      </p>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>Nguy cơ tranh chấp quyền sở hữu</li>
                        <li>Nguy cơ vi phạm quyền sử dụng (hàng nhái, hàng giả)</li>
                        <li>Nguy cơ vi phạm quyền định đoạt</li>
                      </ol>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu 2: Đề xuất biện pháp bảo vệ thương hiệu</h3>
                      <p className="mb-3">Đề xuất các biện pháp bảo vệ thương hiệu cho làng nghề đã chọn, bao gồm:</p>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>Rào cản kỹ thuật</li>
                        <li>Rào cản kinh tế - tâm lý</li>
                        <li>Rào cản pháp lý</li>
                      </ol>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">
                        Yêu cầu 3: Lập kế hoạch đăng ký bảo hộ thương hiệu
                      </h3>
                      <p className="mb-3">Lập kế hoạch đăng ký bảo hộ thương hiệu cho làng nghề đã chọn, bao gồm:</p>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>Xác định đối tượng cần bảo hộ</li>
                        <li>Quy trình đăng ký bảo hộ</li>
                        <li>Chi phí và thời gian dự kiến</li>
                        <li>Phạm vi bảo hộ (trong nước và quốc tế)</li>
                      </ol>
                    </div>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu nộp bài</h3>
                      <p>
                        Hãy thực hiện các yêu cầu trên và nộp bài dưới dạng file PowerPoint hoặc PDF qua hệ thống học
                        tập trực tuyến trước ngày 30/06/2025.
                      </p>
                      <Button className="bg-terracotta hover:bg-terracotta-600 text-white mt-4">Tải mẫu báo cáo</Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="tai-lieu">
                  <div className="learning-content">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Tài liệu tham khảo</h2>
                    <ul className="list-disc pl-6 space-y-3">
                      <li>Luật Sở hữu trí tuệ số 50/2005/QH11 ngày 29/11/2005 của Quốc hội.</li>
                      <li>
                        Luật sửa đổi, bổ sung một số điều của Luật Sở hữu trí tuệ số 36/2009/QH12 ngày 19/6/2009 của
                        Quốc hội.
                      </li>
                      <li>
                        Nghị định số 103/2006/NĐ-CP ngày 22/9/2006 của Chính phủ quy định chi tiết và hướng dẫn thi hành
                        một số điều của Luật Sở hữu trí tuệ về sở hữu công nghiệp.
                      </li>
                      <li>
                        Nghị định số 105/2006/NĐ-CP ngày 22/9/2006 của Chính phủ quy định chi tiết và hướng dẫn thi hành
                        một số điều của Luật Sở hữu trí tuệ về bảo vệ quyền sở hữu trí tuệ và quản lý nhà nước về sở hữu
                        trí tuệ.
                      </li>
                      <li>
                        Nghị định số 106/2006/NĐ-CP ngày 22/9/2006 của Chính phủ quy định xử phạt vi phạm hành chính về
                        sở hữu công nghiệp.
                      </li>
                    </ul>

                    <div className="mt-8">
                      <h3 className="font-bold text-earth-800 mb-3">Tài liệu bổ sung</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Bài giảng Bảo vệ thương hiệu</p>
                            <p className="text-sm text-earth-600">PDF - 3.5MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Hướng dẫn đăng ký bảo hộ thương hiệu</p>
                            <p className="text-sm text-earth-600">PDF - 2.3MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Mẫu đơn đăng ký nhãn hiệu</p>
                            <p className="text-sm text-earth-600">DOCX - 0.5MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Biểu phí đăng ký bảo hộ SHTT</p>
                            <p className="text-sm text-earth-600">PDF - 0.8MB</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
