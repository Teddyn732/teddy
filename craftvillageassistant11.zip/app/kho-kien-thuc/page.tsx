import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, BookOpen, FileText, Shield, BarChart } from "lucide-react"

export default function KhoKienThucPage() {
  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-white border-b border-earth-200 py-3 px-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5 text-earth-700" />
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="Làng Nghề Việt Logo" className="h-8 w-8" />
              <h1 className="text-xl font-bold text-earth-900">Làng Nghề Việt</h1>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="border-earth-600 text-earth-700">
              Tìm kiếm
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-earth-900 mb-6">Kho kiến thức</h1>
        <p className="text-lg text-earth-700 mb-8 max-w-3xl">
          Tài liệu hướng dẫn và kiến thức chuyên sâu về xây dựng, phát triển và bảo vệ thương hiệu cho các làng nghề
          truyền thống Việt Nam.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Link href="/kho-kien-thuc/xay-dung-thuong-hieu" className="block">
            <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-earth-100 h-full">
              <div className="h-48 bg-earth-100 flex items-center justify-center">
                <BookOpen className="h-16 w-16 text-terracotta" />
              </div>
              <div className="p-6">
                <h2 className="text-xl font-bold text-earth-900 mb-2">Xây dựng đặc tính thương hiệu</h2>
                <p className="text-earth-700 mb-4">
                  Hướng dẫn quy trình xây dựng thương hiệu, định vị thương hiệu, đặc tính thương hiệu và hình ảnh thương
                  hiệu.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-earth-600">3 bài học</span>
                  <Button variant="ghost" className="text-terracotta hover:text-terracotta-600 p-0">
                    Xem chi tiết
                  </Button>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/kho-kien-thuc/do-luong-thuong-hieu" className="block">
            <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-earth-100 h-full">
              <div className="h-48 bg-earth-100 flex items-center justify-center">
                <BarChart className="h-16 w-16 text-terracotta" />
              </div>
              <div className="p-6">
                <h2 className="text-xl font-bold text-earth-900 mb-2">Đo lường thương hiệu</h2>
                <p className="text-earth-700 mb-4">
                  Phương pháp đo lường sức khỏe thương hiệu, nhận biết, liên tưởng, chất lượng cảm nhận và mức độ trung
                  thành.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-earth-600">5 bài học</span>
                  <Button variant="ghost" className="text-terracotta hover:text-terracotta-600 p-0">
                    Xem chi tiết
                  </Button>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/kho-kien-thuc/bao-ve-thuong-hieu" className="block">
            <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-earth-100 h-full">
              <div className="h-48 bg-earth-100 flex items-center justify-center">
                <Shield className="h-16 w-16 text-terracotta" />
              </div>
              <div className="p-6">
                <h2 className="text-xl font-bold text-earth-900 mb-2">Bảo vệ và khai thác thương hiệu</h2>
                <p className="text-earth-700 mb-4">
                  Hướng dẫn đăng ký bảo hộ thương hiệu, rào cản chống xâm phạm và giải quyết khi quyền SHCN bị xâm phạm.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-earth-600">4 bài học</span>
                  <Button variant="ghost" className="text-terracotta hover:text-terracotta-600 p-0">
                    Xem chi tiết
                  </Button>
                </div>
              </div>
            </div>
          </Link>
        </div>

        <h2 className="text-2xl font-bold text-earth-900 mb-4">Tài liệu mới nhất</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {[1, 2, 3, 4].map((item) => (
            <div
              key={item}
              className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-earth-100"
            >
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <FileText className="h-6 w-6 text-terracotta" />
                  <h3 className="font-bold text-earth-800">Hướng dẫn đăng ký nhãn hiệu</h3>
                </div>
                <p className="text-earth-700 text-sm mb-3">
                  Quy trình và thủ tục đăng ký bảo hộ nhãn hiệu hàng hóa tại Việt Nam và quốc tế.
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-earth-600">Cập nhật: 15/05/2025</span>
                  <Button variant="ghost" size="sm" className="text-terracotta hover:text-terracotta-600 p-0">
                    Tải xuống
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <h2 className="text-2xl font-bold text-earth-900 mb-4">Khóa học trực tuyến</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-earth-100">
            <div className="h-48 bg-earth-100 flex items-center justify-center">
              <img
                src="/images/online-course-1.jpg"
                alt="Khóa học xây dựng thương hiệu"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-earth-900 mb-2">
                Xây dựng thương hiệu làng nghề trong kỷ nguyên số
              </h3>
              <p className="text-earth-700 mb-4">
                Khóa học 8 tuần giúp các làng nghề truyền thống xây dựng và phát triển thương hiệu trong thời đại số.
              </p>
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-sm text-earth-600 block">Thời lượng: 24 giờ</span>
                  <span className="text-sm text-earth-600 block">Khai giảng: 01/07/2025</span>
                </div>
                <Button className="bg-terracotta hover:bg-terracotta-600 text-white">Đăng ký</Button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-earth-100">
            <div className="h-48 bg-earth-100 flex items-center justify-center">
              <img
                src="/images/online-course-2.jpg"
                alt="Khóa học marketing số"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-earth-900 mb-2">Marketing số cho sản phẩm làng nghề</h3>
              <p className="text-earth-700 mb-4">
                Học cách tiếp thị sản phẩm làng nghề trên các nền tảng số như Facebook, TikTok và các sàn thương mại
                điện tử.
              </p>
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-sm text-earth-600 block">Thời lượng: 16 giờ</span>
                  <span className="text-sm text-earth-600 block">Khai giảng: 15/07/2025</span>
                </div>
                <Button className="bg-terracotta hover:bg-terracotta-600 text-white">Đăng ký</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
