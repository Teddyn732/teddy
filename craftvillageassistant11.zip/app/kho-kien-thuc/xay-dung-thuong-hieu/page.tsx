"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, Printer, Share2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function XayDungThuongHieuPage() {
  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-white border-b border-earth-200 py-3 px-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5 text-earth-700" />
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="Làng Nghề Việt Logo" className="h-8 w-8" />
              <h1 className="text-xl font-bold text-earth-900">Làng Nghề Việt</h1>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Printer className="h-4 w-4" />
              <span className="hidden md:inline">In tài liệu</span>
            </Button>
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Download className="h-4 w-4" />
              <span className="hidden md:inline">Tải xuống</span>
            </Button>
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Share2 className="h-4 w-4" />
              <span className="hidden md:inline">Chia sẻ</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <aside className="w-full md:w-64 shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-earth-100 p-4 sticky top-4">
              <h3 className="font-bold text-earth-900 mb-4 text-lg">Mục lục</h3>
              <nav className="space-y-1">
                <Link
                  href="#gioi-thieu"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Giới thiệu
                </Link>
                <Link
                  href="#thuc-trang"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Thực trạng xây dựng thương hiệu ở Việt Nam
                </Link>
                <Link
                  href="#quy-trinh"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Quy trình xây dựng thương hiệu
                </Link>
                <Link
                  href="#dinh-vi"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Định vị thương hiệu
                </Link>
                <Link
                  href="#dac-tinh"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đặc tính thương hiệu
                </Link>
                <Link
                  href="#hinh-anh"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Hình ảnh thương hiệu
                </Link>
              </nav>
            </div>
          </aside>

          <main className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-earth-100 p-6 md:p-8">
              <h1 className="text-3xl font-bold text-earth-900 mb-6">XÂY DỰNG ĐẶC TÍNH THƯƠNG HIỆU</h1>

              <Tabs defaultValue="noi-dung">
                <TabsList className="mb-6">
                  <TabsTrigger value="noi-dung">Nội dung</TabsTrigger>
                  <TabsTrigger value="bai-tap">Bài tập thực hành</TabsTrigger>
                  <TabsTrigger value="tai-lieu">Tài liệu tham khảo</TabsTrigger>
                </TabsList>

                <TabsContent value="noi-dung" className="learning-content">
                  <section id="gioi-thieu" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Nội dung</h2>
                    <ol className="list-decimal pl-6 space-y-2 mb-4">
                      <li>Thực trạng xây dựng thương hiệu ở Việt Nam</li>
                      <li>Quy trình xây dựng thương hiệu</li>
                      <li>Định vị thương hiệu, đặc tính thương hiệu, hình ảnh thương hiệu</li>
                    </ol>
                  </section>

                  <section id="thuc-trang" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">
                      Thực trạng xây dựng thương hiệu ở Việt Nam
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div className="bg-earth-50 p-4 rounded-lg border border-earth-100">
                        <h3 className="font-bold text-earth-800 mb-3">Thực trạng doanh nghiệp</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="font-bold text-terracotta">16%</span>
                            <span>Có bộ phận chuyên trách về Marketing</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="font-bold text-terracotta">74%</span>
                            <span>DN đầu tư dưới 5% doanh số cho việc xây dựng và phát triển thương hiệu</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="font-bold text-terracotta">20%</span>
                            <span>DN không hề chi cho việc xây dựng thương hiệu</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="font-bold text-terracotta">80%</span>
                            <span>DN không có chức danh quản lý nhãn hiệu</span>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-earth-50 p-4 rounded-lg border border-earth-100">
                        <h3 className="font-bold text-earth-800 mb-3">Quan niệm sai lầm</h3>
                        <ul className="list-disc pl-6 space-y-1">
                          <li>Thương hiệu chỉ là logo đẹp mắt</li>
                          <li>Xây dựng thương hiệu là quảng cáo và PR</li>
                          <li>Muốn xây dựng thương hiệu phải có rất nhiều tiền và trong thời gian ngắn</li>
                          <li>Cứ giá rẻ chất lượng cao là bán được hàng</li>
                          <li>Nghiên cứu thị trường không quan trọng</li>
                          <li>Thương hiệu Việt luôn luôn phải đặt tên thuần Việt</li>
                        </ul>
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Khó khăn của DN trong xây dựng thương hiệu</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <ul className="space-y-2">
                            <li className="flex items-start gap-2">
                              <span className="font-bold text-terracotta">23%</span>
                              <span>Tài chính</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="font-bold text-terracotta">19%</span>
                              <span>Nguồn nhân lực</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="font-bold text-terracotta">11.8%</span>
                              <span>Xây dựng chiến lược và cách thực hiện</span>
                            </li>
                          </ul>
                        </div>
                        <div>
                          <ul className="space-y-2">
                            <li className="flex items-start gap-2">
                              <span className="font-bold text-terracotta">8%</span>
                              <span>Nạn hàng giả và vi phạm bản quyền</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="font-bold text-terracotta">14%</span>
                              <span>Cơ chế chính sách, thủ tục</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <span className="font-bold text-terracotta">6.3%</span>
                              <span>Giá dịch vụ</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section id="quy-trinh" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Quy trình xây dựng thương hiệu</h2>

                    <div className="bg-white p-6 rounded-lg border border-earth-200 mb-6">
                      <img
                        src="/images/brand-building-process.png"
                        alt="Quy trình xây dựng thương hiệu"
                        className="w-full max-w-3xl mx-auto my-4"
                      />

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">Phân tích khách hàng</h3>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Xu hướng tiêu dùng</li>
                            <li>Động cơ mua sắm</li>
                            <li>Những nhu cầu chưa được thoả mãn</li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">Phân tích cạnh tranh</h3>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Đặc tính và hình ảnh thương hiệu</li>
                            <li>Điểm mạnh, điểm yếu</li>
                            <li>Chiến lược</li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">Phân tích doanh nghiệp</h3>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Hình ảnh thương hiệu hiện tại</li>
                            <li>Sự kế thừa thương hiệu hiện tại</li>
                            <li>Điểm mạnh, điểm yếu, năng lực của tổ chức</li>
                            <li>Các giá trị của tổ chức</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section id="dinh-vi" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">
                      Định vị thương hiệu, đặc tính thương hiệu, hình ảnh thương hiệu
                    </h2>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <img
                        src="/images/brand-positioning.png"
                        alt="Mối quan hệ giữa định vị, đặc tính và hình ảnh thương hiệu"
                        className="w-full max-w-2xl mx-auto my-4"
                      />

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">Định vị thương hiệu</h3>
                          <p className="text-earth-700">
                            Thiết kế các lợi ích (chức năng và hình ảnh) mà thương hiệu sẽ đem đến cho khách hàng sao
                            cho thương hiệu có thể chiếm một vị trí khác biệt và có giá trị trong tâm trí khách hàng mục
                            tiêu.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">Đặc tính thương hiệu</h3>
                          <p className="text-earth-700">
                            Cách thức mà doanh nghiệp mong muốn mọi người nhận thức về thương hiệu của mình một cách
                            nhất quán, khác biệt và nổi trội hơn các thương hiệu cạnh tranh.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-bold text-earth-800 mb-3">Hình ảnh thương hiệu</h3>
                          <p className="text-earth-700">
                            Cách thức mà người tiêu dùng thực tế nhận thức về một thương hiệu.
                          </p>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section id="dac-tinh" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đặc tính thương hiệu</h2>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <p className="mb-4">
                        Đặc tính thương hiệu là một tập hợp duy nhất các liên kết thuộc tính mà các nhà chiến lược
                        thương hiệu mong muốn tạo ra và duy trì trong tâm trí người tiêu dùng. Đây là đặc điểm nhận
                        dạng, giúp người tiêu dùng phân biệt được các thương hiệu khác nhau (mặc dù cùng một chủng loại
                        sản phẩm).
                      </p>
                      <p>
                        Đặc tính thương hiệu phản ánh cái mà thương hiệu hướng tới và là sự cam kết của nhà sản xuất với
                        khách hàng. Nó được sử dụng như một chuẩn mực cho chiến lược xây dựng thương hiệu trong dài hạn.
                      </p>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Bốn khía cạnh tạo nên đặc tính thương hiệu</h3>
                      <img
                        src="/images/brand-identity-prism.png"
                        alt="Bốn khía cạnh tạo nên đặc tính thương hiệu"
                        className="w-full max-w-2xl mx-auto my-4"
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                        <div>
                          <h4 className="font-bold text-earth-800 mb-2">1. Thương hiệu là sản phẩm</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Phạm vi sản phẩm</li>
                            <li>Thuộc tính sản phẩm</li>
                            <li>Chất lượng/giá trị</li>
                            <li>Tính hữu dụng</li>
                            <li>Người sử dụng</li>
                            <li>Nguồn gốc xuất xứ</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-800 mb-2">2. Thương hiệu là tổ chức</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Đặc tính tổ chức</li>
                            <li>Tính toàn cầu/tính địa phương</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-800 mb-2">3. Thương hiệu là con người</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Cá tính</li>
                            <li>Mối quan hệ giữa thương hiệu và khách hàng</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-bold text-earth-800 mb-2">4. Thương hiệu là biểu tượng</h4>
                          <ul className="list-disc pl-6 space-y-1">
                            <li>Biểu tượng hữu hình/biểu tượng ẩn dụ</li>
                            <li>Di sản thương hiệu</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Tuyên ngôn về bản chất thương hiệu</h3>
                      <p className="mb-4">
                        Bản chất thương hiệu, tinh thần hay lời hứa hẹn của thương hiệu phải được khẳng định một cách
                        ngắn gọn trong vòng từ 3 cho đến 5 từ (tuyên ngôn về bản chất của thương hiệu - brand
                        essence/brand mantra).
                      </p>
                      <p>Một tuyên ngôn tốt về bản chất của thương hiệu có thể gồm 3 thành phần:</p>
                      <ul className="list-disc pl-6 space-y-2 mt-3">
                        <li>
                          Thành phần chức năng: mô tả bản chất tự nhiên của sản phẩm dịch vụ hoặc loại ích lợi mà thương
                          hiệu cung cấp
                        </li>
                        <li>Thành phần điều chỉnh về mặt mô tả: chỉ ra ranh giới giới hạn hoạt động của thương hiệu</li>
                        <li>
                          Thành phần điều chỉnh cảm xúc: chỉ ra thương hiệu sẽ tạo ra lợi ích như thế nào và bằng cách
                          nào
                        </li>
                      </ul>
                    </div>
                  </section>

                  <section id="hinh-anh" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Hình ảnh thương hiệu</h2>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <p className="mb-4">
                        Hình ảnh thương hiệu là cách thức mà người tiêu dùng thực tế nhận thức về một thương hiệu. Đây
                        là kết quả của tất cả các hoạt động marketing và truyền thông của doanh nghiệp, cũng như các yếu
                        tố khác ngoài tầm kiểm soát như truyền miệng, báo chí, v.v.
                      </p>
                      <p className="mb-4">Sự khác biệt giữa đặc tính thương hiệu và hình ảnh thương hiệu:</p>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Đặc tính thương hiệu: Cách doanh nghiệp muốn khách hàng nhìn nhận về thương hiệu</li>
                        <li>Hình ảnh thương hiệu: Cách khách hàng thực sự nhìn nhận về thương hiệu</li>
                      </ul>

                      <div className="mt-6">
                        <h3 className="font-bold text-earth-800 mb-3">Các yếu tố ảnh hưởng đến hình ảnh thương hiệu</h3>
                        <ul className="list-disc pl-6 space-y-2">
                          <li>Chất lượng sản phẩm/dịch vụ</li>
                          <li>Truyền thông marketing</li>
                          <li>Trải nghiệm khách hàng</li>
                          <li>Truyền miệng</li>
                          <li>Các yếu tố môi trường</li>
                          <li>Văn hóa doanh nghiệp</li>
                        </ul>
                      </div>
                    </div>
                  </section>
                </TabsContent>

                <TabsContent value="bai-tap">
                  <div className="learning-content">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Bài tập thực hành</h2>
                    <p className="mb-4">
                      Hãy chọn một thương hiệu làng nghề truyền thống Việt Nam và thực hiện các yêu cầu sau:
                    </p>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu 1: Phân tích đặc tính thương hiệu</h3>
                      <p className="mb-3">
                        Phân tích đặc tính thương hiệu theo mô hình lăng trụ đặc tính thương hiệu của Kapferer:
                      </p>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>Yếu tố hữu hình (Physics)</li>
                        <li>Cá tính (Personality)</li>
                        <li>Mối quan hệ (Relationship)</li>
                        <li>Biểu tượng văn hoá (Culture)</li>
                        <li>Sự phản ánh (Reflection)</li>
                        <li>Sự tự cảm nhận về bản thân (Self-image)</li>
                      </ol>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu 2: Xây dựng tuyên ngôn thương hiệu</h3>
                      <p className="mb-3">
                        Xây dựng tuyên ngôn về bản chất thương hiệu (brand essence/brand mantra) cho thương hiệu làng
                        nghề đã chọn, bao gồm:
                      </p>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>Thành phần chức năng</li>
                        <li>Thành phần điều chỉnh mô tả</li>
                        <li>Thành phần điều chỉnh cảm xúc</li>
                      </ol>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu 3: Đề xuất chiến lược định vị</h3>
                      <p className="mb-3">Đề xuất chiến lược định vị thương hiệu cho làng nghề đã chọn, bao gồm:</p>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>Phân tích khách hàng mục tiêu</li>
                        <li>Phân tích đối thủ cạnh tranh</li>
                        <li>Xác định điểm khác biệt</li>
                        <li>Xây dựng tuyên bố định vị</li>
                      </ol>
                    </div>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu nộp bài</h3>
                      <p>
                        Hãy thực hiện các yêu cầu trên và nộp bài dưới dạng file PowerPoint hoặc PDF qua hệ thống học
                        tập trực tuyến trước ngày 30/06/2025.
                      </p>
                      <Button className="bg-terracotta hover:bg-terracotta-600 text-white mt-4">Tải mẫu báo cáo</Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="tai-lieu">
                  <div className="learning-content">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Tài liệu tham khảo</h2>
                    <ul className="list-disc pl-6 space-y-3">
                      <li>
                        Aaker, D.A. (2014), <em>Aaker on Branding: 20 Principles That Drive Success</em>, Morgan James
                        Publishing.
                      </li>
                      <li>
                        Kapferer, J.N. (2012),{" "}
                        <em>The New Strategic Brand Management: Advanced Insights and Strategic Thinking</em>, 5th
                        Edition, Kogan Page.
                      </li>
                      <li>
                        Keller, K.L. (2013),{" "}
                        <em>Strategic Brand Management: Building, Measuring, and Managing Brand Equity</em>, 4th
                        Edition, Pearson Education.
                      </li>
                      <li>
                        Wheeler, A. (2017),{" "}
                        <em>Designing Brand Identity: An Essential Guide for the Whole Branding Team</em>, 5th Edition,
                        Wiley.
                      </li>
                      <li>
                        Trần Minh Đạo (2014), <em>Giáo trình Marketing căn bản</em>, NXB Đại học Kinh tế Quốc dân.
                      </li>
                    </ul>

                    <div className="mt-8">
                      <h3 className="font-bold text-earth-800 mb-3">Tài liệu bổ sung</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Bài giảng Xây dựng đặc tính thương hiệu</p>
                            <p className="text-sm text-earth-600">PDF - 3.2MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Mẫu phân tích đặc tính thương hiệu</p>
                            <p className="text-sm text-earth-600">PPTX - 2.1MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Ví dụ tuyên ngôn thương hiệu</p>
                            <p className="text-sm text-earth-600">PDF - 1.5MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Hướng dẫn xây dựng chiến lược định vị</p>
                            <p className="text-sm text-earth-600">PDF - 2.8MB</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
