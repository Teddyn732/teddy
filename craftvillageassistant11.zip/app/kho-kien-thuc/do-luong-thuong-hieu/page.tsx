"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, Printer, Share2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DoLuongThuongHieuPage() {
  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-white border-b border-earth-200 py-3 px-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5 text-earth-700" />
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="Làng Nghề Việt Logo" className="h-8 w-8" />
              <h1 className="text-xl font-bold text-earth-900">Làng Nghề Việt</h1>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Printer className="h-4 w-4" />
              <span className="hidden md:inline">In tài liệu</span>
            </Button>
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Download className="h-4 w-4" />
              <span className="hidden md:inline">Tải xuống</span>
            </Button>
            <Button variant="outline" className="border-earth-600 text-earth-700 gap-2">
              <Share2 className="h-4 w-4" />
              <span className="hidden md:inline">Chia sẻ</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <aside className="w-full md:w-64 shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-earth-100 p-4 sticky top-4">
              <h3 className="font-bold text-earth-900 mb-4 text-lg">Mục lục</h3>
              <nav className="space-y-1">
                <Link
                  href="#gioi-thieu"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Giới thiệu
                </Link>
                <Link
                  href="#do-luong-nhan-biet"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đo lường nhận biết
                </Link>
                <Link
                  href="#do-luong-lien-tuong"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đo lường liên tưởng
                </Link>
                <Link
                  href="#do-luong-chat-luong"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đo lường chất lượng
                </Link>
                <Link
                  href="#do-luong-trung-thanh"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đo lường trung thành
                </Link>
                <Link
                  href="#ban-do-nhan-thuc"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Bản đồ nhận thức
                </Link>
                <Link
                  href="#danh-gia-logo-slogan"
                  className="block py-2 px-3 rounded-md hover:bg-earth-50 text-earth-700 hover:text-earth-900"
                >
                  Đánh giá logo và slogan
                </Link>
              </nav>
            </div>
          </aside>

          <main className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-earth-100 p-6 md:p-8">
              <h1 className="text-3xl font-bold text-earth-900 mb-6">ĐO LƯỜNG KHẢ NĂNG HOẠT ĐỘNG CỦA THƯƠNG HIỆU</h1>

              <Tabs defaultValue="noi-dung">
                <TabsList className="mb-6">
                  <TabsTrigger value="noi-dung">Nội dung</TabsTrigger>
                  <TabsTrigger value="bai-tap">Bài tập thực hành</TabsTrigger>
                  <TabsTrigger value="tai-lieu">Tài liệu tham khảo</TabsTrigger>
                </TabsList>

                <TabsContent value="noi-dung" className="learning-content">
                  <section id="gioi-thieu" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đo lường hoạt động của thương hiệu</h2>
                    <p>
                      Sự vận hành của thương hiệu trong tâm trí khách hàng và công chúng (Đo lường sức khoẻ thương hiệu)
                      bao gồm:
                    </p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>Đo lường mức độ nhận biết</li>
                      <li>Đo lường chất lượng, giá trị cảm nhận</li>
                      <li>Đo lường liên tưởng thương hiệu</li>
                      <li>
                        Đo lường định vị/tính cách: vị trí hiện hữu so với các thủ cạnh tranh, so với vị trí muốn đạt
                        đến
                      </li>
                      <li>
                        Đo lường hình ảnh công ty: các đối tượng đang có hình ảnh về công ty như thế nào trong tâm tưởng
                      </li>
                      <li>Đo lường mức độ hài lòng</li>
                      <li>Đo lường mức độ trung thành</li>
                    </ul>

                    <p>Sự vận hành của thương hiệu trên thị trường:</p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>Tăng trưởng doanh số</li>
                      <li>Thị phần</li>
                    </ul>

                    <p>Sự vận hành của thương hiệu trong doanh nghiệp:</p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>% lợi nhuận trên doanh thu</li>
                      <li>Tăng trưởng lợi nhuận</li>
                      <li>Thời điểm sinh lợi</li>
                    </ul>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mt-6">
                      <h3 className="font-bold text-earth-800 mb-2">
                        Mục tiêu và ý nghĩa của việc đo lường sức khoẻ thương hiệu
                      </h3>
                      <p>
                        Biết được sức khỏe thương hiệu để điều chỉnh chiến lược thương hiệu, tạo lập thương hiệu mới, ra
                        thương hiệu nhánh, tái định vị, điều chỉnh bản sắc, thay đổi truyền thông, v.v.
                      </p>
                      <p className="font-medium mt-2">Ra quyết định kinh doanh dựa trên nền tảng thương hiệu.</p>
                    </div>
                  </section>

                  <section id="do-luong-nhan-biet" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đo lường nhận biết</h2>
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="bg-earth-100">
                            <th className="border border-earth-200 p-2 text-left">Mức độ nhận biết</th>
                            <th className="border border-earth-200 p-2 text-left">Câu hỏi</th>
                            <th className="border border-earth-200 p-2 text-left">Ý nghĩa</th>
                            <th className="border border-earth-200 p-2 text-left">Mức độ</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="border border-earth-200 p-2">Nhận biết đầu tiên (top-of-mind)</td>
                            <td className="border border-earth-200 p-2">
                              Nói đến ngành hàng..., anh/chị nghĩ đến thương hiệu nào đầu tiên?
                            </td>
                            <td className="border border-earth-200 p-2">Cân nhắc chọn</td>
                            <td className="border border-earth-200 p-2">Mạnh</td>
                          </tr>
                          <tr>
                            <td className="border border-earth-200 p-2">
                              Nhận biết không cần nhắc nhở (unaided awareness)
                            </td>
                            <td className="border border-earth-200 p-2">
                              Ngoài thương hiệu kể trên, anh/chị còn nhớ đến thương hiệu nào nữa?
                            </td>
                            <td className="border border-earth-200 p-2">Có thể được xem xét</td>
                            <td className="border border-earth-200 p-2">Trung bình</td>
                          </tr>
                          <tr>
                            <td className="border border-earth-200 p-2">Nhận biết có nhắc nhở (aided awareness)</td>
                            <td className="border border-earth-200 p-2">
                              Trong các thương hiệu gợi ý dưới đây, anh/chị biết đến thương hiệu nào?
                            </td>
                            <td className="border border-earth-200 p-2">Không xem xét</td>
                            <td className="border border-earth-200 p-2">Yếu</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </section>

                  <section id="do-luong-lien-tuong" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đo lường liên tưởng thương hiệu</h2>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>Câu hỏi: Khi nhắc đến thương hiệu...., anh/chị có những liên tưởng nào?</li>
                      <li>Liên tưởng qua thương hiệu có được do đâu?</li>
                      <li>Cách lựa chọn các liên tưởng qua thương hiệu?</li>
                      <li>Lựa chọn liên tưởng tích cực hay tiêu cực?</li>
                    </ul>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mt-4">
                      <h3 className="font-bold text-earth-800 mb-3">
                        Cách đơn giản để đo lường liên tưởng thương hiệu, so sánh giữa các thương hiệu
                      </h3>
                      <img
                        src="/images/radar-chart.png"
                        alt="Biểu đồ radar so sánh liên tưởng thương hiệu"
                        className="w-full max-w-2xl mx-auto my-4"
                      />
                      <p className="text-sm text-earth-600 text-center">
                        Biểu đồ radar so sánh các thuộc tính của thương hiệu
                      </p>
                    </div>
                  </section>

                  <section id="do-luong-chat-luong" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đo lường chất lượng cảm nhận</h2>
                    <p>
                      Căn cứ xây dựng các chỉ tiêu đo lường chất lượng cảm nhận của khách hàng đối với thương hiệu dựa
                      trên các yếu tố:
                    </p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>Hiệu suất sản phẩm</li>
                      <li>Tính năng đặc biệt</li>
                      <li>Độ tin cậy</li>
                      <li>Độ bền</li>
                      <li>Khả năng phục vụ</li>
                      <li>Thẩm mỹ</li>
                      <li>Chất lượng cảm nhận</li>
                    </ul>
                  </section>

                  <section id="do-luong-trung-thanh" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đo lường mức độ trung thành</h2>
                    <p>Các khía cạnh thể hiện sự trung thành của khách hàng đối với thương hiệu:</p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>Mức độ hài lòng</li>
                      <li>Ý định mua lại</li>
                      <li>Sẵn sàng giới thiệu cho người khác</li>
                      <li>Sẵn sàng trả giá cao hơn</li>
                      <li>Tần suất mua hàng</li>
                      <li>Tỷ lệ chi tiêu cho thương hiệu</li>
                    </ul>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mt-4">
                      <h3 className="font-bold text-earth-800 mb-2">Phân tích sức khỏe thương hiệu</h3>
                      <p>Các chỉ số quan trọng cần đo lường:</p>
                      <ul className="list-disc pl-6 space-y-1 mt-2">
                        <li>Chuyển từ nhận biết sang giao dịch/sử dụng</li>
                        <li>Duy trì mức độ sử dụng</li>
                        <li>Tiếp tục sử dụng</li>
                        <li>Truyền miệng</li>
                        <li>Xu hướng thay đổi thương hiệu</li>
                      </ul>
                    </div>
                  </section>

                  <section id="ban-do-nhan-thuc" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">
                      Đo lường định vị - Bản đồ nhận thức (perceptual map)
                    </h2>
                    <p>
                      Bản đồ nhận thức là công cụ mô tả cấu trúc cạnh tranh của thị trường, hỗ trợ cho việc ra các quyết
                      định về khác biệt và định vị.
                    </p>
                    <p>
                      Bản đồ nhận thức là một cách trình bày các TH cạnh tranh trên một không gian Eucid. Nó có 3 đặc
                      tính:
                    </p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>
                        Khoảng cách giữa 2 TH thể hiện "mức độ giống nhau" của 2 TH này theo cảm nhận của KH. Khoảng
                        cách càng nhỏ thể hiện mức độ giống nhau càng nhiều.
                      </li>
                      <li>
                        Một vecto (đoạn thẳng) trên bản đồ biểu thị độ lớn và chiều hướng trong không gian Euclid của
                        các thuộc tính.
                      </li>
                      <li>
                        Các trục (hướng) của bản đồ là một tập hợp các vecto có thể gợi ra các yếu tố (khía cạnh -
                        dimension) quan trọng mô tả cách khách hàng phân biệt các TH như thế nào.
                      </li>
                    </ul>

                    <div className="bg-white p-4 rounded-lg border border-earth-200 mt-4">
                      <h3 className="font-bold text-earth-800 mb-3">Ví dụ về bản đồ nhận thức</h3>
                      <img
                        src="/images/perceptual-map.png"
                        alt="Bản đồ nhận thức thương hiệu"
                        className="w-full max-w-2xl mx-auto my-4"
                      />
                      <p className="text-sm text-earth-600 text-center">Bản đồ nhận thức thương hiệu xe hơi</p>
                    </div>
                  </section>

                  <section id="danh-gia-logo-slogan" className="mb-8">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Đo lường, đánh giá Logo và Slogan</h2>
                    <p>
                      Kiểm tra Logo và Slogan của công ty có hỗ trợ tốt cho việc tạo định vị, truyền thông bản sắc đối
                      với đối tượng mục tiêu hay không?
                    </p>
                    <ul className="list-disc pl-6 space-y-2 mb-4">
                      <li>Xin cho biết anh/chị có nhớ logo của thương hiệu... có màu gì không ạ?</li>
                      <li>Anh/chị có thể mô tả một chi tiết bất kỳ của logo thương hiệu....?</li>
                      <li>Nhìn vào log của thương hiệu..., anh chị vui lòng cho biết ý nghĩa của nó?</li>
                      <li>Anh/chị vui lòng cho biết câu slogan hiện tại của thương hiệu.... là gì?</li>
                    </ul>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mt-4">
                      <h3 className="font-bold text-earth-800 mb-2">Bố cục bài trình bày đo lường thương hiệu</h3>
                      <ol className="list-decimal pl-6 space-y-1 mt-2">
                        <li>Tên bài trình bày, tên nhóm</li>
                        <li>Giới thiệu vài nét về thương hiệu</li>
                        <li>Phương pháp nghiên cứu (phương pháp điều tra, xử lý số liệu,...)</li>
                        <li>Bảng đặc điểm mẫu nghiên cứu (giới tính, tuổi, nghề nghiệp, thu nhập, học vấn,...)</li>
                        <li>Nhận biết thương hiệu (các cấp độ nhận biết: T.O.M, không giúp, có giúp, không biết)</li>
                        <li>Liên tưởng qua thương hiệu</li>
                        <li>
                          Thông tin ngoài lề (nguồn thông tin biết đến TH, tần suất sử dụng, địa điểm mua, đi cùng với
                          ai, mua làm gì, số tiền chi, ....)
                        </li>
                        <li>Chất lượng cảm nhận</li>
                        <li>Mức độ hài lòng</li>
                        <li>Trung thành thương hiệu</li>
                        <li>Các % đạt chuyển</li>
                        <li>Bản đồ định vị hoặc biểu đồ radar</li>
                        <li>
                          Đo lường, đánh giá logo, slogan hoặc các yếu tố thương hiệu khác như bao bì, kiểu dáng sản
                          phẩm, đồng phục,...
                        </li>
                        <li>Tài liệu tham khảo</li>
                      </ol>
                    </div>
                  </section>
                </TabsContent>

                <TabsContent value="bai-tap">
                  <div className="learning-content">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Bài tập thực hành</h2>
                    <p className="mb-4">
                      Hãy chọn một trong các thương hiệu sau để thực hiện đo lường thương hiệu theo hướng dẫn:
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      <div className="bg-white p-4 rounded-lg border border-earth-200">
                        <h3 className="font-bold text-earth-800 mb-2">Nhóm 1</h3>
                        <ol className="list-decimal pl-6 space-y-1">
                          <li>Kem Merino</li>
                          <li>Kem đánh răng Sensodyne</li>
                          <li>Cf Highlands</li>
                          <li>KFC</li>
                          <li>Dell</li>
                          <li>Redbull</li>
                          <li>Viettelpay</li>
                          <li>Shopee</li>
                          <li>Nước rửa tay Lifebuoy</li>
                        </ol>
                      </div>

                      <div className="bg-white p-4 rounded-lg border border-earth-200">
                        <h3 className="font-bold text-earth-800 mb-2">Nhóm 2</h3>
                        <ol className="list-decimal pl-6 space-y-1">
                          <li>Bút bi Thiên Long</li>
                          <li>Biti's</li>
                          <li>Dầu ăn Meizan</li>
                          <li>Trà xanh không độ</li>
                          <li>Nước sát khuẩn Lifebouy</li>
                          <li>Comfort</li>
                          <li>The Pizza Company</li>
                          <li>Now</li>
                          <li>Clear</li>
                          <li>Tương ớt Chinsu</li>
                        </ol>
                      </div>
                    </div>

                    <div className="bg-earth-50 p-4 rounded-lg border border-earth-100 mb-6">
                      <h3 className="font-bold text-earth-800 mb-3">Hướng dẫn thực hiện</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Tìm hiểu thương hiệu</li>
                        <li>Các hoạt động truyền thông thương hiệu đang thực hiện (nguồn thông tin, liên tưởng)</li>
                        <li>Các chỉ tiêu sử dụng để đánh giá chất lượng của ngành (chất lượng cảm nhận)</li>
                        <li>Tìm các đối thủ cạnh tranh (radar)</li>
                        <li>Các yếu tố dùng để cạnh tranh trong ngành của mình (radar)</li>
                        <li>Các yếu tố bao bì/logo/slogan/đồng phục/trang trí cửa hàng (hiện tại)</li>
                        <li>
                          Các yếu tố mô tả hành vi của khách hàng (tần suất sử dụng/ mức chi/ các sản phẩm đang sử dụng/
                          dung tích/ loại hương thơm/...)
                        </li>
                      </ul>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-earth-200">
                      <h3 className="font-bold text-earth-800 mb-3">Yêu cầu nộp bài</h3>
                      <p>
                        Hãy thực hiện đo lường thương hiệu theo hướng dẫn và nộp bài dưới dạng file PowerPoint hoặc PDF
                        qua hệ thống học tập trực tuyến trước ngày 30/06/2025.
                      </p>
                      <Button className="bg-terracotta hover:bg-terracotta-600 text-white mt-4">Tải mẫu báo cáo</Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="tai-lieu">
                  <div className="learning-content">
                    <h2 className="text-2xl font-bold text-earth-900 mb-4">Tài liệu tham khảo</h2>
                    <ul className="list-disc pl-6 space-y-3">
                      <li>
                        Hoàng Trọng và Chu Nguyễn Mộng Ngọc (2008),{" "}
                        <em>Phân tích dữ liệu nghiên cứu với SPSS, tập hai</em>, NXB Hồng Đức.
                      </li>
                      <li>
                        Keller, K.L. (2013),{" "}
                        <em>Strategic Brand Management: Building, Measuring, and Managing Brand Equity</em>, 4th
                        Edition, Pearson Education.
                      </li>
                      <li>
                        Aaker, D.A. (2014), <em>Aaker on Branding: 20 Principles That Drive Success</em>, Morgan James
                        Publishing.
                      </li>
                      <li>
                        Kapferer, J.N. (2012),{" "}
                        <em>The New Strategic Brand Management: Advanced Insights and Strategic Thinking</em>, 5th
                        Edition, Kogan Page.
                      </li>
                      <li>
                        Wheeler, A. (2017),{" "}
                        <em>Designing Brand Identity: An Essential Guide for the Whole Branding Team</em>, 5th Edition,
                        Wiley.
                      </li>
                    </ul>

                    <div className="mt-8">
                      <h3 className="font-bold text-earth-800 mb-3">Tài liệu bổ sung</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Bài giảng Đo lường thương hiệu</p>
                            <p className="text-sm text-earth-600">PDF - 2.5MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Mẫu báo cáo đo lường thương hiệu</p>
                            <p className="text-sm text-earth-600">PPTX - 1.8MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Bộ công cụ đo lường thương hiệu</p>
                            <p className="text-sm text-earth-600">XLSX - 0.9MB</p>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-earth-200 flex items-center gap-3">
                          <Download className="h-5 w-5 text-terracotta" />
                          <div>
                            <p className="font-medium text-earth-900">Hướng dẫn phân tích dữ liệu với SPSS</p>
                            <p className="text-sm text-earth-600">PDF - 3.2MB</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
