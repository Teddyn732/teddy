"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Loader2 } from "lucide-react"
import puterClient from "@/lib/puter-client"

export default function PuterDemoPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [isInitialized, setIsInitialized] = useState(false)
  const [output, setOutput] = useState("")
  const [aiPrompt, setAiPrompt] = useState("")
  const [imagePrompt, setImagePrompt] = useState("")
  const [fileName, setFileName] = useState("demo.txt")
  const [fileContent, setFileContent] = useState("Hello, Puter!")
  const [kvKey, setKvKey] = useState("demo_key")
  const [kvValue, setKvValue] = useState("demo_value")
  const [userInfo, setUserInfo] = useState<any>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    const initialize = async () => {
      setIsLoading(true)
      const initialized = await puterClient.init()
      setIsInitialized(initialized)

      if (initialized) {
        // Check if user is signed in
        if (puterClient.auth.isSignedIn()) {
          const user = await puterClient.auth.getUser()
          setUserInfo(user)
        }
      }

      setIsLoading(false)
    }

    initialize()
  }, [])

  const appendOutput = (text: string) => {
    setOutput((prev) => prev + text + "\n")
  }

  const clearOutput = () => {
    setOutput("")
  }

  const handleSignIn = async () => {
    setIsProcessing(true)
    appendOutput("Đang đăng nhập...")

    try {
      const user = await puterClient.auth.signIn()
      setUserInfo(user)
      appendOutput("Đăng nhập thành công!")
    } catch (error) {
      appendOutput("Lỗi khi đăng nhập: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleSignOut = async () => {
    setIsProcessing(true)
    appendOutput("Đang đăng xuất...")

    try {
      await puterClient.auth.signOut()
      setUserInfo(null)
      appendOutput("Đăng xuất thành công!")
    } catch (error) {
      appendOutput("Lỗi khi đăng xuất: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleGenerateText = async () => {
    if (!aiPrompt) return

    setIsProcessing(true)
    appendOutput(`Đang tạo văn bản với prompt: "${aiPrompt}"...`)

    try {
      const response = await puterClient.ai.generateText(aiPrompt)

      if (response) {
        let responseText = ""

        if (typeof response === "string") {
          responseText = response
        } else if (response.message && response.message.content) {
          responseText = response.message.content
        } else if (response.content) {
          responseText = response.content
        } else {
          responseText = JSON.stringify(response)
        }

        appendOutput("Kết quả:")
        appendOutput(responseText)
      } else {
        appendOutput("Không nhận được phản hồi từ AI")
      }
    } catch (error) {
      appendOutput("Lỗi khi tạo văn bản: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleGenerateImage = async () => {
    if (!imagePrompt) return

    setIsProcessing(true)
    appendOutput(`Đang tạo hình ảnh với prompt: "${imagePrompt}"...`)

    try {
      const imageElement = await puterClient.ai.generateImage(imagePrompt)

      if (imageElement && imageElement.src) {
        appendOutput("Hình ảnh đã được tạo thành công!")
        appendOutput(`URL hình ảnh: ${imageElement.src}`)

        // Display the image
        const imgContainer = document.createElement("div")
        imgContainer.className = "mt-2 mb-4"
        imgContainer.appendChild(imageElement)

        const outputElement = document.getElementById("output-container")
        if (outputElement) {
          outputElement.appendChild(imgContainer)
        }
      } else {
        appendOutput("Không thể tạo hình ảnh")
      }
    } catch (error) {
      appendOutput("Lỗi khi tạo hình ảnh: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleWriteFile = async () => {
    if (!fileName || !fileContent) return

    setIsProcessing(true)
    appendOutput(`Đang ghi tệp "${fileName}" với nội dung: "${fileContent}"...`)

    try {
      const success = await puterClient.fs.writeFile(fileName, fileContent)

      if (success) {
        appendOutput("Ghi tệp thành công!")
      } else {
        appendOutput("Không thể ghi tệp")
      }
    } catch (error) {
      appendOutput("Lỗi khi ghi tệp: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleReadFile = async () => {
    if (!fileName) return

    setIsProcessing(true)
    appendOutput(`Đang đọc tệp "${fileName}"...`)

    try {
      const file = await puterClient.fs.readFile(fileName)

      if (file) {
        const content = await file.text()
        appendOutput("Nội dung tệp:")
        appendOutput(content)
      } else {
        appendOutput("Không thể đọc tệp")
      }
    } catch (error) {
      appendOutput("Lỗi khi đọc tệp: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleListFiles = async () => {
    setIsProcessing(true)
    appendOutput("Đang liệt kê tệp...")

    try {
      const files = await puterClient.fs.listFiles()

      if (files && files.length > 0) {
        appendOutput(`Tìm thấy ${files.length} tệp:`)
        files.forEach((file: any) => {
          appendOutput(`- ${file.name} (${file.type})`)
        })
      } else {
        appendOutput("Không tìm thấy tệp nào")
      }
    } catch (error) {
      appendOutput("Lỗi khi liệt kê tệp: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleSetValue = async () => {
    if (!kvKey || !kvValue) return

    setIsProcessing(true)
    appendOutput(`Đang lưu giá trị "${kvValue}" với khóa "${kvKey}"...`)

    try {
      const success = await puterClient.kv.setValue(kvKey, kvValue)

      if (success) {
        appendOutput("Lưu giá trị thành công!")
      } else {
        appendOutput("Không thể lưu giá trị")
      }
    } catch (error) {
      appendOutput("Lỗi khi lưu giá trị: " + String(error))
    }

    setIsProcessing(false)
  }

  const handleGetValue = async () => {
    if (!kvKey) return

    setIsProcessing(true)
    appendOutput(`Đang lấy giá trị với khóa "${kvKey}"...`)

    try {
      const value = await puterClient.kv.getValue(kvKey)

      if (value !== null) {
        appendOutput("Giá trị:")
        appendOutput(typeof value === "object" ? JSON.stringify(value) : String(value))
      } else {
        appendOutput("Không tìm thấy giá trị với khóa này")
      }
    } catch (error) {
      appendOutput("Lỗi khi lấy giá trị: " + String(error))
    }

    setIsProcessing(false)
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 px-4 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-earth-600" />
      </div>
    )
  }

  if (!isInitialized) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card>
          <CardHeader>
            <CardTitle>Puter.js Demo</CardTitle>
            <CardDescription>Khám phá các tính năng của Puter.js</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-red-500">Không thể khởi tạo Puter.js. Vui lòng kiểm tra kết nối mạng và thử lại.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card>
        <CardHeader>
          <CardTitle>Puter.js Demo</CardTitle>
          <CardDescription>Khám phá các tính năng của Puter.js</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="auth">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="auth">Xác thực</TabsTrigger>
              <TabsTrigger value="ai">AI</TabsTrigger>
              <TabsTrigger value="fs">Lưu trữ</TabsTrigger>
              <TabsTrigger value="kv">Key-Value</TabsTrigger>
            </TabsList>

            <TabsContent value="auth" className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Trạng thái xác thực</h3>
                <p>
                  {userInfo ? (
                    <span className="text-green-500">Đã đăng nhập</span>
                  ) : (
                    <span className="text-red-500">Chưa đăng nhập</span>
                  )}
                </p>

                {userInfo && (
                  <div className="p-2 bg-gray-50 rounded-md">
                    <p>
                      <strong>ID:</strong> {userInfo.id}
                    </p>
                    <p>
                      <strong>Tên:</strong> {userInfo.name || "N/A"}
                    </p>
                    <p>
                      <strong>Email:</strong> {userInfo.email || "N/A"}
                    </p>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                {!userInfo ? (
                  <Button onClick={handleSignIn} disabled={isProcessing}>
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                      </>
                    ) : (
                      "Đăng nhập"
                    )}
                  </Button>
                ) : (
                  <Button onClick={handleSignOut} disabled={isProcessing} variant="outline">
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                      </>
                    ) : (
                      "Đăng xuất"
                    )}
                  </Button>
                )}
              </div>
            </TabsContent>

            <TabsContent value="ai" className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Tạo văn bản với AI</h3>
                <Textarea
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="Nhập prompt của bạn..."
                  rows={3}
                />
                <Button onClick={handleGenerateText} disabled={isProcessing || !aiPrompt}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Tạo văn bản"
                  )}
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Tạo hình ảnh với AI</h3>
                <Textarea
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder="Mô tả hình ảnh bạn muốn tạo..."
                  rows={3}
                />
                <Button onClick={handleGenerateImage} disabled={isProcessing || !imagePrompt}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Tạo hình ảnh"
                  )}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="fs" className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Ghi tệp</h3>
                <div className="grid grid-cols-1 gap-2">
                  <Input value={fileName} onChange={(e) => setFileName(e.target.value)} placeholder="Tên tệp" />
                  <Textarea
                    value={fileContent}
                    onChange={(e) => setFileContent(e.target.value)}
                    placeholder="Nội dung tệp"
                    rows={3}
                  />
                </div>
                <Button onClick={handleWriteFile} disabled={isProcessing || !fileName || !fileContent}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Ghi tệp"
                  )}
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Đọc tệp</h3>
                <Input value={fileName} onChange={(e) => setFileName(e.target.value)} placeholder="Tên tệp" />
                <Button onClick={handleReadFile} disabled={isProcessing || !fileName}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Đọc tệp"
                  )}
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Liệt kê tệp</h3>
                <Button onClick={handleListFiles} disabled={isProcessing}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Liệt kê tệp"
                  )}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="kv" className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Lưu giá trị</h3>
                <div className="grid grid-cols-1 gap-2">
                  <Input value={kvKey} onChange={(e) => setKvKey(e.target.value)} placeholder="Khóa" />
                  <Input value={kvValue} onChange={(e) => setKvValue(e.target.value)} placeholder="Giá trị" />
                </div>
                <Button onClick={handleSetValue} disabled={isProcessing || !kvKey || !kvValue}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Lưu giá trị"
                  )}
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Lấy giá trị</h3>
                <Input value={kvKey} onChange={(e) => setKvKey(e.target.value)} placeholder="Khóa" />
                <Button onClick={handleGetValue} disabled={isProcessing || !kvKey}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang xử lý...
                    </>
                  ) : (
                    "Lấy giá trị"
                  )}
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-8">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-medium">Kết quả</h3>
              <Button variant="outline" size="sm" onClick={clearOutput}>
                Xóa
              </Button>
            </div>
            <div
              id="output-container"
              className="bg-gray-50 p-4 rounded-md h-[300px] overflow-y-auto font-mono text-sm whitespace-pre-wrap"
            >
              {output || "Chưa có kết quả. Hãy thử một trong các tính năng ở trên."}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
