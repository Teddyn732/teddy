/**
 * Utility for loading external scripts with retry capability
 */
export async function loadScript(src: string, id: string, retries = 3, delay = 1000): Promise<boolean> {
  return new Promise((resolve) => {
    // Check if script is already loaded
    if (document.getElementById(id)) {
      console.log(`Script ${id} already loaded`)
      resolve(true)
      return
    }

    // Check if window.puter already exists
    if (id === "puter-js" && typeof window !== "undefined" && "puter" in window) {
      console.log("Puter.js already loaded and initialized")
      resolve(true)
      return
    }

    const script = document.createElement("script")
    script.src = src
    script.id = id
    script.async = true

    script.onload = () => {
      console.log(`Script ${id} loaded successfully`)
      resolve(true)
    }

    script.onerror = async () => {
      console.error(`Failed to load script ${id}`)
      if (retries > 0) {
        console.log(`Retrying... (${retries} attempts left)`)
        // Remove the failed script
        script.remove()
        // Wait before retrying
        await new Promise((r) => setTimeout(r, delay))
        // Try again with one less retry
        const result = await loadScript(src, id, retries - 1, delay * 1.5)
        resolve(result)
      } else {
        console.error(`All attempts to load ${id} failed`)
        resolve(false)
      }
    }

    document.head.appendChild(script)
  })
}

/**
 * Check if Puter.js is loaded and initialized
 */
export function isPuterLoaded(): boolean {
  return typeof window !== "undefined" && "puter" in window
}

/**
 * Load Puter.js with retry capability
 */
export async function loadPuter(retries = 3): Promise<boolean> {
  return loadScript("https://js.puter.com/v2/", "puter-js", retries)
}
