import * as tf from "@tensorflow/tfjs"
import { supabase } from "@/lib/db/supabase"

// Load pre-trained recommendation model
export async function loadRecommendationModel() {
  try {
    const model = await tf.loadLayersModel("/models/recommendation/model.json")
    return model
  } catch (error) {
    console.error("Error loading recommendation model:", error)
    throw new Error("Failed to load recommendation model")
  }
}

// Get product recommendations based on user preferences
export async function getProductRecommendations(userPreferences: {
  craftType: string
  priceRange: [number, number]
  style: string
  purpose: string
}) {
  try {
    // 1. Convert user preferences to feature vector
    const featureVector = encodeUserPreferences(userPreferences)

    // 2. Load model
    const model = await loadRecommendationModel()

    // 3. Get predictions
    const predictions = model.predict(tf.tensor([featureVector])) as tf.Tensor
    const predictionArray = await predictions.array()

    // 4. Get top product IDs
    const topProductIds = getTopKIndices(predictionArray[0], 5)

    // 5. Fetch products from database
    const { data: products, error } = await supabase.from("products").select("*").in("id", topProductIds)

    if (error) throw error

    // 6. Return sorted products
    return sortProductsByPredictionScore(products, topProductIds, predictionArray[0])
  } catch (error) {
    console.error("Error getting recommendations:", error)
    throw new Error("Failed to get product recommendations")
  }
}

// Helper functions
function encodeUserPreferences(preferences: any) {
  // Convert user preferences to numerical feature vector
  // This is a simplified example - in a real system, this would be more complex
  const craftTypeEncoding = {
    "gom-su": [1, 0, 0, 0, 0],
    "det-may": [0, 1, 0, 0, 0],
    "may-tre": [0, 0, 1, 0, 0],
    "son-mai": [0, 0, 0, 1, 0],
    "thu-cong": [0, 0, 0, 0, 1],
  }

  const styleEncoding = {
    traditional: [1, 0, 0],
    modern: [0, 1, 0],
    fusion: [0, 0, 1],
  }

  const purposeEncoding = {
    gift: [1, 0, 0, 0],
    home: [0, 1, 0, 0],
    collection: [0, 0, 1, 0],
    souvenir: [0, 0, 0, 1],
  }

  // Normalize price range to 0-1
  const priceNormalized = [preferences.priceRange[0] / 10000000, preferences.priceRange[1] / 10000000]

  // Combine all features
  return [
    ...craftTypeEncoding[preferences.craftType as keyof typeof craftTypeEncoding],
    ...priceNormalized,
    ...styleEncoding[preferences.style as keyof typeof styleEncoding],
    ...purposeEncoding[preferences.purpose as keyof typeof purposeEncoding],
  ]
}

function getTopKIndices(arr: number[], k: number) {
  return Array.from(Array(arr.length).keys())
    .sort((a, b) => arr[b] - arr[a])
    .slice(0, k)
}

function sortProductsByPredictionScore(products: any[], indices: number[], scores: number[]) {
  return indices
    .map((index) => ({
      ...products.find((p) => p.id === index),
      score: scores[index],
    }))
    .sort((a, b) => b.score - a.score)
}
