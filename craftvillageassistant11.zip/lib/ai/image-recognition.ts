import * as tf from "@tensorflow/tfjs"

// Load the pre-trained model for craft identification
export async function loadCraftIdentificationModel() {
  try {
    const model = await tf.loadGraphModel("/models/craft-identification/model.json")
    return model
  } catch (error) {
    console.error("Error loading craft identification model:", error)
    throw new Error("Failed to load craft identification model")
  }
}

// Process image and identify craft type
export async function identifyCraftFromImage(imageElement: HTMLImageElement) {
  try {
    // 1. Load model
    const model = await loadCraftIdentificationModel()

    // 2. Preprocess image
    const tensor = preprocessImage(imageElement)

    // 3. Run prediction
    const predictions = (await model.predict(tensor)) as tf.Tensor

    // 4. Process results
    const craftTypes = ["gom-su", "det-may", "may-tre", "son-mai", "thu-cong"]

    // Get probabilities
    const probabilities = await predictions.array()

    // Get top prediction
    const maxProbIndex = probabilities[0].indexOf(Math.max(...probabilities[0]))
    const craftType = craftTypes[maxProbIndex]
    const confidence = probabilities[0][maxProbIndex]

    // Clean up tensors
    tf.dispose([tensor, predictions])

    return {
      craftType,
      confidence,
      allPredictions: craftTypes
        .map((type, i) => ({
          type,
          probability: probabilities[0][i],
        }))
        .sort((a, b) => b.probability - a.probability),
    }
  } catch (error) {
    console.error("Error identifying craft from image:", error)
    throw new Error("Failed to identify craft from image")
  }
}

// Preprocess image for the model
function preprocessImage(imageElement: HTMLImageElement) {
  // Convert image to tensor
  const tensor = tf.browser
    .fromPixels(imageElement)
    .resizeNearestNeighbor([224, 224]) // Resize to model input size
    .toFloat()
    .div(tf.scalar(255.0)) // Normalize to 0-1
    .expandDims(0) // Add batch dimension

  return tensor
}
