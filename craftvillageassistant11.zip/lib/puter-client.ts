/**
 * Unified Puter.js client utility
 * Provides access to all Puter.js capabilities with proper error handling
 */

// Define types for Puter.js
declare global {
  interface Window {
    puter?: {
      ai?: {
        chat?: (prompt: string | any, options?: any) => Promise<any>
        txt2img?: (prompt: string) => Promise<HTMLImageElement>
        txt2speech?: (text: string, language?: string) => Promise<HTMLAudioElement>
      }
      kv?: {
        set?: (key: string, value: string) => Promise<void>
        get?: (key: string) => Promise<string | null>
        del?: (key: string) => Promise<void>
        list?: (pattern: string, withValues?: boolean) => Promise<any[]>
        incr?: (key: string) => Promise<number>
      }
      fs?: {
        write?: (path: string, content: string | Blob) => Promise<void>
        read?: (path: string) => Promise<Response>
        delete?: (path: string) => Promise<void>
        list?: (path: string) => Promise<any[]>
      }
      auth?: {
        isSignedIn?: () => boolean
        signIn?: () => Promise<void>
        getUser?: () => Promise<any>
      }
    }
  }
}

// AI model types
export type AIModel =
  // OpenAI models
  | "gpt-4o"
  | "gpt-4.1"
  | "gpt-4.1-mini"
  | "gpt-4.1-nano"
  | "gpt-4.5-preview"
  | "gpt-4o-mini"
  | "o1"
  | "o1-mini"
  | "o1-pro"
  | "o3"
  | "o3-mini"
  | "o4-mini"
  // Claude models
  | "claude-3-5-sonnet"
  | "claude-3-7-sonnet"
  // DeepSeek models
  | "deepseek-chat"
  | "deepseek-reasoner"

// Language types for TTS
export type Language = "en-US" | "vi-VN" | "fr-FR" | "de-DE" | "es-ES" | "it-IT" | "ja-JP" | "ko-KR" | "zh-CN"

// Puter client class
export class PuterClient {
  private static instance: PuterClient
  private _isLoaded = false
  private _isLoading = false
  private _loadError: Error | null = null
  private _loadPromise: Promise<boolean> | null = null

  private constructor() {}

  // Singleton pattern
  public static getInstance(): PuterClient {
    if (!PuterClient.instance) {
      PuterClient.instance = new PuterClient()
    }
    return PuterClient.instance
  }

  // Load Puter.js script
  public async load(): Promise<boolean> {
    // Return immediately if already loaded
    if (this._isLoaded && typeof window !== "undefined" && window.puter) {
      return true
    }

    // Return existing promise if loading
    if (this._isLoading && this._loadPromise) {
      return this._loadPromise
    }

    // Create new load promise
    this._isLoading = true
    this._loadPromise = new Promise<boolean>((resolve, reject) => {
      // Skip if not in browser
      if (typeof window === "undefined") {
        this._isLoading = false
        reject(new Error("Puter.js can only be loaded in browser environment"))
        return
      }

      // Skip if already loaded
      if (window.puter) {
        this._isLoaded = true
        this._isLoading = false
        resolve(true)
        return
      }

      try {
        const script = document.createElement("script")
        script.src = "https://js.puter.com/v2/"
        script.async = true

        script.onload = () => {
          this._isLoaded = true
          this._isLoading = false
          this._loadError = null
          resolve(true)
        }

        script.onerror = (e) => {
          this._isLoaded = false
          this._isLoading = false
          this._loadError = new Error("Failed to load Puter.js")
          console.error("Failed to load Puter.js", e)
          reject(this._loadError)
        }

        document.body.appendChild(script)
      } catch (err) {
        this._isLoading = false
        this._loadError = err instanceof Error ? err : new Error("Unknown error loading Puter.js")
        console.error("Error setting up Puter.js:", err)
        reject(this._loadError)
      }
    })

    return this._loadPromise
  }

  // Check if Puter.js is loaded
  public get isLoaded(): boolean {
    return this._isLoaded && typeof window !== "undefined" && !!window.puter
  }

  // Get load error
  public get loadError(): Error | null {
    return this._loadError
  }

  // AI methods

  // Generate text with AI
  public async generateText(
    prompt: string,
    model: AIModel = "gpt-4o",
    systemPrompt?: string,
    stream = false,
  ): Promise<any> {
    await this.load()

    if (!this.isLoaded || !window.puter?.ai?.chat) {
      throw new Error("Puter.js not loaded or AI chat not available")
    }

    try {
      const options: any = { model }

      if (systemPrompt) {
        // Different models use different parameter names for system prompts
        if (model.includes("claude")) {
          options.systemPrompt = systemPrompt
        } else {
          options.system = systemPrompt
        }
      }

      if (stream) {
        options.stream = true
      }

      return await window.puter.ai.chat(prompt, options)
    } catch (error) {
      console.error("Error generating text:", error)
      throw error
    }
  }

  // Generate image with AI
  public async generateImage(prompt: string): Promise<HTMLImageElement> {
    await this.load()

    if (!this.isLoaded || !window.puter?.ai?.txt2img) {
      throw new Error("Puter.js not loaded or AI image generation not available")
    }

    try {
      return await window.puter.ai.txt2img(prompt)
    } catch (error) {
      console.error("Error generating image:", error)
      throw error
    }
  }

  // Convert text to speech
  public async textToSpeech(text: string, language: Language = "vi-VN"): Promise<HTMLAudioElement> {
    await this.load()

    if (!this.isLoaded || !window.puter?.ai?.txt2speech) {
      throw new Error("Puter.js not loaded or text-to-speech not available")
    }

    try {
      return await window.puter.ai.txt2speech(text, language)
    } catch (error) {
      console.error("Error converting text to speech:", error)
      throw error
    }
  }

  // Key-Value Store methods

  // Set a value in the key-value store
  public async setValue(key: string, value: string): Promise<void> {
    await this.load()

    if (!this.isLoaded || !window.puter?.kv?.set) {
      throw new Error("Puter.js not loaded or key-value store not available")
    }

    try {
      return await window.puter.kv.set(key, value)
    } catch (error) {
      console.error("Error setting value:", error)
      throw error
    }
  }

  // Get a value from the key-value store
  public async getValue(key: string): Promise<string | null> {
    await this.load()

    if (!this.isLoaded || !window.puter?.kv?.get) {
      throw new Error("Puter.js not loaded or key-value store not available")
    }

    try {
      return await window.puter.kv.get(key)
    } catch (error) {
      console.error("Error getting value:", error)
      throw error
    }
  }

  // Delete a value from the key-value store
  public async deleteValue(key: string): Promise<void> {
    await this.load()

    if (!this.isLoaded || !window.puter?.kv?.del) {
      throw new Error("Puter.js not loaded or key-value store not available")
    }

    try {
      return await window.puter.kv.del(key)
    } catch (error) {
      console.error("Error deleting value:", error)
      throw error
    }
  }

  // List keys in the key-value store
  public async listKeys(pattern: string, withValues = false): Promise<any[]> {
    await this.load()

    if (!this.isLoaded || !window.puter?.kv?.list) {
      throw new Error("Puter.js not loaded or key-value store not available")
    }

    try {
      return await window.puter.kv.list(pattern, withValues)
    } catch (error) {
      console.error("Error listing keys:", error)
      throw error
    }
  }

  // Increment a value in the key-value store
  public async incrementValue(key: string): Promise<number> {
    await this.load()

    if (!this.isLoaded || !window.puter?.kv?.incr) {
      throw new Error("Puter.js not loaded or key-value store not available")
    }

    try {
      return await window.puter.kv.incr(key)
    } catch (error) {
      console.error("Error incrementing value:", error)
      throw error
    }
  }

  // File System methods

  // Write a file
  public async writeFile(path: string, content: string | Blob): Promise<void> {
    await this.load()

    if (!this.isLoaded || !window.puter?.fs?.write) {
      throw new Error("Puter.js not loaded or file system not available")
    }

    try {
      return await window.puter.fs.write(path, content)
    } catch (error) {
      console.error("Error writing file:", error)
      throw error
    }
  }

  // Read a file
  public async readFile(path: string): Promise<Response> {
    await this.load()

    if (!this.isLoaded || !window.puter?.fs?.read) {
      throw new Error("Puter.js not loaded or file system not available")
    }

    try {
      return await window.puter.fs.read(path)
    } catch (error) {
      console.error("Error reading file:", error)
      throw error
    }
  }

  // Delete a file
  public async deleteFile(path: string): Promise<void> {
    await this.load()

    if (!this.isLoaded || !window.puter?.fs?.delete) {
      throw new Error("Puter.js not loaded or file system not available")
    }

    try {
      return await window.puter.fs.delete(path)
    } catch (error) {
      console.error("Error deleting file:", error)
      throw error
    }
  }

  // List files
  public async listFiles(path: string): Promise<any[]> {
    await this.load()

    if (!this.isLoaded || !window.puter?.fs?.list) {
      throw new Error("Puter.js not loaded or file system not available")
    }

    try {
      return await window.puter.fs.list(path)
    } catch (error) {
      console.error("Error listing files:", error)
      throw error
    }
  }

  // Authentication methods

  // Check if user is signed in
  public async isSignedIn(): Promise<boolean> {
    await this.load()

    if (!this.isLoaded || !window.puter?.auth?.isSignedIn) {
      throw new Error("Puter.js not loaded or authentication not available")
    }

    try {
      return window.puter.auth.isSignedIn()
    } catch (error) {
      console.error("Error checking if signed in:", error)
      throw error
    }
  }

  // Sign in
  public async signIn(): Promise<void> {
    await this.load()

    if (!this.isLoaded || !window.puter?.auth?.signIn) {
      throw new Error("Puter.js not loaded or authentication not available")
    }

    try {
      return await window.puter.auth.signIn()
    } catch (error) {
      console.error("Error signing in:", error)
      throw error
    }
  }

  // Get user info
  public async getUser(): Promise<any> {
    await this.load()

    if (!this.isLoaded || !window.puter?.auth?.getUser) {
      throw new Error("Puter.js not loaded or authentication not available")
    }

    try {
      return await window.puter.auth.getUser()
    } catch (error) {
      console.error("Error getting user:", error)
      throw error
    }
  }
}

// Export singleton instance
export const puterClient = PuterClient.getInstance()

// Export default for convenience
export default puterClient
