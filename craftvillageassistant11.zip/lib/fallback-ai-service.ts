interface KeywordResponse {
  keywords: string[]
  response: string
}

class FallbackAIService {
  private responses: KeywordResponse[] = [
    {
      keywords: ["hello", "hi", "xin chào", "chào"],
      response:
        "Xin chào! Tôi là trợ lý AI của Làng Nghề Việt Nam. Tôi đang hoạt động ở chế độ dự phòng do không thể kết nối với dịch vụ AI đầy đủ. Tôi có thể giúp gì cho bạn?",
    },
    {
      keywords: ["làng nghề", "craft village", "village"],
      response:
        "Làng nghề Việt Nam có lịch sử lâu đời và đa dạng. Mỗi làng nghề thường chuyên về một sản phẩm thủ công cụ thể như gốm sứ, dệt may, mây tre đan, khảm trai, sơn mài, và nhiều nghề khác. Bạn quan tâm đến làng nghề nào cụ thể?",
    },
    {
      keywords: ["gốm", "ceramic", "pottery"],
      response:
        "Gốm sứ là một trong những nghề thủ công lâu đời nhất của Việt Nam. Các làng nghề gốm nổi tiếng bao gồm Bát Tràng (Hà Nội), Phù Lãng (Bắc Ninh), và Thanh Hà (Hội An). Mỗi làng nghề có kỹ thuật và phong cách riêng biệt.",
    },
    {
      keywords: ["mây tre", "bamboo", "rattan"],
      response:
        "Nghề đan lát mây tre là một nghề thủ công truyền thống của Việt Nam. Các sản phẩm phổ biến bao gồm giỏ, rổ, đồ nội thất và đồ trang trí. Làng nghề Phú Vinh (Hà Nội) và Bảo La (Thừa Thiên-Huế) nổi tiếng với các sản phẩm mây tre đan chất lượng cao.",
    },
    {
      keywords: ["dệt", "textile", "weaving", "thổ cẩm"],
      response:
        "Nghề dệt truyền thống của Việt Nam rất đa dạng, từ lụa, lanh, đến thổ cẩm. Mỗi vùng miền có kỹ thuật và họa tiết đặc trưng riêng. Làng Vạn Phúc (Hà Nội) nổi tiếng với lụa, trong khi các dân tộc thiểu số ở vùng cao phía Bắc và Tây Nguyên nổi tiếng với thổ cẩm đầy màu sắc.",
    },
    {
      keywords: ["sơn mài", "lacquer"],
      response:
        "Sơn mài là một nghề thủ công tinh xảo của Việt Nam, sử dụng nhựa cây sơn để tạo ra các sản phẩm có độ bóng và độ bền cao. Làng Hạ Thái (Hà Nội) và Tương Bình Hiệp (Bình Dương) là những trung tâm sơn mài nổi tiếng.",
    },
    {
      keywords: ["marketing", "tiếp thị", "quảng bá"],
      response:
        "Để tiếp thị sản phẩm làng nghề hiệu quả, bạn có thể: 1) Xây dựng câu chuyện về nguồn gốc và quy trình sản xuất, 2) Tham gia các hội chợ thương mại và triển lãm, 3) Sử dụng mạng xã hội để quảng bá sản phẩm, 4) Hợp tác với các cửa hàng lưu niệm và khách sạn, 5) Phát triển trải nghiệm du lịch tại làng nghề.",
    },
    {
      keywords: ["xuất khẩu", "export", "quốc tế", "international"],
      response:
        "Để xuất khẩu sản phẩm làng nghề, bạn cần: 1) Đảm bảo chất lượng và tính nhất quán của sản phẩm, 2) Tìm hiểu quy định và tiêu chuẩn của thị trường mục tiêu, 3) Tham gia các hội chợ thương mại quốc tế, 4) Xây dựng website chuyên nghiệp bằng nhiều ngôn ngữ, 5) Hợp tác với các đại lý phân phối hoặc nền tảng thương mại điện tử quốc tế.",
    },
    {
      keywords: ["thương hiệu", "brand", "branding"],
      response:
        "Xây dựng thương hiệu cho sản phẩm làng nghề cần: 1) Xác định giá trị cốt lõi và điểm khác biệt, 2) Thiết kế logo và bao bì phản ánh di sản văn hóa nhưng vẫn hiện đại, 3) Kể câu chuyện về nguồn gốc và quy trình sản xuất, 4) Đảm bảo chất lượng sản phẩm nhất quán, 5) Xây dựng sự hiện diện trực tuyến chuyên nghiệp.",
    },
    {
      keywords: ["thiết kế", "design", "sản phẩm mới", "new product"],
      response:
        "Để phát triển sản phẩm mới cho làng nghề: 1) Kết hợp kỹ thuật truyền thống với thiết kế hiện đại, 2) Nghiên cứu xu hướng thị trường và nhu cầu khách hàng, 3) Hợp tác với nhà thiết kế chuyên nghiệp, 4) Tạo ra sản phẩm đa chức năng và phù hợp với lối sống hiện đại, 5) Thử nghiệm sản phẩm với nhóm khách hàng mục tiêu trước khi sản xuất hàng loạt.",
    },
    {
      keywords: ["du lịch", "tourism", "travel"],
      response:
        "Du lịch làng nghề là cách tuyệt vời để quảng bá sản phẩm và tăng thu nhập. Bạn có thể: 1) Tổ chức tour tham quan quy trình sản xuất, 2) Tạo không gian cho khách tham gia làm thủ công, 3) Mở cửa hàng bán sản phẩm tại làng, 4) Kết hợp với các dịch vụ du lịch địa phương, 5) Tổ chức các sự kiện và lễ hội truyền thống.",
    },
    {
      keywords: ["bảo tồn", "preservation", "conservation"],
      response:
        "Bảo tồn nghề thủ công truyền thống rất quan trọng. Một số cách tiếp cận bao gồm: 1) Ghi lại và lưu trữ kỹ thuật truyền thống, 2) Đào tạo thế hệ trẻ, 3) Hiện đại hóa quy trình sản xuất mà không làm mất đi bản sắc, 4) Tạo ra các sản phẩm có giá trị cao hơn, 5) Phát triển du lịch làng nghề để tăng nhận thức và tạo thu nhập.",
    },
    {
      keywords: ["đào tạo", "training", "học nghề", "learn"],
      response:
        "Đào tạo nghề thủ công có thể thực hiện qua: 1) Chương trình học việc với nghệ nhân, 2) Lớp học tại các trung tâm đào tạo nghề, 3) Hội thảo và khóa học ngắn hạn, 4) Tài liệu và video hướng dẫn trực tuyến, 5) Chương trình trao đổi và học tập với các làng nghề khác.",
    },
    {
      keywords: ["khó khăn", "thách thức", "challenge", "problem"],
      response:
        "Các làng nghề thường đối mặt với nhiều thách thức như: 1) Cạnh tranh từ sản phẩm công nghiệp giá rẻ, 2) Thiếu lao động trẻ và có kỹ năng, 3) Khó khăn trong việc tiếp cận thị trường mới, 4) Vấn đề môi trường từ quy trình sản xuất truyền thống, 5) Thiếu vốn đầu tư để hiện đại hóa và mở rộng.",
    },
    {
      keywords: ["môi trường", "environment", "sustainable", "bền vững"],
      response:
        "Để phát triển làng nghề bền vững về môi trường: 1) Sử dụng nguyên liệu thân thiện với môi trường, 2) Cải tiến quy trình sản xuất để giảm chất thải và tiêu thụ năng lượng, 3) Tái chế và tái sử dụng vật liệu, 4) Đầu tư vào hệ thống xử lý chất thải, 5) Phát triển sản phẩm xanh và quảng bá giá trị bền vững.",
    },
    {
      keywords: ["tài chính", "finance", "vốn", "capital", "đầu tư", "investment"],
      response:
        "Các nguồn tài chính cho làng nghề bao gồm: 1) Chương trình hỗ trợ của chính phủ, 2) Vay vốn từ ngân hàng và tổ chức tài chính vi mô, 3) Đầu tư từ doanh nghiệp tư nhân, 4) Gọi vốn cộng đồng (crowdfunding), 5) Tài trợ từ các tổ chức phi chính phủ và quỹ phát triển quốc tế.",
    },
    {
      keywords: ["chính sách", "policy", "hỗ trợ", "support"],
      response:
        "Các chính sách hỗ trợ làng nghề thường bao gồm: 1) Ưu đãi thuế cho doanh nghiệp làng nghề, 2) Chương trình đào tạo và phát triển kỹ năng, 3) Hỗ trợ tham gia hội chợ và triển lãm, 4) Trợ giúp xây dựng thương hiệu và bảo hộ sở hữu trí tuệ, 5) Đầu tư vào cơ sở hạ tầng và không gian sản xuất.",
    },
    {
      keywords: ["sở hữu trí tuệ", "intellectual property", "bản quyền", "copyright"],
      response:
        "Bảo vệ sở hữu trí tuệ cho sản phẩm làng nghề bao gồm: 1) Đăng ký nhãn hiệu cho tên và logo, 2) Bảo hộ kiểu dáng công nghiệp cho thiết kế sản phẩm, 3) Đăng ký chỉ dẫn địa lý cho sản phẩm đặc trưng của vùng miền, 4) Bảo vệ bản quyền cho các mẫu thiết kế nghệ thuật, 5) Xây dựng chiến lược thực thi quyền sở hữu trí tuệ.",
    },
    {
      keywords: ["hợp tác", "collaboration", "partnership"],
      response:
        "Hợp tác có thể giúp phát triển làng nghề thông qua: 1) Liên kết giữa các nghệ nhân để chia sẻ kiến thức và nguồn lực, 2) Hợp tác với nhà thiết kế và nghệ sĩ đương đại, 3) Đối tác với các trường đại học và viện nghiên cứu, 4) Liên kết với công ty du lịch và khách sạn, 5) Hợp tác quốc tế với các tổ chức nghề thủ công tương tự.",
    },
    {
      keywords: ["công nghệ", "technology", "số hóa", "digital"],
      response:
        "Ứng dụng công nghệ trong làng nghề có thể bao gồm: 1) Sử dụng thương mại điện tử để mở rộng thị trường, 2) Áp dụng công nghệ trong một số công đoạn sản xuất để tăng hiệu quả, 3) Sử dụng phần mềm thiết kế để phát triển sản phẩm mới, 4) Ứng dụng công nghệ thực tế ảo/thực tế tăng cường trong trải nghiệm du lịch, 5) Sử dụng mạng xã hội và tiếp thị số để quảng bá sản phẩm.",
    },
    {
      keywords: ["help", "giúp đỡ", "trợ giúp"],
      response:
        "Tôi có thể giúp bạn với thông tin về làng nghề Việt Nam, chiến lược marketing, phát triển sản phẩm, xây dựng thương hiệu, xuất khẩu, du lịch làng nghề, và nhiều chủ đề khác liên quan đến phát triển làng nghề. Vui lòng cho tôi biết bạn cần thông tin cụ thể về vấn đề gì?",
    },
  ]

  generateResponse(prompt: string): { message: { content: string } } {
    const lowerPrompt = prompt.toLowerCase()

    // Find matching keywords
    for (const item of this.responses) {
      if (item.keywords.some((keyword) => lowerPrompt.includes(keyword.toLowerCase()))) {
        return { message: { content: item.response } }
      }
    }

    // Default response if no keywords match
    return {
      message: {
        content:
          "Xin lỗi, tôi đang hoạt động ở chế độ dự phòng và không thể trả lời câu hỏi này. Vui lòng thử lại sau khi kết nối internet được cải thiện, hoặc hỏi về các chủ đề liên quan đến làng nghề Việt Nam như: gốm sứ, mây tre đan, dệt may, sơn mài, marketing, xuất khẩu, thương hiệu, thiết kế sản phẩm, du lịch làng nghề, bảo tồn nghề truyền thống.",
      },
    }
  }
}

export const fallbackAIService = new FallbackAIService()
