import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ""

export const supabase = createClient(supabaseUrl, supabaseKey)

// Craft village data functions
export async function getCraftVillages() {
  const { data, error } = await supabase.from("craft_villages").select("*")

  if (error) throw error
  return data
}

export async function getCraftVillageById(id: number) {
  const { data, error } = await supabase.from("craft_villages").select("*").eq("id", id).single()

  if (error) throw error
  return data
}

// Product data functions
export async function getProducts(filters: any = {}) {
  let query = supabase.from("products").select("*")

  // Apply filters
  if (filters.craftType) {
    query = query.eq("craft_type", filters.craftType)
  }

  if (filters.priceRange) {
    query = query.gte("price", filters.priceRange[0]).lte("price", filters.priceRange[1])
  }

  const { data, error } = await query

  if (error) throw error
  return data
}

// Cultural library functions
export async function getCulturalLibraryItems(type: string) {
  const { data, error } = await supabase.from("cultural_library").select("*").eq("type", type)

  if (error) throw error
  return data
}
