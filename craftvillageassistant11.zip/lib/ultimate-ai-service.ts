import { loadPuter, isPuterLoaded } from "./script-loader"
import { fallbackAIService } from "./fallback-ai-service"

export type AIModel =
  // Claude models
  | "claude-3-5-sonnet"
  | "claude-3-7-sonnet"
  // DeepSeek models
  | "deepseek-chat"
  | "deepseek-reasoner"
  // OpenAI models
  | "gpt-4o"
  | "gpt-4.1"
  | "o1-mini"
  | "o3-mini"

export interface ChatOptions {
  model?: AIModel
  stream?: boolean
  systemPrompt?: string
  temperature?: number
  maxTokens?: number
}

export interface ChatMessage {
  role: "user" | "assistant" | "system"
  content: string
}

export interface ImageGenerationOptions {
  size?: "1024x1024" | "1792x1024" | "1024x1792"
  quality?: "standard" | "hd"
  style?: "vivid" | "natural"
}

export interface TTSOptions {
  language?: string
  voice?: string
}

export interface KVOptions {
  namespace?: string
}

class UltimateAIService {
  private puterLoaded = false
  private loadingPromise: Promise<boolean> | null = null
  private defaultModel: AIModel = "gpt-4o"
  private fallbackMode = false

  constructor() {
    // Initialize in browser environment only
    if (typeof window !== "undefined") {
      this.initialize()
    }
  }

  private async initialize(): Promise<boolean> {
    if (this.loadingPromise) return this.loadingPromise

    this.loadingPromise = new Promise(async (resolve) => {
      try {
        // Check if Puter is already loaded
        if (isPuterLoaded()) {
          console.log("Puter.js already loaded")
          this.puterLoaded = true
          resolve(true)
          return
        }

        // Try to load Puter.js
        console.log("Loading Puter.js...")
        const loaded = await loadPuter(3)

        this.puterLoaded = loaded
        this.fallbackMode = !loaded

        if (loaded) {
          console.log("Puter.js loaded successfully")
        } else {
          console.warn("Failed to load Puter.js, using fallback mode")
        }

        resolve(loaded)
      } catch (error) {
        console.error("Error initializing UltimateAIService:", error)
        this.fallbackMode = true
        resolve(false)
      }
    })

    return this.loadingPromise
  }

  /**
   * Ensure Puter.js is loaded before performing operations
   */
  private async ensurePuter(): Promise<boolean> {
    if (this.puterLoaded) return true
    return this.initialize()
  }

  /**
   * Chat with an AI model
   */
  async chat(prompt: string, options: ChatOptions = {}): Promise<any> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      return fallbackAIService.generateResponse(prompt)
    }

    try {
      const model = options.model || this.defaultModel
      return await window.puter.ai.chat(prompt, {
        model,
        stream: options.stream || false,
        temperature: options.temperature,
        max_tokens: options.maxTokens,
        system: options.systemPrompt,
      })
    } catch (error) {
      console.error("Error in chat:", error)
      return fallbackAIService.generateResponse(prompt)
    }
  }

  /**
   * Chat with conversation history
   */
  async chatWithHistory(messages: ChatMessage[], options: ChatOptions = {}): Promise<any> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      const lastMessage = messages[messages.length - 1]
      return fallbackAIService.generateResponse(lastMessage.content)
    }

    try {
      const model = options.model || this.defaultModel
      return await window.puter.ai.chat(messages, {
        model,
        stream: options.stream || false,
        temperature: options.temperature,
        max_tokens: options.maxTokens,
      })
    } catch (error) {
      console.error("Error in chatWithHistory:", error)
      const lastMessage = messages[messages.length - 1]
      return fallbackAIService.generateResponse(lastMessage.content)
    }
  }

  /**
   * Generate an image from text
   */
  async generateImage(prompt: string, options: ImageGenerationOptions = {}): Promise<HTMLImageElement | null> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      console.warn("Image generation not available in fallback mode")
      return null
    }

    try {
      return await window.puter.ai.txt2img(prompt, options)
    } catch (error) {
      console.error("Error in generateImage:", error)
      return null
    }
  }

  /**
   * Convert text to speech
   */
  async textToSpeech(text: string, options: TTSOptions = {}): Promise<HTMLAudioElement | null> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      console.warn("Text-to-speech not available in fallback mode")
      return null
    }

    try {
      return await window.puter.ai.txt2speech(text, options.language)
    } catch (error) {
      console.error("Error in textToSpeech:", error)
      return null
    }
  }

  /**
   * Store a value in the key-value store
   */
  async storeValue(key: string, value: string, options: KVOptions = {}): Promise<boolean> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      console.warn("Key-value store not available in fallback mode")
      // Use localStorage as fallback
      try {
        localStorage.setItem(`puter_kv_${key}`, value)
        return true
      } catch (e) {
        console.error("Error using localStorage fallback:", e)
        return false
      }
    }

    try {
      await window.puter.kv.set(key, value, options.namespace)
      return true
    } catch (error) {
      console.error("Error in storeValue:", error)
      return false
    }
  }

  /**
   * Retrieve a value from the key-value store
   */
  async getValue(key: string, options: KVOptions = {}): Promise<string | null> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      console.warn("Key-value store not available in fallback mode")
      // Use localStorage as fallback
      try {
        return localStorage.getItem(`puter_kv_${key}`)
      } catch (e) {
        console.error("Error using localStorage fallback:", e)
        return null
      }
    }

    try {
      return await window.puter.kv.get(key, options.namespace)
    } catch (error) {
      console.error("Error in getValue:", error)
      return null
    }
  }

  /**
   * Delete a value from the key-value store
   */
  async deleteValue(key: string, options: KVOptions = {}): Promise<boolean> {
    await this.ensurePuter()

    if (this.fallbackMode) {
      console.warn("Key-value store not available in fallback mode")
      // Use localStorage as fallback
      try {
        localStorage.removeItem(`puter_kv_${key}`)
        return true
      } catch (e) {
        console.error("Error using localStorage fallback:", e)
        return false
      }
    }

    try {
      await window.puter.kv.del(key, options.namespace)
      return true
    } catch (error) {
      console.error("Error in deleteValue:", error)
      return false
    }
  }

  /**
   * Check if the service is in fallback mode
   */
  isFallbackMode(): boolean {
    return this.fallbackMode
  }

  /**
   * Set the default AI model
   */
  setDefaultModel(model: AIModel): void {
    this.defaultModel = model
  }

  /**
   * Get the current default AI model
   */
  getDefaultModel(): AIModel {
    return this.defaultModel
  }

  /**
   * Retry loading Puter.js
   */
  async retryLoading(): Promise<boolean> {
    this.loadingPromise = null
    const result = await this.initialize()
    this.fallbackMode = !result
    return result
  }
}

// Create a singleton instance
export const ultimateAIService = new UltimateAIService()
