"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Save } from "lucide-react"
import puterClient from "@/lib/puter-client"

interface UserPreferences {
  theme: string
  language: string
  notifications: boolean
  defaultModel: string
}

const defaultPreferences: UserPreferences = {
  theme: "light",
  language: "vi",
  notifications: true,
  defaultModel: "deepseek-chat",
}

function UserPreferences() {
  const [preferences, setPreferences] = useState<UserPreferences>(defaultPreferences)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isSignedIn, setIsSignedIn] = useState(false)
  const [message, setMessage] = useState("")

  useEffect(() => {
    const initializePreferences = async () => {
      setIsLoading(true)

      // Initialize Puter.js
      await puterClient.init()

      // Check if user is signed in
      const signedIn = puterClient.auth.isSignedIn()
      setIsSignedIn(signedIn)

      if (signedIn) {
        // Load preferences from KV store
        const storedPreferences = await puterClient.kv.getValue("user_preferences")

        if (storedPreferences) {
          setPreferences(storedPreferences)
        }
      }

      setIsLoading(false)
    }

    initializePreferences()
  }, [])

  const handleSignIn = async () => {
    setIsLoading(true)
    await puterClient.auth.signIn()
    setIsSignedIn(true)
    setIsLoading(false)
  }

  const handleSignOut = async () => {
    setIsLoading(true)
    await puterClient.auth.signOut()
    setIsSignedIn(false)
    setPreferences(defaultPreferences)
    setIsLoading(false)
  }

  const savePreferences = async () => {
    setIsSaving(true)
    setMessage("")

    if (!isSignedIn) {
      await handleSignIn()
    }

    const success = await puterClient.kv.setValue("user_preferences", preferences)

    if (success) {
      setMessage("Đã lưu thành công!")
    } else {
      setMessage("Lỗi khi lưu. Vui lòng thử lại.")
    }

    setIsSaving(false)

    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage("")
    }, 3000)
  }

  if (isLoading) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-earth-600" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Tùy chọn người dùng</CardTitle>
        <CardDescription>Điều chỉnh cài đặt cho trải nghiệm của bạn</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="theme">Giao diện</Label>
          <Select value={preferences.theme} onValueChange={(value) => setPreferences({ ...preferences, theme: value })}>
            <SelectTrigger id="theme">
              <SelectValue placeholder="Chọn giao diện" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Sáng</SelectItem>
              <SelectItem value="dark">Tối</SelectItem>
              <SelectItem value="system">Theo hệ thống</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="language">Ngôn ngữ</Label>
          <Select
            value={preferences.language}
            onValueChange={(value) => setPreferences({ ...preferences, language: value })}
          >
            <SelectTrigger id="language">
              <SelectValue placeholder="Chọn ngôn ngữ" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="vi">Tiếng Việt</SelectItem>
              <SelectItem value="en">English</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="model">Model AI mặc định</Label>
          <Select
            value={preferences.defaultModel}
            onValueChange={(value) => setPreferences({ ...preferences, defaultModel: value })}
          >
            <SelectTrigger id="model">
              <SelectValue placeholder="Chọn model AI" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="deepseek-chat">DeepSeek Chat</SelectItem>
              <SelectItem value="deepseek-reasoner">DeepSeek Reasoner</SelectItem>
              <SelectItem value="gpt-4o">GPT-4o</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="notifications" className="flex-grow">
            Thông báo
          </Label>
          <Switch
            id="notifications"
            checked={preferences.notifications}
            onCheckedChange={(checked) => setPreferences({ ...preferences, notifications: checked })}
          />
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-4">
        <div className="w-full flex justify-between">
          <Button variant="outline" onClick={isSignedIn ? handleSignOut : handleSignIn}>
            {isSignedIn ? "Đăng xuất" : "Đăng nhập"}
          </Button>

          <Button onClick={savePreferences} disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang lưu...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" /> Lưu cài đặt
              </>
            )}
          </Button>
        </div>

        {message && (
          <p className={`text-sm text-center ${message.includes("Lỗi") ? "text-red-500" : "text-green-500"}`}>
            {message}
          </p>
        )}
      </CardFooter>
    </Card>
  )
}

export { UserPreferences }
export default UserPreferences
