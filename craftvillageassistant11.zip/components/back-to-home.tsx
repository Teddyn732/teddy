"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Home } from "lucide-react"

export function BackToHome() {
  const router = useRouter()

  return (
    <Button
      variant="outline"
      size="sm"
      className="fixed bottom-4 right-4 z-50 flex items-center gap-2 shadow-md"
      onClick={() => router.push("/")}
    >
      <Home className="h-4 w-4" />
      <span>Về trang chủ</span>
    </Button>
  )
}
