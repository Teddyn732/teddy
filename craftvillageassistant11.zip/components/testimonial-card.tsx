interface TestimonialCardProps {
  name: string
  role: string
  quote: string
  imageSrc: string
  craftType: string
}

export function TestimonialCard({ name, role, quote, imageSrc, craftType }: TestimonialCardProps) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-earth-100 hover-lift transition-all">
      <div className="flex items-center gap-3 mb-4">
        <div className="relative">
          <img
            src={imageSrc || "/placeholder.svg"}
            alt={name}
            className="w-16 h-16 rounded-full object-cover transition-all duration-300 hover:scale-105"
          />
          <div className="absolute -bottom-1 -right-1 bg-terracotta text-white text-xs px-2 py-1 rounded-full">
            {craftType}
          </div>
        </div>
        <div>
          <h4 className="font-bold text-earth-900">{name}</h4>
          <p className="text-sm text-earth-600">{role}</p>
        </div>
      </div>
      <p className="text-earth-700 italic">"{quote}"</p>
    </div>
  )
}
