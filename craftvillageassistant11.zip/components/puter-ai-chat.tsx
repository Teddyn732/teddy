"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ImageIcon, Send, RefreshCw } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Mock responses for when the API is unavailable
const mockResponses = {
  vi: [
    "Xin chào! Tôi là trợ lý AI Nghệ Nhân Số. Tôi có thể giúp gì cho bạn về làng nghề truyền thống Việt Nam?",
    "Làng nghề truyền thống Việt Nam có lịch sử phát triển lâu đời, với nhiều sản phẩm thủ công mỹ nghệ nổi tiếng như gốm Bát Tràng, lụa Vạn Phúc, và tranh dân gian Đông Hồ.",
    "Để phát triển thương hiệu cho sản phẩm làng nghề, bạn cần xây dựng câu chuyện về nguồn gốc, quy trình sản xuất, và giá trị văn hóa của sản phẩm.",
    "Chụp ảnh sản phẩm đẹp là rất quan trọng khi bán hàng online. Bạn nên sử dụng ánh sáng tự nhiên, nền đơn giản, và chụp nhiều góc độ khác nhau.",
    "Bạn muốn tôi hỗ trợ gì tiếp theo không ạ?",
  ],
  en: [
    "Hello! I'm the Digital Artisan AI Assistant. How can I help you with Vietnamese traditional craft villages?",
    "Vietnamese traditional craft villages have a long history, with many famous handicraft products such as Bat Trang pottery, Van Phuc silk, and Dong Ho folk paintings.",
    "To develop a brand for craft village products, you need to build a story about the origin, production process, and cultural value of the product.",
    "Taking good product photos is very important when selling online. You should use natural light, simple backgrounds, and capture multiple angles.",
    "Is there anything else I can help you with?",
  ],
}

export default function PuterAIChat() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [chatHistory, setChatHistory] = useState<Array<{ role: string; content: string; isImage?: boolean }>>([])
  const [selectedModel, setSelectedModel] = useState("gpt-4o")
  const [isGeneratingImage, setIsGeneratingImage] = useState(false)
  const [imagePrompt, setImagePrompt] = useState("")
  const responseRef = useRef<HTMLDivElement>(null)
  const [scriptLoaded, setScriptLoaded] = useState(false)
  const [scriptError, setScriptError] = useState(false)
  const [isLoadingScript, setIsLoadingScript] = useState(false)
  const [retryCount, setRetryCount] = useState(0)

  // Function to load Puter.js script
  const loadPuterScript = () => {
    // Skip if already loaded or loading
    if (typeof window === "undefined" || window.puter || isLoadingScript) {
      if (window.puter) setScriptLoaded(true)
      return
    }

    setIsLoadingScript(true)
    setScriptError(false)

    try {
      // Create a new script element
      const script = document.createElement("script")
      script.src = "https://js.puter.com/v2/"
      script.async = true

      // Add event handlers
      script.onload = () => {
        console.log("Puter.js loaded successfully")
        setScriptLoaded(true)
        setScriptError(false)
        setIsLoadingScript(false)
      }

      script.onerror = (e) => {
        console.error("Failed to load Puter.js", e)
        setScriptLoaded(false)
        setScriptError(true)
        setIsLoadingScript(false)
      }

      // Append the script to the document
      document.body.appendChild(script)
    } catch (err) {
      console.error("Error setting up Puter.js:", err)
      setScriptError(true)
      setScriptLoaded(false)
      setIsLoadingScript(false)
    }
  }

  // Try to load Puter.js on component mount
  useEffect(() => {
    // Check if Puter is already available
    if (typeof window !== "undefined" && window.puter) {
      setScriptLoaded(true)
      return
    }

    // Load the script
    loadPuterScript()
  }, [retryCount])

  // Function to get a random mock response
  const getMockResponse = () => {
    const responses = mockResponses.vi // Default to Vietnamese
    const randomIndex = Math.floor(Math.random() * responses.length)
    return responses[randomIndex]
  }

  // Function to retry loading the script
  const handleRetryScriptLoad = () => {
    setRetryCount((prev) => prev + 1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    setIsLoading(true)
    setError(null)

    // Add user message to chat history
    const updatedHistory = [...chatHistory, { role: "user", content: prompt }]
    setChatHistory(updatedHistory)

    try {
      // Check if Puter.js is available
      if (typeof window !== "undefined" && window.puter && window.puter.ai && window.puter.ai.chat && scriptLoaded) {
        try {
          // Create system prompt based on the context of craft villages
          const systemPrompt =
            "Bạn là trợ lý AI Nghệ Nhân Số, chuyên về làng nghề truyền thống Việt Nam. " +
            "Hãy cung cấp thông tin chính xác và hữu ích về các làng nghề, sản phẩm thủ công, " +
            "và cách phát triển thương hiệu cho các sản phẩm làng nghề."

          // Call Puter.js API
          const result = await window.puter.ai.chat(prompt, {
            model: selectedModel,
            systemPrompt: systemPrompt,
          })

          // Handle different response formats
          let responseText = ""

          if (typeof result === "string") {
            responseText = result
          } else if (result && typeof result === "object") {
            // Handle DeepSeek response format
            if (result.message && result.message.content) {
              responseText = result.message.content
            } else if (result.message && typeof result.message === "string") {
              responseText = result.message
            } else if (result.content && typeof result.content === "string") {
              responseText = result.content
            } else if (result.toString && typeof result.toString === "function") {
              responseText = result.toString()
            } else {
              // Fallback to mock response
              responseText = getMockResponse()
            }
          } else {
            responseText = getMockResponse()
          }

          // Add assistant response to chat history
          setChatHistory([...updatedHistory, { role: "assistant", content: responseText }])
        } catch (puterError) {
          console.error("Puter.js error:", puterError)
          const mockResponse = getMockResponse()
          setChatHistory([...updatedHistory, { role: "assistant", content: mockResponse }])
        }
      } else {
        // Use mock response if Puter.js isn't available
        setTimeout(() => {
          const mockResponse = getMockResponse()
          setChatHistory([...updatedHistory, { role: "assistant", content: mockResponse }])
        }, 1000) // Add a small delay to simulate API call
      }
    } catch (err: any) {
      console.error("Error:", err)
      setError(err.message || "An error occurred")

      // Add error message to chat history
      const errorMessage = "Xin lỗi, đã xảy ra lỗi. Vui lòng thử lại sau."
      setChatHistory([...updatedHistory, { role: "assistant", content: errorMessage }])
    } finally {
      setIsLoading(false)
      setPrompt("")
      // Scroll to response
      setTimeout(() => {
        responseRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }

  const generateImage = async () => {
    if (!imagePrompt.trim()) return

    setIsGeneratingImage(true)
    setError(null)

    try {
      if (typeof window !== "undefined" && window.puter && window.puter.ai && window.puter.ai.txt2img && scriptLoaded) {
        const imageElement = await window.puter.ai.txt2img(imagePrompt)

        // Add the image prompt to chat history
        setChatHistory([
          ...chatHistory,
          {
            role: "user",
            content: `Tạo hình ảnh: ${imagePrompt}`,
          },
        ])

        // Add the image to chat history
        if (imageElement && imageElement.src) {
          setChatHistory((prev) => [
            ...prev,
            {
              role: "assistant",
              content: imageElement.src,
              isImage: true,
            },
          ])
        } else {
          throw new Error("Không thể tạo hình ảnh")
        }
      } else {
        throw new Error("Puter.js không khả dụng")
      }
    } catch (err: any) {
      console.error("Error generating image:", err)
      setError(err.message || "Lỗi khi tạo hình ảnh")

      // Add error message to chat history
      setChatHistory((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Xin lỗi, không thể tạo hình ảnh. Vui lòng thử lại sau.",
        },
      ])
    } finally {
      setIsGeneratingImage(false)
      setImagePrompt("")
      // Scroll to response
      setTimeout(() => {
        responseRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }

  return (
    <Card className="w-full max-w-3xl mx-auto mt-8">
      <CardHeader>
        <CardTitle>Trò chuyện với Nghệ Nhân Số</CardTitle>
        <div className="flex items-center gap-2 mt-2">
          <span className="text-sm text-gray-500">Model:</span>
          <Select value={selectedModel} onValueChange={setSelectedModel}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Chọn model" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gpt-4o">GPT-4o</SelectItem>
              <SelectItem value="gpt-4.1">GPT-4.1</SelectItem>
              <SelectItem value="o1-mini">O1-mini</SelectItem>
              <SelectItem value="o3-mini">O3-mini</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {scriptError && (
          <Alert variant="destructive" className="mt-2">
            <div className="flex justify-between items-center">
              <AlertDescription>Không thể tải Puter.js. Đang sử dụng chế độ dự phòng.</AlertDescription>
              <Button variant="outline" size="sm" onClick={handleRetryScriptLoad} disabled={isLoadingScript}>
                {isLoadingScript ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4 mr-1" />
                )}
                Thử lại
              </Button>
            </div>
          </Alert>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-[500px] overflow-y-auto mb-4">
          {chatHistory.length === 0 ? (
            <div className="text-center text-gray-500 py-8">Hãy đặt câu hỏi về làng nghề truyền thống Việt Nam</div>
          ) : (
            chatHistory.map((message, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg ${
                  message.role === "user"
                    ? "bg-blue-100 ml-auto max-w-[80%] text-right"
                    : "bg-gray-100 mr-auto max-w-[80%]"
                }`}
              >
                {message.isImage ? (
                  <img
                    src={message.content || "/placeholder.svg"}
                    alt="Generated image"
                    className="rounded-md max-w-full"
                  />
                ) : (
                  <div className="whitespace-pre-wrap">{message.content}</div>
                )}
              </div>
            ))
          )}
          {isLoading && (
            <div className="bg-gray-100 p-3 rounded-lg flex items-center">
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              Đang trả lời...
            </div>
          )}
          {isGeneratingImage && (
            <div className="bg-gray-100 p-3 rounded-lg flex items-center">
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              Đang tạo hình ảnh...
            </div>
          )}
          {error && <div className="bg-red-50 p-3 rounded-lg text-red-500 text-sm">Lỗi: {error}</div>}
          <div ref={responseRef} />
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-4">
        <form onSubmit={handleSubmit} className="w-full flex gap-2">
          <Textarea
            placeholder="Nhập câu hỏi của bạn về làng nghề truyền thống..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[50px] flex-grow"
            disabled={isLoading}
          />
          <Button type="submit" disabled={isLoading || !prompt.trim()}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang gửi...
              </>
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>

        <div className="w-full border-t pt-4">
          <div className="flex items-center gap-2 mb-2">
            <ImageIcon className="h-4 w-4" />
            <span className="text-sm font-medium">Tạo hình ảnh với DALL-E</span>
          </div>
          <div className="flex gap-2">
            <Textarea
              placeholder="Mô tả hình ảnh bạn muốn tạo..."
              value={imagePrompt}
              onChange={(e) => setImagePrompt(e.target.value)}
              className="min-h-[50px] flex-grow"
              disabled={isGeneratingImage || !scriptLoaded}
            />
            <Button
              type="button"
              onClick={generateImage}
              disabled={isGeneratingImage || !imagePrompt.trim() || !scriptLoaded}
              variant="outline"
            >
              {isGeneratingImage ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Đang tạo...
                </>
              ) : (
                "Tạo"
              )}
            </Button>
          </div>
          {!scriptLoaded && (
            <p className="text-xs text-gray-500 mt-1">
              {scriptError ? "Tính năng tạo hình ảnh không khả dụng do lỗi tải Puter.js" : "Đang tải Puter.js..."}
            </p>
          )}
        </div>
      </CardFooter>
    </Card>
  )
}
