import Link from "next/link"

interface CraftCategoryCardProps {
  title: string
  description: string
  imageSrc: string
  href: string
}

export function CraftCategoryCard({ title, description, imageSrc, href }: CraftCategoryCardProps) {
  return (
    <Link href={href} className="block">
      <div className="bg-white rounded-xl overflow-hidden shadow-md hover-lift transition-all border border-earth-100 h-full">
        <div className="h-48 overflow-hidden">
          <img
            src={imageSrc || "/placeholder.svg"}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
        </div>
        <div className="p-4">
          <h3 className="font-bold text-xl text-earth-900 mb-1">{title}</h3>
          <p className="text-earth-600">{description}</p>
        </div>
      </div>
    </Link>
  )
}
