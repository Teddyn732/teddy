import { MessageSquare, BookOpen, Users } from "lucide-react"
import { FeatureCard } from "@/components/feature-card"
import { ScrollReveal } from "@/components/scroll-reveal"

export function FeatureSection() {
  return (
    <section className="bg-earth-50 py-16">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <h2 className="text-3xl font-bold text-earth-900 mb-3 text-center">Giải pháp toàn diện</h2>
          <p className="text-xl text-earth-700 mb-12 text-center max-w-3xl mx-auto">
            Hỗ trợ từ quy trình sản xuất đến thương mại hóa và phát triển doanh nghiệp
          </p>
        </ScrollReveal>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-children">
          <ScrollReveal delay={100}>
            <FeatureCard
              icon={<MessageSquare className="h-10 w-10 text-terracotta" />}
              title="Trợ lý AI thông minh"
              description="Trò chuyện với AI để nhận hướng dẫn cá nhân hóa về quy trình sản xuất, định giá sản phẩm, và chiến lược kinh doanh."
            />
          </ScrollReveal>
          <ScrollReveal delay={200}>
            <FeatureCard
              icon={<BookOpen className="h-10 w-10 text-terracotta" />}
              title="Kho kiến thức phong phú"
              description="Thư viện bài viết, video hướng dẫn và tài liệu về marketing, chụp ảnh sản phẩm, và bán hàng trực tuyến."
            />
          </ScrollReveal>
          <ScrollReveal delay={300}>
            <FeatureCard
              icon={<Users className="h-10 w-10 text-terracotta" />}
              title="Cộng đồng hỗ trợ"
              description="Kết nối với các nghệ nhân khác, chuyên gia tư vấn và mentor đồng hành trong hành trình phát triển."
            />
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
