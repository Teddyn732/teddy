"use client"

import { useState, useEffect } from "react"
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet"
import "leaflet/dist/leaflet.css"
import { Icon } from "leaflet"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Info, Navigation, AlertTriangle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Define custom marker icon with fallback
const getCustomIcon = () => {
  try {
    return new Icon({
      iconUrl: "/images/craft-marker.png",
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      popupAnchor: [0, -32],
    })
  } catch (error) {
    // Fallback to default icon if custom icon fails to load
    return new Icon({
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
    })
  }
}

// Village data type
interface CraftVillage {
  id: number
  name: string
  craftType: string
  description: string
  latitude: number
  longitude: number
  imageUrl: string
}

// Sample data to use when API fails
const sampleVillages: CraftVillage[] = [
  {
    id: 1,
    name: "Làng gốm Bát Tràng",
    craftType: "Gốm sứ",
    description: "Làng gốm nổi tiếng với lịch sử hơn 700 năm, chuyên sản xuất đồ gốm sứ cao cấp.",
    latitude: 21.0157,
    longitude: 105.9131,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    name: "Làng lụa Vạn Phúc",
    craftType: "Dệt may",
    description: "Làng nghề dệt lụa truyền thống với các sản phẩm lụa cao cấp.",
    latitude: 20.9775,
    longitude: 105.7539,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    name: "Làng mây tre đan Phú Vinh",
    craftType: "Mây tre",
    description: "Làng nghề chuyên sản xuất các sản phẩm thủ công từ mây tre đan.",
    latitude: 20.8157,
    longitude: 105.7131,
    imageUrl: "/placeholder.svg?height=200&width=300",
  },
]

export function CraftVillageMap() {
  const [villages, setVillages] = useState<CraftVillage[]>([])
  const [selectedVillage, setSelectedVillage] = useState<CraftVillage | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isUsingFallback, setIsUsingFallback] = useState(false)
  const customIcon = getCustomIcon()

  // Fetch craft villages data
  useEffect(() => {
    async function fetchVillages() {
      try {
        const response = await fetch("/api/craft-villages")
        if (!response.ok) throw new Error("Failed to fetch villages")
        const data = await response.json()
        setVillages(data.length > 0 ? data : sampleVillages)
      } catch (error) {
        console.error("Error fetching villages:", error)
        setVillages(sampleVillages)
        setIsUsingFallback(true)
      } finally {
        setIsLoading(false)
      }
    }

    fetchVillages()
  }, [])

  // Handle village selection
  const handleVillageSelect = (village: CraftVillage) => {
    setSelectedVillage(village)
  }

  // Get directions to village
  const getDirections = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, "_blank")
  }

  if (isLoading) {
    return <div className="flex justify-center items-center h-96">Loading map...</div>
  }

  return (
    <div className="space-y-4">
      {isUsingFallback && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>Đang sử dụng dữ liệu mẫu. Kết nối API không khả dụng.</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[600px]">
        <div className="md:col-span-2 h-full">
          <MapContainer
            center={[21.0285, 105.8542]} // Hanoi center
            zoom={8}
            style={{ height: "100%", width: "100%" }}
          >
            {/* Always use OpenStreetMap as it doesn't require an API key */}
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />

            {villages.map((village) => (
              <Marker
                key={village.id}
                position={[village.latitude, village.longitude]}
                icon={customIcon}
                eventHandlers={{
                  click: () => handleVillageSelect(village),
                }}
              >
                <Popup>
                  <div>
                    <h3 className="font-bold">{village.name}</h3>
                    <p className="text-sm">{village.craftType}</p>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="overflow-y-auto">
          {selectedVillage ? (
            <Card>
              <CardHeader>
                <CardTitle>{selectedVillage.name}</CardTitle>
                <CardDescription>{selectedVillage.craftType}</CardDescription>
              </CardHeader>
              <CardContent>
                <img
                  src={selectedVillage.imageUrl || "/placeholder.svg?height=200&width=300"}
                  alt={selectedVillage.name}
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <p className="text-sm mb-4">{selectedVillage.description}</p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => getDirections(selectedVillage.latitude, selectedVillage.longitude)}
                  >
                    <Navigation className="h-4 w-4 mr-2" />
                    Chỉ đường
                  </Button>
                  <Button className="flex-1">
                    <Info className="h-4 w-4 mr-2" />
                    Xem chi tiết
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Bản đồ làng nghề</CardTitle>
                <CardDescription>Chọn một làng nghề trên bản đồ để xem thông tin chi tiết</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {villages.slice(0, 5).map((village) => (
                    <Button
                      key={village.id}
                      variant="ghost"
                      className="w-full justify-start text-left"
                      onClick={() => handleVillageSelect(village)}
                    >
                      {village.name} - {village.craftType}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
