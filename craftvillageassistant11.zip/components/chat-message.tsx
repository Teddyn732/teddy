"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Copy, ThumbsUp, ThumbsDown } from "lucide-react"

interface ChatMessageProps {
  message: {
    role: string
    content: string
  }
  language: string
}

export function ChatMessage({ message, language }: ChatMessageProps) {
  const isUser = message.role === "user"
  const [isCopied, setIsCopied] = useState(false)
  const [feedback, setFeedback] = useState<"like" | "dislike" | null>(null)
  const isVietnamese = language === "vi"

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content)
    setIsCopied(true)
    setTimeout(() => setIsCopied(false), 2000)
  }

  const handleFeedback = (type: "like" | "dislike") => {
    setFeedback(type)
    // In a real app, you would send this feedback to your backend
  }

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`flex gap-3 max-w-3xl ${isUser ? "flex-row-reverse" : ""}`}>
        <Avatar
          className={`h-10 w-10 ${isUser ? "bg-earth-200" : "bg-terracotta"} transition-transform hover:scale-110`}
        >
          <AvatarFallback>{isUser ? "U" : "AI"}</AvatarFallback>
          {!isUser && <AvatarImage src="/ai-avatar.svg" alt="AI Assistant" />}
        </Avatar>
        <div className="space-y-2 w-full">
          <Card
            className={`p-4 ${isUser ? "bg-earth-100 border-earth-200" : "bg-white border-earth-200"} transition-all hover:shadow-md`}
          >
            <div className="prose prose-earth whitespace-pre-wrap">{message.content}</div>
          </Card>

          {!isUser && (
            <div className="flex items-center gap-2 opacity-0 hover:opacity-100 transition-opacity">
              <Button variant="ghost" size="sm" className="h-8 px-2 transition-colors" onClick={handleCopy}>
                {isCopied ? (
                  <>
                    <span className="text-green-600 mr-1">✓</span>
                    {isVietnamese ? "Đã sao chép" : "Copied"}
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-1" />
                    {isVietnamese ? "Sao chép" : "Copy"}
                  </>
                )}
              </Button>
              <Button variant="ghost" size="sm" className="h-8 px-2 transition-colors">
                <Download className="h-4 w-4 mr-1" />
                {isVietnamese ? "Tải xuống" : "Download"}
              </Button>
              <div className="flex items-center ml-auto">
                <Button
                  variant="ghost"
                  size="icon"
                  className={`h-7 w-7 transition-transform hover:scale-110 ${feedback === "like" ? "text-green-500" : ""}`}
                  onClick={() => handleFeedback("like")}
                >
                  <ThumbsUp className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className={`h-7 w-7 transition-transform hover:scale-110 ${feedback === "dislike" ? "text-red-500" : ""}`}
                  onClick={() => handleFeedback("dislike")}
                >
                  <ThumbsDown className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
