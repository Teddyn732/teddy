import { CraftCategoryCard } from "@/components/craft-category-card"
import { ScrollReveal } from "@/components/scroll-reveal"

export function CraftCategorySection() {
  return (
    <section className="bg-white py-16">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <h2 className="text-3xl font-bold text-earth-900 mb-3 text-center">Hỗ trợ đa dạng làng nghề</h2>
          <p className="text-xl text-earth-700 mb-12 text-center max-w-3xl mx-auto">
            Giải pháp AI của chúng tôi được thiết kế riêng cho từng loại hình làng nghề truyền thống Việt Nam
          </p>
        </ScrollReveal>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 stagger-children">
          <ScrollReveal delay={100}>
            <CraftCategoryCard
              title="Gốm sứ"
              description="Bát Tràng, Phù Lãng, Biên Hòa..."
              imageSrc="/images/gom-su.jpg"
              href="/nganh-nghe/gom-su"
            />
          </ScrollReveal>
          <ScrollReveal delay={200}>
            <CraftCategoryCard
              title="Dệt may"
              description="Lụa Vạn Phúc, Thổ cẩm Sapa..."
              imageSrc="/images/det-may.jpg"
              href="/nganh-nghe/det-may"
            />
          </ScrollReveal>
          <ScrollReveal delay={300}>
            <CraftCategoryCard
              title="Mây tre đan"
              description="Phú Vinh, Bảo Lộc, Ninh Bình..."
              imageSrc="/images/may-tre.jpg"
              href="/nganh-nghe/may-tre"
            />
          </ScrollReveal>
          <ScrollReveal delay={400}>
            <CraftCategoryCard
              title="Sơn mài"
              description="Hạ Thái, Tương Bình Hiệp..."
              imageSrc="/images/son-mai.jpg"
              href="/nganh-nghe/son-mai"
            />
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
