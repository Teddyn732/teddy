"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { AlertCircle, Volume2, Send, RefreshCw, Save, Download, ImageIcon } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ultimateAIService, type AIModel, type ChatMessage } from "@/lib/ultimate-ai-service"

// Define message types
interface Message {
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  id?: string
  model?: AIModel
  isImage?: boolean
  isAudio?: boolean
  audioUrl?: string
}

// Define conversation types
interface Conversation {
  id: string
  title: string
  messages: Message[]
  createdAt: number
  updatedAt: number
}

// Define user preferences
interface UserPreferences {
  defaultModel: AIModel
  language: Language
  autoSave: boolean
  darkMode: boolean
  speechEnabled: boolean
  streamingEnabled: boolean
}

// Define language type
type Language = "vi-VN" | "en-US" | "fr-FR" | "de-DE" | "es-ES" | "it-IT" | "ja-JP" | "ko-KR" | "zh-CN"

// Default user preferences
const defaultPreferences: UserPreferences = {
  defaultModel: "gpt-4o",
  language: "vi-VN",
  autoSave: true,
  darkMode: false,
  speechEnabled: false,
  streamingEnabled: true,
}

// Available AI models grouped by provider
const aiModels = {
  openai: [
    { value: "gpt-4o", label: "GPT-4o" },
    { value: "gpt-4.1", label: "GPT-4.1" },
    { value: "gpt-4.1-mini", label: "GPT-4.1 Mini" },
    { value: "o1-mini", label: "O1 Mini" },
    { value: "o3-mini", label: "O3 Mini" },
  ],
  claude: [
    { value: "claude-3-7-sonnet", label: "Claude 3.7 Sonnet" },
    { value: "claude-3-5-sonnet", label: "Claude 3.5 Sonnet" },
  ],
  deepseek: [
    { value: "deepseek-chat", label: "DeepSeek Chat" },
    { value: "deepseek-reasoner", label: "DeepSeek Reasoner" },
  ],
}

// Available languages for text-to-speech
const languages = [
  { value: "vi-VN", label: "Tiếng Việt" },
  { value: "en-US", label: "English (US)" },
  { value: "fr-FR", label: "Français" },
  { value: "de-DE", label: "Deutsch" },
  { value: "es-ES", label: "Español" },
  { value: "it-IT", label: "Italiano" },
  { value: "ja-JP", label: "日本語" },
  { value: "ko-KR", label: "한국어" },
  { value: "zh-CN", label: "中文" },
]

// Generate a unique ID
const generateId = () => Math.random().toString(36).substring(2, 15)

export default function UltimateAIAssistant() {
  // State for the assistant
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Xin chào! Tôi là trợ lý AI của Làng Nghề Việt Nam. Tôi có thể giúp gì cho bạn?",
      timestamp: new Date(),
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [isFallbackMode, setIsFallbackMode] = useState(false)
  const [selectedModel, setSelectedModel] = useState<AIModel>("gpt-4o")
  const [streamingEnabled, setStreamingEnabled] = useState(true)
  const [activeTab, setActiveTab] = useState("chat")
  const [imagePrompt, setImagePrompt] = useState("")
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [textToSpeak, setTextToSpeak] = useState("")
  const [audioPlaying, setAudioPlaying] = useState(false)
  const [savedConversations, setSavedConversations] = useState<{ id: string; title: string }[]>([])
  const [conversationTitle, setConversationTitle] = useState("")
  const [systemPrompt, setSystemPrompt] = useState(
    "Bạn là trợ lý AI chuyên về làng nghề Việt Nam. Hãy cung cấp thông tin chính xác, hữu ích và chi tiết về các làng nghề, sản phẩm thủ công, kỹ thuật sản xuất, tiếp thị, xuất khẩu và phát triển bền vững cho làng nghề.",
  )

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  // Check if we're in fallback mode on component mount
  useEffect(() => {
    const checkFallbackMode = async () => {
      await ultimateAIService.ensurePuter()
      setIsFallbackMode(ultimateAIService.isFallbackMode())
    }

    checkFallbackMode()
  }, [])

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Load saved conversations on mount
  useEffect(() => {
    const loadSavedConversations = async () => {
      try {
        const savedConvos = await ultimateAIService.getValue("saved_conversations")
        if (savedConvos) {
          setSavedConversations(JSON.parse(savedConvos))
        }
      } catch (error) {
        console.error("Error loading saved conversations:", error)
      }
    }

    loadSavedConversations()
  }, [])

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // Convert messages to the format expected by the AI service
      const messageHistory: ChatMessage[] = [
        { role: "system", content: systemPrompt },
        ...messages.map((msg) => ({
          role: msg.role,
          content: msg.content,
        })),
        { role: "user", content: input },
      ]

      if (streamingEnabled) {
        // Handle streaming response
        const assistantMessage: Message = {
          role: "assistant",
          content: "",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, assistantMessage])

        const response = await ultimateAIService.chatWithHistory(messageHistory, {
          model: selectedModel,
          stream: true,
          systemPrompt,
        })

        // For streaming responses
        if (response[Symbol.asyncIterator]) {
          let fullContent = ""

          for await (const part of response) {
            if (part?.text) {
              fullContent += part.text
              setMessages((prev) => {
                const newMessages = [...prev]
                newMessages[newMessages.length - 1].content = fullContent
                return newMessages
              })
            }
          }
        } else {
          // Handle non-streaming fallback response
          setMessages((prev) => {
            const newMessages = [...prev]
            newMessages[newMessages.length - 1].content = response.message.content
            return newMessages
          })
        }
      } else {
        // Handle non-streaming response
        const response = await ultimateAIService.chatWithHistory(messageHistory, {
          model: selectedModel,
          systemPrompt,
        })

        const assistantMessage: Message = {
          role: "assistant",
          content: response.message.content,
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, assistantMessage])
      }
    } catch (error) {
      console.error("Error sending message:", error)

      // Add error message
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Xin lỗi, đã xảy ra lỗi khi xử lý yêu cầu của bạn. Vui lòng thử lại sau.",
          timestamp: new Date(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleGenerateImage = async () => {
    if (!imagePrompt.trim()) return

    setIsLoading(true)
    setGeneratedImage(null)

    try {
      const imageElement = await ultimateAIService.generateImage(imagePrompt)

      if (imageElement) {
        setGeneratedImage(imageElement.src)
      } else {
        alert("Không thể tạo hình ảnh. Vui lòng thử lại sau.")
      }
    } catch (error) {
      console.error("Error generating image:", error)
      alert("Đã xảy ra lỗi khi tạo hình ảnh. Vui lòng thử lại sau.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleTextToSpeech = async () => {
    if (!textToSpeak.trim()) return

    setIsLoading(true)

    try {
      const audio = await ultimateAIService.textToSpeech(textToSpeak)

      if (audio) {
        audioRef.current = audio
        audio.onplay = () => setAudioPlaying(true)
        audio.onended = () => setAudioPlaying(false)
        audio.play()
      } else {
        alert("Không thể chuyển đổi văn bản thành giọng nói. Vui lòng thử lại sau.")
      }
    } catch (error) {
      console.error("Error with text-to-speech:", error)
      alert("Đã xảy ra lỗi khi chuyển đổi văn bản thành giọng nói. Vui lòng thử lại sau.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleStopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
      setAudioPlaying(false)
    }
  }

  const handleSaveConversation = async () => {
    if (!conversationTitle.trim()) {
      alert("Vui lòng nhập tiêu đề cho cuộc trò chuyện")
      return
    }

    try {
      const conversationId = Date.now().toString()
      const newConversation = {
        id: conversationId,
        title: conversationTitle,
      }

      // Save conversation metadata
      const updatedConversations = [...savedConversations, newConversation]
      setSavedConversations(updatedConversations)
      await ultimateAIService.storeValue("saved_conversations", JSON.stringify(updatedConversations))

      // Save conversation content
      await ultimateAIService.storeValue(`conversation_${conversationId}`, JSON.stringify(messages))

      setConversationTitle("")
      alert("Đã lưu cuộc trò chuyện thành công!")
    } catch (error) {
      console.error("Error saving conversation:", error)
      alert("Đã xảy ra lỗi khi lưu cuộc trò chuyện. Vui lòng thử lại sau.")
    }
  }

  const handleLoadConversation = async (conversationId: string) => {
    try {
      const conversationData = await ultimateAIService.getValue(`conversation_${conversationId}`)

      if (conversationData) {
        const parsedMessages = JSON.parse(conversationData)
        // Convert string timestamps to Date objects
        const messagesWithDateObjects = parsedMessages.map((msg: any) => ({
          ...msg,
          timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(),
        }))
        setMessages(messagesWithDateObjects)
      }
    } catch (error) {
      console.error("Error loading conversation:", error)
      alert("Đã xảy ra lỗi khi tải cuộc trò chuyện. Vui lòng thử lại sau.")
    }
  }

  const handleRetryLoading = async () => {
    setIsLoading(true)

    try {
      const result = await ultimateAIService.retryLoading()
      setIsFallbackMode(!result)

      if (result) {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "Kết nối với dịch vụ AI đã được khôi phục. Bạn có thể sử dụng đầy đủ tính năng của trợ lý AI.",
            timestamp: new Date(),
          },
        ])
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content:
              "Không thể kết nối với dịch vụ AI. Trợ lý vẫn đang hoạt động ở chế độ dự phòng với chức năng hạn chế.",
            timestamp: new Date(),
          },
        ])
      }
    } catch (error) {
      console.error("Error retrying connection:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Trợ Lý AI Làng Nghề Việt Nam</h1>

      {isFallbackMode && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Chế độ dự phòng</AlertTitle>
          <AlertDescription>
            Không thể kết nối với dịch vụ AI đầy đủ. Trợ lý đang hoạt động ở chế độ dự phòng với chức năng hạn chế.
            <Button variant="outline" size="sm" className="mt-2" onClick={handleRetryLoading} disabled={isLoading}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Thử kết nối lại
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="chat">Trò chuyện</TabsTrigger>
          <TabsTrigger value="image" disabled={isFallbackMode}>
            Tạo hình ảnh
          </TabsTrigger>
          <TabsTrigger value="speech" disabled={isFallbackMode}>
            Văn bản sang giọng nói
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Trò chuyện với Trợ lý AI</CardTitle>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="streaming" className="text-sm">
                    Streaming
                  </Label>
                  <Switch
                    id="streaming"
                    checked={streamingEnabled}
                    onCheckedChange={setStreamingEnabled}
                    disabled={isFallbackMode}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Label htmlFor="model-select">Mô hình AI</Label>
                <Select
                  value={selectedModel}
                  onValueChange={(value) => setSelectedModel(value as AIModel)}
                  disabled={isFallbackMode}
                >
                  <SelectTrigger id="model-select">
                    <SelectValue placeholder="Chọn mô hình AI" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gpt-4o">OpenAI GPT-4o</SelectItem>
                    <SelectItem value="gpt-4.1">OpenAI GPT-4.1</SelectItem>
                    <SelectItem value="o1-mini">OpenAI o1-mini</SelectItem>
                    <SelectItem value="o3-mini">OpenAI o3-mini</SelectItem>
                    <SelectItem value="claude-3-5-sonnet">Claude 3.5 Sonnet</SelectItem>
                    <SelectItem value="claude-3-7-sonnet">Claude 3.7 Sonnet</SelectItem>
                    <SelectItem value="deepseek-chat">DeepSeek Chat</SelectItem>
                    <SelectItem value="deepseek-reasoner">DeepSeek Reasoner</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="mb-4">
                <Label htmlFor="system-prompt">System Prompt</Label>
                <Textarea
                  id="system-prompt"
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                  className="h-24"
                  disabled={isFallbackMode}
                />
              </div>

              <ScrollArea className="h-[400px] border rounded-md p-4">
                <div className="space-y-4">
                  {messages.map((message, index) => (
                    <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <div className="mb-1">
                          <Badge variant={message.role === "user" ? "outline" : "secondary"}>
                            {message.role === "user" ? "Bạn" : "Trợ lý AI"}
                          </Badge>
                        </div>
                        <div className="whitespace-pre-wrap">{message.content}</div>
                        <div className="text-xs opacity-70 mt-1">
                          {message.timestamp instanceof Date
                            ? message.timestamp.toLocaleTimeString()
                            : typeof message.timestamp === "string"
                              ? new Date(message.timestamp).toLocaleTimeString()
                              : new Date().toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
            </CardContent>
            <CardFooter>
              <div className="flex w-full space-x-2">
                <Input
                  placeholder="Nhập tin nhắn của bạn..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSendMessage()
                    }
                  }}
                  disabled={isLoading}
                />
                <Button onClick={handleSendMessage} disabled={isLoading || !input.trim()}>
                  <Send className="h-4 w-4 mr-2" />
                  Gửi
                </Button>
              </div>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Lưu và tải cuộc trò chuyện</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2 mb-4">
                <Input
                  placeholder="Tiêu đề cuộc trò chuyện"
                  value={conversationTitle}
                  onChange={(e) => setConversationTitle(e.target.value)}
                  disabled={isLoading}
                />
                <Button
                  onClick={handleSaveConversation}
                  disabled={isLoading || !conversationTitle.trim() || isFallbackMode}
                >
                  <Save className="h-4 w-4 mr-2" />
                  Lưu
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Cuộc trò chuyện đã lưu:</h3>
                {savedConversations.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Chưa có cuộc trò chuyện nào được lưu</p>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {savedConversations.map((convo) => (
                      <Button
                        key={convo.id}
                        variant="outline"
                        onClick={() => handleLoadConversation(convo.id)}
                        disabled={isLoading || isFallbackMode}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        {convo.title}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="image">
          <Card>
            <CardHeader>
              <CardTitle>Tạo hình ảnh với AI</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="image-prompt">Mô tả hình ảnh</Label>
                  <Textarea
                    id="image-prompt"
                    placeholder="Mô tả chi tiết hình ảnh bạn muốn tạo..."
                    value={imagePrompt}
                    onChange={(e) => setImagePrompt(e.target.value)}
                    className="h-24"
                    disabled={isLoading}
                  />
                </div>

                <Button onClick={handleGenerateImage} disabled={isLoading || !imagePrompt.trim()} className="w-full">
                  <ImageIcon className="h-4 w-4 mr-2" />
                  {isLoading ? "Đang tạo hình ảnh..." : "Tạo hình ảnh"}
                </Button>

                {generatedImage && (
                  <div className="mt-4">
                    <h3 className="text-lg font-medium mb-2">Hình ảnh đã tạo:</h3>
                    <div className="border rounded-md overflow-hidden">
                      <img src={generatedImage || "/placeholder.svg"} alt="Generated" className="w-full h-auto" />
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="speech">
          <Card>
            <CardHeader>
              <CardTitle>Chuyển văn bản thành giọng nói</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="text-to-speak">Văn bản</Label>
                  <Textarea
                    id="text-to-speak"
                    placeholder="Nhập văn bản bạn muốn chuyển thành giọng nói..."
                    value={textToSpeak}
                    onChange={(e) => setTextToSpeak(e.target.value)}
                    className="h-24"
                    disabled={isLoading || audioPlaying}
                  />
                </div>

                <div className="flex space-x-2">
                  <Button
                    onClick={handleTextToSpeech}
                    disabled={isLoading || !textToSpeak.trim() || audioPlaying}
                    className="flex-1"
                  >
                    <Volume2 className="h-4 w-4 mr-2" />
                    {isLoading ? "Đang xử lý..." : "Phát giọng nói"}
                  </Button>

                  {audioPlaying && (
                    <Button variant="outline" onClick={handleStopAudio}>
                      Dừng
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
