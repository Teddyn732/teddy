"use client"

import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, ArrowRight } from "lucide-react"

interface BusinessTemplatesProps {
  language: string
  onSelect: (template: string) => void
}

export function BusinessTemplates({ language, onSelect }: BusinessTemplatesProps) {
  const isVietnamese = language === "vi"

  const templates = [
    {
      id: "business-plan",
      title: isVietnamese ? "Kế hoạch kinh doanh" : "Business Plan",
      description: isVietnamese
        ? "Tạo kế hoạch kinh doanh toàn diện cho doanh nghiệp làng nghề của bạn"
        : "Create a comprehensive business plan for your craft business",
      prompt: isVietnamese
        ? "Tạo kế hoạch kinh doanh toàn diện cho doanh nghiệp làng nghề của tôi. Hãy hỏi tôi các thông tin cần thiết để tạo kế hoạch chi tiết."
        : "Create a comprehensive business plan for my craft business. Please ask me for the necessary information to create a detailed plan.",
    },
    {
      id: "marketing-strategy",
      title: isVietnamese ? "Chiến lược marketing" : "Marketing Strategy",
      description: isVietnamese
        ? "Phát triển chiến lược marketing hiệu quả cho sản phẩm làng nghề"
        : "Develop an effective marketing strategy for craft products",
      prompt: isVietnamese
        ? "Tạo chiến lược marketing toàn diện cho sản phẩm làng nghề của tôi, bao gồm kế hoạch truyền thông xã hội, tiếp thị nội dung, và chiến lược bán hàng trực tuyến."
        : "Create a comprehensive marketing strategy for my craft products, including social media plans, content marketing, and online sales strategies.",
    },
    {
      id: "branding-guide",
      title: isVietnamese ? "Hướng dẫn xây dựng thương hiệu" : "Branding Guide",
      description: isVietnamese
        ? "Xây dựng thương hiệu mạnh mẽ cho sản phẩm làng nghề của bạn"
        : "Build a strong brand for your craft products",
      prompt: isVietnamese
        ? "Tạo hướng dẫn xây dựng thương hiệu cho sản phẩm làng nghề của tôi, bao gồm định vị thương hiệu, thông điệp chính, và chiến lược nhận diện thương hiệu."
        : "Create a branding guide for my craft products, including brand positioning, key messaging, and brand identity strategies.",
    },
    {
      id: "pricing-strategy",
      title: isVietnamese ? "Chiến lược định giá" : "Pricing Strategy",
      description: isVietnamese
        ? "Phát triển mô hình định giá hiệu quả cho sản phẩm thủ công"
        : "Develop an effective pricing model for handcraft products",
      prompt: isVietnamese
        ? "Tạo chiến lược định giá cho sản phẩm thủ công của tôi, bao gồm phân tích chi phí, định giá cạnh tranh, và chiến lược giá theo phân khúc thị trường."
        : "Create a pricing strategy for my handcraft products, including cost analysis, competitive pricing, and market segment pricing strategies.",
    },
    {
      id: "export-plan",
      title: isVietnamese ? "Kế hoạch xuất khẩu" : "Export Plan",
      description: isVietnamese
        ? "Phát triển chiến lược xuất khẩu sản phẩm làng nghề ra thị trường quốc tế"
        : "Develop a strategy to export craft products to international markets",
      prompt: isVietnamese
        ? "Tạo kế hoạch xuất khẩu sản phẩm làng nghề của tôi ra thị trường quốc tế, bao gồm phân tích thị trường mục tiêu, yêu cầu pháp lý, và chiến lược phân phối."
        : "Create an export plan for my craft products to international markets, including target market analysis, legal requirements, and distribution strategies.",
    },
    {
      id: "production-optimization",
      title: isVietnamese ? "Tối ưu hóa sản xuất" : "Production Optimization",
      description: isVietnamese
        ? "Cải thiện quy trình sản xuất để tăng hiệu quả và chất lượng"
        : "Improve production processes to increase efficiency and quality",
      prompt: isVietnamese
        ? "Tạo kế hoạch tối ưu hóa quy trình sản xuất cho làng nghề của tôi, bao gồm phân tích quy trình hiện tại, xác định điểm nghẽn, và đề xuất cải tiến."
        : "Create a production optimization plan for my craft village, including analysis of current processes, identification of bottlenecks, and improvement suggestions.",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {templates.map((template) => (
        <Card key={template.id} className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="text-lg">{template.title}</CardTitle>
            <CardDescription>{template.description}</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button
              variant="outline"
              className="w-full justify-between hover:border-terracotta hover:text-terracotta transition-colors"
              onClick={() => onSelect(template.prompt)}
            >
              <FileText className="h-4 w-4" />
              <span>{isVietnamese ? "Sử dụng mẫu này" : "Use this template"}</span>
              <ArrowRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
