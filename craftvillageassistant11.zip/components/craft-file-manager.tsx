"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, File, Folder, Upload, Trash2, Plus, Save } from "lucide-react"
import puterClient from "@/lib/puter-client"

interface FileItem {
  name: string
  type: "file" | "directory"
  size?: number
  modified?: string
  path: string
}

function CraftFileManager() {
  const [files, setFiles] = useState<FileItem[]>([])
  const [currentPath, setCurrentPath] = useState("/craft-village")
  const [isLoading, setIsLoading] = useState(true)
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null)
  const [fileContent, setFileContent] = useState("")
  const [newFileName, setNewFileName] = useState("")
  const [newFileContent, setNewFileContent] = useState("")
  const [isCreatingFile, setIsCreatingFile] = useState(false)
  const [message, setMessage] = useState("")
  const [isSignedIn, setIsSignedIn] = useState(false)

  useEffect(() => {
    const initializeFileManager = async () => {
      setIsLoading(true)

      // Initialize Puter.js
      await puterClient.init()

      // Check if user is signed in
      const signedIn = puterClient.auth.isSignedIn()
      setIsSignedIn(signedIn)

      if (signedIn) {
        // Create base directory if it doesn't exist
        try {
          await puterClient.fs.createDirectory("/craft-village")
        } catch (error) {
          // Directory might already exist, continue
        }

        // Load files
        await loadFiles()
      }

      setIsLoading(false)
    }

    initializeFileManager()
  }, [])

  const loadFiles = async () => {
    setIsLoading(true)
    const fileList = await puterClient.fs.listFiles(currentPath)

    if (Array.isArray(fileList)) {
      const formattedFiles = fileList.map((file) => ({
        name: file.name,
        type: file.type === "directory" ? "directory" : "file",
        size: file.size,
        modified: file.modified,
        path: `${currentPath}/${file.name}`,
      }))

      setFiles(formattedFiles)
    } else {
      setFiles([])
    }

    setIsLoading(false)
  }

  const handleSignIn = async () => {
    setIsLoading(true)
    await puterClient.auth.signIn()
    setIsSignedIn(true)
    await loadFiles()
    setIsLoading(false)
  }

  const handleFileClick = async (file: FileItem) => {
    if (file.type === "directory") {
      setCurrentPath(file.path)
      setSelectedFile(null)
      setFileContent("")
      await loadFiles()
    } else {
      setSelectedFile(file)
      const content = await puterClient.fs.readFile(file.path)
      if (content) {
        const text = await content.text()
        setFileContent(text)
      } else {
        setFileContent("")
      }
    }
  }

  const handleSaveFile = async () => {
    if (!selectedFile) return

    setIsLoading(true)
    const success = await puterClient.fs.writeFile(selectedFile.path, fileContent)

    if (success) {
      setMessage("Đã lưu thành công!")
    } else {
      setMessage("Lỗi khi lưu. Vui lòng thử lại.")
    }

    setIsLoading(false)

    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage("")
    }, 3000)
  }

  const handleDeleteFile = async () => {
    if (!selectedFile) return

    setIsLoading(true)
    const success = await puterClient.fs.deleteFile(selectedFile.path)

    if (success) {
      setMessage("Đã xóa thành công!")
      setSelectedFile(null)
      setFileContent("")
      await loadFiles()
    } else {
      setMessage("Lỗi khi xóa. Vui lòng thử lại.")
    }

    setIsLoading(false)

    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage("")
    }, 3000)
  }

  const handleCreateFile = async () => {
    if (!newFileName) return

    setIsLoading(true)
    const filePath = `${currentPath}/${newFileName}`
    const success = await puterClient.fs.writeFile(filePath, newFileContent)

    if (success) {
      setMessage("Đã tạo tệp thành công!")
      setNewFileName("")
      setNewFileContent("")
      setIsCreatingFile(false)
      await loadFiles()
    } else {
      setMessage("Lỗi khi tạo tệp. Vui lòng thử lại.")
    }

    setIsLoading(false)

    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage("")
    }, 3000)
  }

  const handleCreateFolder = async () => {
    if (!newFileName) return

    setIsLoading(true)
    const folderPath = `${currentPath}/${newFileName}`
    const success = await puterClient.fs.createDirectory(folderPath)

    if (success) {
      setMessage("Đã tạo thư mục thành công!")
      setNewFileName("")
      setIsCreatingFile(false)
      await loadFiles()
    } else {
      setMessage("Lỗi khi tạo thư mục. Vui lòng thử lại.")
    }

    setIsLoading(false)

    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage("")
    }, 3000)
  }

  const navigateUp = async () => {
    if (currentPath === "/craft-village") return

    const pathParts = currentPath.split("/")
    pathParts.pop()
    const newPath = pathParts.join("/") || "/craft-village"

    setCurrentPath(newPath)
    setSelectedFile(null)
    setFileContent("")
    await loadFiles()
  }

  if (isLoading && !isSignedIn) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="pt-6 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-earth-600" />
        </CardContent>
      </Card>
    )
  }

  if (!isSignedIn) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Quản lý tệp làng nghề</CardTitle>
          <CardDescription>Lưu trữ và quản lý tài liệu làng nghề của bạn trên đám mây</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="mb-4">Vui lòng đăng nhập để sử dụng tính năng quản lý tệp</p>
          <Button onClick={handleSignIn}>Đăng nhập</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Quản lý tệp làng nghề</CardTitle>
        <CardDescription>Lưu trữ và quản lý tài liệu làng nghề của bạn trên đám mây</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={navigateUp} disabled={currentPath === "/craft-village"}>
              <Folder className="h-4 w-4 mr-1" /> ..
            </Button>
            <span className="text-sm font-mono">{currentPath}</span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setIsCreatingFile(true)
                setNewFileName("")
                setNewFileContent("")
              }}
            >
              <Plus className="h-4 w-4 mr-1" /> Tạo mới
            </Button>
            <Button size="sm" variant="default" onClick={loadFiles}>
              <Upload className="h-4 w-4 mr-1" /> Làm mới
            </Button>
          </div>
        </div>

        {isCreatingFile && (
          <Card className="border border-dashed p-4">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Tên tệp/thư mục:</label>
                <Input
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  placeholder="Nhập tên tệp hoặc thư mục"
                  className="mt-1"
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setIsCreatingFile(false)}>
                  Hủy
                </Button>
                <Button variant="outline" size="sm" onClick={handleCreateFolder} disabled={!newFileName}>
                  <Folder className="h-4 w-4 mr-1" /> Tạo thư mục
                </Button>
                <Button size="sm" onClick={handleCreateFile} disabled={!newFileName}>
                  <File className="h-4 w-4 mr-1" /> Tạo tệp
                </Button>
              </div>

              {newFileName && !newFileName.includes("/") && (
                <div>
                  <label className="text-sm font-medium">Nội dung tệp:</label>
                  <Textarea
                    value={newFileContent}
                    onChange={(e) => setNewFileContent(e.target.value)}
                    placeholder="Nhập nội dung tệp"
                    className="mt-1"
                    rows={5}
                  />
                </div>
              )}
            </div>
          </Card>
        )}

        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tên</TableHead>
                <TableHead>Loại</TableHead>
                <TableHead>Kích thước</TableHead>
                <TableHead>Sửa đổi lần cuối</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {files.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4">
                    Không có tệp nào trong thư mục này
                  </TableCell>
                </TableRow>
              ) : (
                files.map((file) => (
                  <TableRow
                    key={file.path}
                    className={`cursor-pointer hover:bg-gray-50 ${selectedFile?.path === file.path ? "bg-blue-50" : ""}`}
                    onClick={() => handleFileClick(file)}
                  >
                    <TableCell className="flex items-center gap-2">
                      {file.type === "directory" ? (
                        <Folder className="h-4 w-4 text-blue-500" />
                      ) : (
                        <File className="h-4 w-4 text-gray-500" />
                      )}
                      {file.name}
                    </TableCell>
                    <TableCell>{file.type === "directory" ? "Thư mục" : "Tệp"}</TableCell>
                    <TableCell>{file.size ? `${Math.round(file.size / 1024)} KB` : "-"}</TableCell>
                    <TableCell>{file.modified || "-"}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {selectedFile && selectedFile.type === "file" && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">{selectedFile.name}</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={handleDeleteFile}>
                  <Trash2 className="h-4 w-4 mr-1" /> Xóa
                </Button>
                <Button size="sm" onClick={handleSaveFile}>
                  <Save className="h-4 w-4 mr-1" /> Lưu
                </Button>
              </div>
            </div>
            <Textarea
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              rows={10}
              className="font-mono text-sm"
            />
          </div>
        )}
      </CardContent>
      <CardFooter>
        {message && (
          <p className={`text-sm ${message.includes("Lỗi") ? "text-red-500" : "text-green-500"}`}>{message}</p>
        )}
      </CardFooter>
    </Card>
  )
}

export { CraftFileManager }
export default CraftFileManager
