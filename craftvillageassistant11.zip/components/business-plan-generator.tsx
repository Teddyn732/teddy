"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Send } from "lucide-react"

interface BusinessPlanGeneratorProps {
  language: string
  onGenerate: (prompt: string) => void
}

export function BusinessPlanGenerator({ language, onGenerate }: BusinessPlanGeneratorProps) {
  const isVietnamese = language === "vi"
  const [businessType, setBusinessType] = useState("")
  const [productDescription, setProductDescription] = useState("")
  const [targetMarket, setTargetMarket] = useState("")
  const [businessGoals, setBusinessGoals] = useState("")
  const [planType, setPlanType] = useState("comprehensive")

  const handleGenerate = () => {
    const prompt = isVietnamese
      ? `Tạo kế hoạch kinh doanh ${planType === "comprehensive" ? "toàn diện" : "ngắn gọn"} cho doanh nghiệp làng nghề của tôi với các thông tin sau:
        - Loại sản phẩm/nghề: ${businessType}
        - Mô tả sản phẩm: ${productDescription}
        - Thị trường mục tiêu: ${targetMarket}
        - Mục tiêu kinh doanh: ${businessGoals}
        
        Kế hoạch cần bao gồm: tóm tắt điều hành, phân tích thị trường, chiến lược marketing, kế hoạch vận hành, và dự báo tài chính cơ bản. Hãy đưa ra các bước cụ thể và thực tế cho doanh nghiệp làng nghề tại Việt Nam.`
      : `Create a ${planType === "comprehensive" ? "comprehensive" : "concise"} business plan for my craft village business with the following information:
        - Type of product/craft: ${businessType}
        - Product description: ${productDescription}
        - Target market: ${targetMarket}
        - Business goals: ${businessGoals}
        
        The plan should include: executive summary, market analysis, marketing strategy, operations plan, and basic financial projections. Please provide specific and practical steps for a craft business in Vietnam.`

    onGenerate(prompt)
  }

  const templates = [
    {
      id: "pottery",
      title: isVietnamese ? "Gốm sứ Bát Tràng" : "Bat Trang Pottery",
      description: isVietnamese
        ? "Sản xuất và bán các sản phẩm gốm sứ thủ công"
        : "Production and sale of handcrafted pottery products",
      market: isVietnamese
        ? "Khách du lịch, cửa hàng nội thất, khách hàng trực tuyến"
        : "Tourists, home decor stores, online customers",
      goals: isVietnamese
        ? "Mở rộng thị trường xuất khẩu và xây dựng thương hiệu cao cấp"
        : "Expand export markets and build a premium brand",
    },
    {
      id: "bamboo",
      title: isVietnamese ? "Mây tre đan Phú Vinh" : "Phu Vinh Bamboo Crafts",
      description: isVietnamese
        ? "Sản xuất đồ gia dụng và trang trí từ mây tre đan"
        : "Production of household and decorative items from woven bamboo",
      market: isVietnamese
        ? "Cửa hàng nội thất, khách sạn, nhà hàng, xuất khẩu"
        : "Furniture stores, hotels, restaurants, export",
      goals: isVietnamese
        ? "Phát triển sản phẩm bền vững và tăng doanh số bán hàng trực tuyến"
        : "Develop sustainable products and increase online sales",
    },
    {
      id: "silk",
      title: isVietnamese ? "Lụa Vạn Phúc" : "Van Phuc Silk",
      description: isVietnamese
        ? "Sản xuất và bán các sản phẩm lụa truyền thống và hiện đại"
        : "Production and sale of traditional and modern silk products",
      market: isVietnamese
        ? "Khách du lịch, cửa hàng thời trang, khách hàng cao cấp"
        : "Tourists, fashion boutiques, premium customers",
      goals: isVietnamese
        ? "Kết hợp thiết kế hiện đại với kỹ thuật truyền thống để tạo sản phẩm độc đáo"
        : "Combine modern design with traditional techniques to create unique products",
    },
  ]

  const handleTemplateSelect = (template: any) => {
    setBusinessType(template.title)
    setProductDescription(template.description)
    setTargetMarket(template.market)
    setBusinessGoals(template.goals)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{isVietnamese ? "Tạo Kế Hoạch Kinh Doanh" : "Business Plan Generator"}</CardTitle>
        <CardDescription>
          {isVietnamese
            ? "Nhập thông tin về doanh nghiệp làng nghề của bạn để tạo kế hoạch kinh doanh chuyên nghiệp"
            : "Enter information about your craft business to generate a professional business plan"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="custom" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="custom">{isVietnamese ? "Tùy chỉnh" : "Custom"}</TabsTrigger>
            <TabsTrigger value="templates">{isVietnamese ? "Mẫu có sẵn" : "Templates"}</TabsTrigger>
          </TabsList>

          <TabsContent value="custom" className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="business-type">{isVietnamese ? "Loại sản phẩm/nghề" : "Type of product/craft"}</Label>
                <Input
                  id="business-type"
                  placeholder={isVietnamese ? "Ví dụ: Gốm sứ Bát Tràng" : "E.g., Bat Trang Pottery"}
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="product-description">{isVietnamese ? "Mô tả sản phẩm" : "Product description"}</Label>
                <Textarea
                  id="product-description"
                  placeholder={
                    isVietnamese ? "Mô tả chi tiết về sản phẩm của bạn" : "Detailed description of your products"
                  }
                  value={productDescription}
                  onChange={(e) => setProductDescription(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-market">{isVietnamese ? "Thị trường mục tiêu" : "Target market"}</Label>
                <Textarea
                  id="target-market"
                  placeholder={isVietnamese ? "Khách hàng mục tiêu của bạn là ai?" : "Who are your target customers?"}
                  value={targetMarket}
                  onChange={(e) => setTargetMarket(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="business-goals">{isVietnamese ? "Mục tiêu kinh doanh" : "Business goals"}</Label>
                <Textarea
                  id="business-goals"
                  placeholder={
                    isVietnamese ? "Mục tiêu ngắn hạn và dài hạn của bạn" : "Your short-term and long-term goals"
                  }
                  value={businessGoals}
                  onChange={(e) => setBusinessGoals(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="plan-type">{isVietnamese ? "Loại kế hoạch" : "Plan type"}</Label>
                <Select value={planType} onValueChange={setPlanType}>
                  <SelectTrigger id="plan-type">
                    <SelectValue placeholder={isVietnamese ? "Chọn loại kế hoạch" : "Select plan type"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="comprehensive">
                      {isVietnamese ? "Toàn diện (chi tiết)" : "Comprehensive (detailed)"}
                    </SelectItem>
                    <SelectItem value="concise">{isVietnamese ? "Ngắn gọn (tóm tắt)" : "Concise (summary)"}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((template) => (
                <Card
                  key={template.id}
                  className="cursor-pointer hover:border-terracotta transition-colors"
                  onClick={() => handleTemplateSelect(template)}
                >
                  <CardHeader className="p-4">
                    <CardTitle className="text-base">{template.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <p className="text-sm text-muted-foreground">{template.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" className="gap-2">
          <FileText className="h-4 w-4" />
          {isVietnamese ? "Xem mẫu" : "View samples"}
        </Button>
        <Button
          className="bg-terracotta hover:bg-terracotta-600 text-white gap-2"
          onClick={handleGenerate}
          disabled={!businessType || !productDescription}
        >
          <Send className="h-4 w-4" />
          {isVietnamese ? "Tạo kế hoạch" : "Generate plan"}
        </Button>
      </CardFooter>
    </Card>
  )
}
