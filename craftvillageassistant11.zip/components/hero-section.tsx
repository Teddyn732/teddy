import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative">
      <div className="absolute inset-0 bg-hero-pattern bg-cover bg-center opacity-20"></div>
      <div className="relative container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-3xl animate-fade-in">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-earth-900 mb-6 leading-tight">
            Từ truyền thống đến tương lai - AI đồng hành cùng làng nghề Việt
          </h2>
          <p className="text-xl md:text-2xl text-earth-700 mb-10 leading-relaxed">
            Ứng dụng công nghệ AI giúp các làng nghề truyền thống hệ thống hóa sản xuất, thương mại hóa sản phẩm và xây
            dựng doanh nghiệp bền vững.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 stagger-children">
            <Button
              size="lg"
              className="bg-terracotta hover:bg-terracotta-600 text-white text-lg px-8 py-6 button-effect"
            >
              <Link href="/tro-ly-ai" className="flex items-center">
                Bắt đầu cùng AI <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-earth-600 text-earth-700 hover:bg-earth-50 text-lg px-8 py-6 transition-all"
            >
              <Link href="/huong-dan" className="flex items-center">
                Hướng dẫn từng bước <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
