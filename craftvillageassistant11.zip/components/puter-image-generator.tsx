"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, ImageIcon, AlertTriangle } from "lucide-react"

interface PuterImageGeneratorProps {
  defaultCraftType?: string
  defaultStyle?: string
}

export function PuterImageGenerator({
  defaultCraftType = "thu-cong",
  defaultStyle = "traditional",
}: PuterImageGeneratorProps) {
  const [craftType, setCraftType] = useState(defaultCraftType)
  const [style, setStyle] = useState(defaultStyle)
  const [elements, setElements] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isPuterLoaded, setIsPuterLoaded] = useState(false)

  // Load Puter.js script
  useEffect(() => {
    if (typeof window !== "undefined" && !window.puter) {
      const script = document.createElement("script")
      script.src = "https://js.puter.com/v2/"
      script.async = true
      script.onload = () => {
        console.log("Puter.js loaded successfully")
        setIsPuterLoaded(true)
      }
      script.onerror = () => {
        console.error("Failed to load Puter.js")
        setError("Không thể tải Puter.js. Vui lòng thử lại sau.")
      }
      document.body.appendChild(script)
    } else if (typeof window !== "undefined" && window.puter) {
      setIsPuterLoaded(true)
    }
  }, [])

  const handleGenerateImage = async () => {
    if (!elements.trim() || !description.trim()) {
      setError("Vui lòng nhập đầy đủ thông tin.")
      return
    }

    setIsLoading(true)
    setError(null)
    setGeneratedImage(null)

    try {
      // If Puter.js is loaded, use it directly
      if (isPuterLoaded && window.puter) {
        // Build the prompt
        const craftPrompts: Record<string, string> = {
          "gom-su": "Vietnamese ceramic pottery with intricate blue patterns",
          "det-may": "Vietnamese traditional textile with detailed embroidery",
          "may-tre": "Vietnamese bamboo and rattan crafts with woven patterns",
          "son-mai": "Vietnamese lacquerware with gold leaf details",
          "thu-cong": "Vietnamese traditional handicraft",
        }

        const styleModifiers: Record<string, string> = {
          traditional: "authentic traditional Vietnamese style, historical patterns",
          modern: "modern interpretation of Vietnamese craft, contemporary design",
          fusion: "fusion of traditional Vietnamese elements with contemporary design",
        }

        const basePrompt = craftPrompts[craftType as keyof typeof craftPrompts] || craftPrompts["thu-cong"]
        const styleModifier = styleModifiers[style as keyof typeof styleModifiers] || styleModifiers["traditional"]
        const elementsArray = elements.split(",").map((item) => item.trim())

        const prompt = `Generate a detailed design for ${basePrompt}. ${styleModifier}. 
                        Include these elements: ${elementsArray.join(", ")}. 
                        Additional details: ${description}. 
                        High quality, detailed texture, professional product photography style.`

        // Use Puter.js to generate the image
        const imageElement = await window.puter.ai.txt2img(prompt)

        if (imageElement && imageElement.src) {
          setGeneratedImage(imageElement.src)
        } else {
          throw new Error("Failed to generate image")
        }
      } else {
        // Fallback to our API route
        const response = await fetch("/api/puter-image-generator", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            craftType,
            style,
            elements: elements.split(",").map((item) => item.trim()),
            description,
          }),
        })

        if (!response.ok) {
          throw new Error("Failed to generate image")
        }

        const data = await response.json()
        setGeneratedImage(data.imageUrl)

        if (data.fallback) {
          setError("Đang sử dụng hình ảnh mẫu. " + (data.message || ""))
        }
      }
    } catch (error) {
      console.error("Error generating image:", error)
      setError("Không thể tạo hình ảnh. Vui lòng thử lại sau.")
      setGeneratedImage("/placeholder.svg?height=512&width=512")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Tạo hình ảnh sản phẩm làng nghề</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-2">
          <Label htmlFor="craft-type">Loại làng nghề</Label>
          <Select value={craftType} onValueChange={setCraftType}>
            <SelectTrigger id="craft-type">
              <SelectValue placeholder="Chọn loại làng nghề" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gom-su">Gốm sứ</SelectItem>
              <SelectItem value="det-may">Dệt may</SelectItem>
              <SelectItem value="may-tre">Mây tre đan</SelectItem>
              <SelectItem value="son-mai">Sơn mài</SelectItem>
              <SelectItem value="thu-cong">Thủ công khác</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="style">Phong cách</Label>
          <Select value={style} onValueChange={setStyle}>
            <SelectTrigger id="style">
              <SelectValue placeholder="Chọn phong cách" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="traditional">Truyền thống</SelectItem>
              <SelectItem value="modern">Hiện đại</SelectItem>
              <SelectItem value="fusion">Kết hợp</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="elements">Yếu tố (cách nhau bởi dấu phẩy)</Label>
          <Input
            id="elements"
            placeholder="Ví dụ: hoa sen, rồng, mây"
            value={elements}
            onChange={(e) => setElements(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Mô tả chi tiết</Label>
          <Textarea
            id="description"
            placeholder="Mô tả chi tiết về sản phẩm bạn muốn tạo..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
          />
        </div>
      </CardContent>
      <CardFooter className="flex flex-col items-stretch gap-4">
        <Button onClick={handleGenerateImage} disabled={isLoading} className="w-full">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Đang tạo hình ảnh...
            </>
          ) : (
            <>
              <ImageIcon className="mr-2 h-4 w-4" />
              Tạo hình ảnh
            </>
          )}
        </Button>

        {generatedImage && (
          <div className="w-full overflow-hidden rounded-md border">
            <img
              src={generatedImage || "/placeholder.svg"}
              alt="Generated craft product"
              className="w-full h-auto object-contain"
            />
          </div>
        )}
      </CardFooter>
    </Card>
  )
}

export default PuterImageGenerator
