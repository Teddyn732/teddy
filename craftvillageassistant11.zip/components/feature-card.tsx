import type { ReactNode } from "react"

interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
}

export function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-earth-100 hover-lift transition-all">
      <div className="mb-4 transition-transform duration-300 hover:scale-110 transform-gpu">{icon}</div>
      <h4 className="text-xl font-bold text-earth-900 mb-3">{title}</h4>
      <p className="text-earth-700">{description}</p>
    </div>
  )
}
