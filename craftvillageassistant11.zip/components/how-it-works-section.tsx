import { BookOpen, Play } from "lucide-react"
import { ScrollReveal } from "@/components/scroll-reveal"

export function HowItWorksSection() {
  return (
    <section className="bg-white py-16">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <h2 className="text-3xl font-bold text-earth-900 mb-3 text-center">Cách thức hoạt động</h2>
          <p className="text-xl text-earth-700 mb-12 text-center max-w-3xl mx-auto">
            Quy trình đơn giản, dễ sử dụng cho mọi đối tượng
          </p>
        </ScrollReveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          <ScrollReveal className="order-2 md:order-1" delay={200}>
            <div className="bg-earth-50 p-8 rounded-2xl border border-earth-100 relative">
              <div className="absolute -top-5 -left-5 bg-terracotta text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">
                1
              </div>
              <h3 className="text-2xl font-bold text-earth-900 mb-4">Trò chuyện với Trợ lý AI</h3>
              <p className="text-lg text-earth-700 mb-6">
                Chia sẻ về làng nghề, sản phẩm và mục tiêu của bạn. AI sẽ hiểu nhu cầu và đưa ra hướng dẫn phù hợp.
              </p>
              <div className="bg-white p-4 rounded-lg border border-earth-100 flex items-start gap-3">
                <div className="bg-earth-100 rounded-full p-2 mt-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 text-earth-700"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-earth-900 font-medium">
                    Tôi muốn phát triển thương hiệu cho sản phẩm gốm Bát Tràng của mình
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>
          <ScrollReveal className="order-1 md:order-2" delay={400}>
            <img
              src="/images/chat-with-ai.jpg"
              alt="Trò chuyện với AI"
              className="rounded-2xl shadow-lg w-full h-auto hover-lift"
            />
          </ScrollReveal>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          <ScrollReveal delay={200}>
            <img
              src="/images/personalized-plan.jpg"
              alt="Kế hoạch cá nhân hóa"
              className="rounded-2xl shadow-lg w-full h-auto hover-lift"
            />
          </ScrollReveal>
          <ScrollReveal delay={400}>
            <div className="bg-earth-50 p-8 rounded-2xl border border-earth-100 relative">
              <div className="absolute -top-5 -left-5 bg-terracotta text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">
                2
              </div>
              <h3 className="text-2xl font-bold text-earth-900 mb-4">Nhận kế hoạch cá nhân hóa</h3>
              <p className="text-lg text-earth-700 mb-6">
                AI tạo lộ trình phát triển từng bước phù hợp với làng nghề, sản phẩm và mục tiêu của bạn.
              </p>
              <div className="bg-white p-4 rounded-lg border border-earth-100">
                <h4 className="font-bold text-earth-800 mb-2">Lộ trình phát triển thương hiệu gốm Bát Tràng</h4>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 text-terracotta"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span className="text-earth-700">Xác định giá trị cốt lõi và câu chuyện thương hiệu</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 text-terracotta"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span className="text-earth-700">Thiết kế logo và nhận diện thương hiệu</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 text-earth-300"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span className="text-earth-500">Xây dựng kênh truyền thông và tiếp thị</span>
                  </li>
                </ul>
              </div>
            </div>
          </ScrollReveal>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <ScrollReveal className="order-2 md:order-1" delay={200}>
            <div className="bg-earth-50 p-8 rounded-2xl border border-earth-100 relative">
              <div className="absolute -top-5 -left-5 bg-terracotta text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">
                3
              </div>
              <h3 className="text-2xl font-bold text-earth-900 mb-4">Học hỏi và thực hành</h3>
              <p className="text-lg text-earth-700 mb-6">
                Truy cập kho kiến thức và nhận sự hỗ trợ từ cộng đồng để thực hiện kế hoạch của bạn.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white p-3 rounded-lg border border-earth-100 flex flex-col items-center text-center hover-scale transition-all">
                  <BookOpen className="h-8 w-8 text-terracotta mb-2" />
                  <span className="text-earth-800 font-medium">Bài học về chụp ảnh sản phẩm</span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-earth-100 flex flex-col items-center text-center hover-scale transition-all">
                  <Play className="h-8 w-8 text-terracotta mb-2" />
                  <span className="text-earth-800 font-medium">Video hướng dẫn bán hàng online</span>
                </div>
              </div>
            </div>
          </ScrollReveal>
          <ScrollReveal className="order-1 md:order-2" delay={400}>
            <img
              src="/images/learning-resources.jpg"
              alt="Tài nguyên học tập"
              className="rounded-2xl shadow-lg w-full h-auto hover-lift"
            />
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
