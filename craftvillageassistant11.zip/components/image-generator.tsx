"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function ImageGenerator() {
  const [loading, setLoading] = useState(false)
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isFallback, setIsFallback] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Just use a placeholder image since we're removing the Replicate dependency
      setImageUrl("/placeholder.svg?height=512&width=512")
      setIsFallback(true)
      setError("Image generation via API has been disabled. Using placeholder image.")
    } catch (err) {
      setError("Failed to generate image. Please try again later.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="craftType">Loại nghề thủ công</Label>
              <Select defaultValue="gom-su">
                <SelectTrigger id="craftType">
                  <SelectValue placeholder="Chọn loại nghề" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gom-su">Gốm sứ</SelectItem>
                  <SelectItem value="det-may">Dệt may</SelectItem>
                  <SelectItem value="may-tre">Mây tre đan</SelectItem>
                  <SelectItem value="son-mai">Sơn mài</SelectItem>
                  <SelectItem value="thu-cong">Khác</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="style">Phong cách</Label>
              <Select defaultValue="traditional">
                <SelectTrigger id="style">
                  <SelectValue placeholder="Chọn phong cách" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="traditional">Truyền thống</SelectItem>
                  <SelectItem value="modern">Hiện đại</SelectItem>
                  <SelectItem value="fusion">Kết hợp</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="elements">Yếu tố thiết kế (cách nhau bởi dấu phẩy)</Label>
              <Input id="elements" placeholder="Hoa văn, họa tiết, màu sắc..." />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Mô tả chi tiết</Label>
              <Textarea id="description" placeholder="Mô tả chi tiết về thiết kế bạn muốn tạo..." rows={4} />
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Đang tạo..." : "Tạo thiết kế"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="text-center text-sm text-muted-foreground">
              {!imageUrl && !loading && "Thiết kế của bạn sẽ xuất hiện ở đây"}
              {loading && "Đang tạo thiết kế..."}
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Lưu ý</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {isFallback && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Thông báo</AlertTitle>
                <AlertDescription>
                  Chức năng tạo hình ảnh đã bị vô hiệu hóa. Đang sử dụng hình ảnh mẫu.
                </AlertDescription>
              </Alert>
            )}

            {imageUrl && (
              <div className="overflow-hidden rounded-lg border">
                <img
                  src={imageUrl || "/placeholder.svg"}
                  alt="Generated design"
                  className="w-full object-cover aspect-square"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default ImageGenerator
