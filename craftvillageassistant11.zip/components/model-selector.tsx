"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ModelSelectorProps {
  selectedModel: string
  onModelChange: (model: string) => void
  language: string
}

export function ModelSelector({ selectedModel, onModelChange, language }: ModelSelectorProps) {
  return (
    <Select value={selectedModel} onValueChange={onModelChange}>
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder={language === "vi" ? "Chọn model" : "Select model"} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="hybrid">{language === "vi" ? "Hybrid (Mặc định)" : "Hybrid (Default)"}</SelectItem>
        <SelectItem value="gpt-4o">GPT-4o</SelectItem>
        <SelectItem value="gpt-4.1">GPT-4.1</SelectItem>
        <SelectItem value="deepseek-chat">DeepSeek Chat</SelectItem>
        <SelectItem value="deepseek-reasoner">DeepSeek Reasoner</SelectItem>
        <SelectItem value="o1-mini">O1-mini</SelectItem>
        <SelectItem value="o3-mini">O3-mini</SelectItem>
      </SelectContent>
    </Select>
  )
}
