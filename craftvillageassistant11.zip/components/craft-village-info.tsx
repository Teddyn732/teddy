import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface CraftVillageInfoProps {
  name: string
  description: string
  location: string
  craftType: string
  foundedYear: number
  imageUrl?: string
}

export default function CraftVillageInfo({
  name,
  description,
  location,
  craftType,
  foundedYear,
  imageUrl,
}: CraftVillageInfoProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{name}</CardTitle>
        <CardDescription>
          {location} • {craftType} • Thành lập: {foundedYear}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {imageUrl && (
          <div className="w-full h-48 mb-4 overflow-hidden rounded-md">
            <img
              src={imageUrl || "/placeholder.svg?height=200&width=400"}
              alt={name}
              className="w-full h-full object-cover"
            />
          </div>
        )}
        <p>{description}</p>
      </CardContent>
    </Card>
  )
}
