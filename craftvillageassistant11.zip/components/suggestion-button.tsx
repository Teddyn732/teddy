"use client"

import { Button } from "@/components/ui/button"

interface SuggestionButtonProps {
  question: string
  onClick: () => void
}

export function SuggestionButton({ question, onClick }: SuggestionButtonProps) {
  return (
    <Button variant="outline" className="text-sm px-3 py-1 h-auto" onClick={onClick}>
      {question}
    </Button>
  )
}
