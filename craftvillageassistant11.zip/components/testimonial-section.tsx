import { Button } from "@/components/ui/button"
import { TestimonialCard } from "@/components/testimonial-card"
import { ScrollReveal } from "@/components/scroll-reveal"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export function TestimonialSection() {
  return (
    <section className="bg-earth-50 py-16">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <h2 className="text-3xl font-bold text-earth-900 mb-3 text-center">Câu chuyện thành công</h2>
          <p className="text-xl text-earth-700 mb-12 text-center max-w-3xl mx-auto">
            Những làng nghề đã phát triển thành công nhờ ứng dụng công nghệ AI
          </p>
        </ScrollReveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-children">
          <ScrollReveal delay={100}>
            <TestimonialCard
              name="Nguyễn Văn Minh"
              role="Nghệ nhân gốm Bát Tràng"
              quote="Nhờ có AI hỗ trợ, tôi đã xây dựng được thương hiệu riêng và bán sản phẩm gốm sứ ra thị trường quốc tế. Doanh thu tăng gấp 3 lần sau 6 tháng."
              imageSrc="/images/testimonial-1.jpg"
              craftType="Gốm sứ"
            />
          </ScrollReveal>
          <ScrollReveal delay={300}>
            <TestimonialCard
              name="Trần Thị Hương"
              role="Chủ cơ sở dệt lụa Vạn Phúc"
              quote="Trợ lý AI đã giúp tôi tối ưu hóa quy trình sản xuất, giảm 30% thời gian và tạo ra các mẫu thiết kế mới phù hợp với thị hiếu hiện đại."
              imageSrc="/images/testimonial-2.jpg"
              craftType="Dệt lụa"
            />
          </ScrollReveal>
          <ScrollReveal delay={500}>
            <TestimonialCard
              name="Lê Thanh Tùng"
              role="Nghệ nhân mây tre đan Phú Vinh"
              quote="Từ một làng nghề nhỏ, chúng tôi đã xây dựng được thương hiệu và kênh bán hàng online, đưa sản phẩm mây tre đan đến với khách hàng trên toàn quốc."
              imageSrc="/images/testimonial-3.jpg"
              craftType="Mây tre đan"
            />
          </ScrollReveal>
        </div>

        <ScrollReveal delay={600}>
          <div className="mt-12 text-center">
            <Button
              variant="outline"
              className="border-earth-600 text-earth-700 hover:bg-earth-50 transition-all hover-scale"
            >
              <Link href="/cau-chuyen" className="flex items-center">
                Xem thêm câu chuyện thành công <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
