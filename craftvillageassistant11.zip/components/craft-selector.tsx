"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface CraftSelectorProps {
  language: string
  selectedCraft?: string
  onSelect?: (craft: string) => void
}

export function CraftSelector({ language, selectedCraft, onSelect }: CraftSelectorProps) {
  const handleValueChange = (value: string) => {
    if (onSelect) {
      onSelect(value)
    }
  }

  return (
    <Select value={selectedCraft} onValueChange={handleValueChange}>
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder={language === "vi" ? "Chọn làng nghề" : "Select craft"} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="gom">{language === "vi" ? "Gốm sứ" : "Pottery"}</SelectItem>
        <SelectItem value="lua">{language === "vi" ? "Dệt lụa" : "Silk weaving"}</SelectItem>
        <SelectItem value="tranh">{language === "vi" ? "Tranh dân gian" : "Folk painting"}</SelectItem>
        <SelectItem value="tre">{language === "vi" ? "Mây tre đan" : "Bamboo weaving"}</SelectItem>
        <SelectItem value="khac">{language === "vi" ? "Khác" : "Other"}</SelectItem>
      </SelectContent>
    </Select>
  )
}
