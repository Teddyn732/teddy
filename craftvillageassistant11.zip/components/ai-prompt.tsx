"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function AIPrompt() {
  const [prompt, setPrompt] = useState("")
  const [response, setResponse] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt }),
      })

      if (!res.ok) {
        const errorData = await res.json()
        throw new Error(errorData.error || "Failed to get response")
      }

      const data = await res.json()
      setResponse(data.content)
    } catch (err: any) {
      console.error("Error:", err)
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full max-w-3xl mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Trò chuyện với Nghệ Nhân Số</CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Textarea
                  placeholder="Nhập câu hỏi của bạn..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
              {error && <div className="bg-red-50 p-3 rounded-md text-red-500 text-sm">{error}</div>}
              {response && <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap">{response}</div>}
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isLoading || !prompt.trim()}>
              {isLoading ? "Đang xử lý..." : "Gửi"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
