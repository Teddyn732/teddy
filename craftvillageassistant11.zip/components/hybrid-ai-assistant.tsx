"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ChatMessage } from "@/components/chat-message"
import {
  AlertCircle,
  Volume2,
  Send,
  RefreshCw,
  Save,
  Download,
  ImageIcon,
  Mic,
  MicOff,
  Loader2,
  FileText,
  Sparkles,
} from "lucide-react"
import { createClient } from "@supabase/supabase-js"

// Define types
type AIModel =
  | "gpt-4o"
  | "gpt-4.1"
  | "gpt-4.1-mini"
  | "o1-mini"
  | "o3-mini"
  | "claude-3-7-sonnet"
  | "claude-3-5-sonnet"
  | "deepseek-chat"
  | "deepseek-reasoner"
  | "hybrid"

type Language = "vi-VN" | "en-US" | "fr-FR" | "de-DE" | "es-ES" | "it-IT" | "ja-JP" | "ko-KR" | "zh-CN"

interface Message {
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  id?: string
  model?: AIModel
  isImage?: boolean
  isAudio?: boolean
  audioUrl?: string
}

interface Conversation {
  id: string
  title: string
  messages: Message[]
  createdAt: number
  updatedAt: number
}

// Initialize Supabase client with fallback for missing environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Add a function to check if Supabase is properly configured
const isSupabaseConfigured = () => {
  return supabaseUrl !== "" && supabaseAnonKey !== ""
}

// Mock responses for when the API is unavailable
const mockResponses = {
  vi: [
    "Xin chào! Tôi là trợ lý AI Nghệ Nhân Số. Tôi có thể giúp gì cho bạn về làng nghề truyền thống Việt Nam?",
    "Làng nghề truyền thống Việt Nam có lịch sử phát triển lâu đời, với nhiều sản phẩm thủ công mỹ nghệ nổi tiếng như gốm Bát Tràng, lụa Vạn Phúc, và tranh dân gian Đông Hồ.",
    "Để phát triển thương hiệu cho sản phẩm làng nghề, bạn cần xây dựng câu chuyện về nguồn gốc, quy trình sản xuất, và giá trị văn hóa của sản phẩm.",
    "Chụp ảnh sản phẩm đẹp là rất quan trọng khi bán hàng online. Bạn nên sử dụng ánh sáng tự nhiên, nền đơn giản, và chụp nhiều góc độ khác nhau.",
    "Bạn muốn tôi hỗ trợ gì tiếp theo không ạ?",
  ],
  en: [
    "Hello! I'm the Digital Artisan AI Assistant. How can I help you with Vietnamese traditional craft villages?",
    "Vietnamese traditional craft villages have a long history, with many famous handicraft products such as Bat Trang pottery, Van Phuc silk, and Dong Ho folk paintings.",
    "To develop a brand for craft village products, you need to build a story about the origin, production process, and cultural value of the product.",
    "Taking good product photos is very important when selling online. You should use natural light, simple backgrounds, and capture multiple angles.",
    "Is there anything else I can help you with?",
  ],
}

export default function HybridAIAssistant() {
  // State for the assistant
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Xin chào! Tôi là trợ lý AI của Làng Nghề Việt Nam. Tôi có thể giúp gì cho bạn?",
      timestamp: new Date(),
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [isFallbackMode, setIsFallbackMode] = useState(false)
  const [selectedModel, setSelectedModel] = useState<AIModel>("hybrid")
  const [language, setLanguage] = useState<Language>("vi-VN")
  const [streamingEnabled, setStreamingEnabled] = useState(true)
  const [activeTab, setActiveTab] = useState("chat")
  const [imagePrompt, setImagePrompt] = useState("")
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [textToSpeak, setTextToSpeak] = useState("")
  const [audioPlaying, setAudioPlaying] = useState(false)
  const [savedConversations, setSavedConversations] = useState<{ id: string; title: string }[]>([])
  const [conversationTitle, setConversationTitle] = useState("")
  const [systemPrompt, setSystemPrompt] = useState(
    "Bạn là trợ lý AI chuyên về làng nghề Việt Nam. Hãy cung cấp thông tin chính xác, hữu ích và chi tiết về các làng nghề, sản phẩm thủ công, kỹ thuật sản xuất, tiếp thị, xuất khẩu và phát triển bền vững cho làng nghề.",
  )
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [ocrText, setOcrText] = useState("")
  const [ocrImage, setOcrImage] = useState<File | null>(null)
  const [ocrPreview, setOcrPreview] = useState<string | null>(null)
  const [isProcessingOcr, setIsProcessingOcr] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null)

  // Function to load Puter.js script
  const loadPuterScript = () => {
    if (typeof window === "undefined" || window.puter) {
      return
    }

    const script = document.createElement("script")
    script.src = "https://js.puter.com/v2/"
    script.async = true
    script.onload = () => {
      console.log("Puter.js loaded successfully")
      setIsFallbackMode(false)
    }
    script.onerror = () => {
      console.error("Failed to load Puter.js")
      setIsFallbackMode(true)
    }
    document.body.appendChild(script)
  }

  // Load Puter.js on component mount
  useEffect(() => {
    loadPuterScript()
  }, [])

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Load saved conversations from Supabase on mount
  useEffect(() => {
    const loadSavedConversations = async () => {
      if (!isSupabaseConfigured()) {
        console.warn("Supabase not configured. Conversation saving disabled.")
        return
      }

      try {
        const { data, error } = await supabase
          .from("conversations")
          .select("id, title")
          .order("created_at", { ascending: false })

        if (error) throw error
        if (data) setSavedConversations(data)
      } catch (error) {
        console.error("Error loading saved conversations:", error)
      }
    }

    loadSavedConversations()
  }, [])

  // Function to get a random mock response
  const getMockResponse = () => {
    const responses = language === "en-US" ? mockResponses.en : mockResponses.vi
    const randomIndex = Math.floor(Math.random() * responses.length)
    return responses[randomIndex]
  }

  // Function to retry loading the script
  const handleRetryScriptLoad = () => {
    loadPuterScript()
  }

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // If we're in fallback mode or Puter.js isn't available
      if (isFallbackMode || !window.puter) {
        setTimeout(() => {
          const mockResponse = getMockResponse()
          setMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              content: mockResponse,
              timestamp: new Date(),
            },
          ])
          setIsLoading(false)
        }, 1000)
        return
      }

      // Create system prompt based on language
      const promptPrefix =
        language === "en-US"
          ? "You are an AI assistant specialized in Vietnamese traditional craft villages. Answer in English."
          : "Bạn là trợ lý AI chuyên về làng nghề truyền thống Việt Nam. Trả lời bằng tiếng Việt."

      const fullSystemPrompt = `${promptPrefix} ${systemPrompt}`

      // If using hybrid model, choose the best model based on the query
      let modelToUse = selectedModel
      if (selectedModel === "hybrid") {
        // Simple logic to choose model based on query complexity
        const wordCount = input.split(/\s+/).length
        if (wordCount > 50) {
          modelToUse = "gpt-4o" // Use more powerful model for complex queries
        } else if (input.includes("code") || input.includes("programming")) {
          modelToUse = "deepseek-reasoner" // Use DeepSeek for coding questions
        } else {
          modelToUse = "o3-mini" // Use lighter model for simple queries
        }
      }

      // Call Puter.js API
      if (streamingEnabled) {
        // Add empty assistant message that will be updated
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "",
            timestamp: new Date(),
            model: modelToUse,
          },
        ])

        const response = await window.puter.ai.chat(input, {
          model: modelToUse,
          system: fullSystemPrompt,
          stream: true,
        })

        let fullContent = ""
        for await (const part of response) {
          if (part?.text) {
            fullContent += part.text
            setMessages((prev) => {
              const newMessages = [...prev]
              newMessages[newMessages.length - 1].content = fullContent
              return newMessages
            })
          }
        }
      } else {
        const response = await window.puter.ai.chat(input, {
          model: modelToUse,
          system: fullSystemPrompt,
        })

        // Extract response text based on model
        let responseText = ""
        if (typeof response === "string") {
          responseText = response
        } else if (response && typeof response === "object") {
          if (response.message && response.message.content) {
            responseText = response.message.content
          } else if (response.content) {
            responseText = response.content
          } else {
            responseText = JSON.stringify(response)
          }
        }

        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: responseText,
            timestamp: new Date(),
            model: modelToUse,
          },
        ])
      }
    } catch (error) {
      console.error("Error sending message:", error)

      // Add error message
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Xin lỗi, đã xảy ra lỗi khi xử lý yêu cầu của bạn. Vui lòng thử lại sau.",
          timestamp: new Date(),
        },
      ])

      // Switch to fallback mode
      setIsFallbackMode(true)
    } finally {
      setIsLoading(false)
    }
  }

  const handleGenerateImage = async () => {
    if (!imagePrompt.trim()) return

    setIsLoading(true)
    setGeneratedImage(null)

    try {
      if (isFallbackMode || !window.puter) {
        throw new Error("Puter.js not available")
      }

      const imageElement = await window.puter.ai.txt2img(imagePrompt)

      if (imageElement && imageElement.src) {
        setGeneratedImage(imageElement.src)

        // Add to chat history
        setMessages((prev) => [
          ...prev,
          {
            role: "user",
            content: `Tạo hình ảnh: ${imagePrompt}`,
            timestamp: new Date(),
          },
          {
            role: "assistant",
            content: imageElement.src,
            timestamp: new Date(),
            isImage: true,
          },
        ])
      } else {
        throw new Error("Failed to generate image")
      }
    } catch (error) {
      console.error("Error generating image:", error)
      alert("Không thể tạo hình ảnh. Vui lòng thử lại sau.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleTextToSpeech = async () => {
    if (!textToSpeak.trim()) return

    setIsLoading(true)

    try {
      if (isFallbackMode || !window.puter) {
        throw new Error("Puter.js not available")
      }

      const audio = await window.puter.ai.txt2speech(textToSpeak, language)

      if (audio) {
        audioRef.current = audio
        audio.onplay = () => setAudioPlaying(true)
        audio.onended = () => setAudioPlaying(false)
        audio.play()
      } else {
        throw new Error("Failed to generate speech")
      }
    } catch (error) {
      console.error("Error with text-to-speech:", error)
      alert("Đã xảy ra lỗi khi chuyển đổi văn bản thành giọng nói. Vui lòng thử lại sau.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleStopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
      setAudioPlaying(false)
    }
  }

  const handleSaveConversation = async () => {
    if (!conversationTitle.trim()) {
      alert("Vui lòng nhập tiêu đề cho cuộc trò chuyện")
      return
    }

    if (!isSupabaseConfigured()) {
      alert("Không thể lưu cuộc trò chuyện. Cấu hình cơ sở dữ liệu chưa được thiết lập.")
      return
    }

    try {
      // Save to Supabase
      const { data, error } = await supabase
        .from("conversations")
        .insert([
          {
            title: conversationTitle,
            messages: messages,
            user_id: "anonymous", // Replace with actual user ID if you have authentication
          },
        ])
        .select()

      if (error) throw error

      if (data && data[0]) {
        // Update local state
        setSavedConversations((prev) => [{ id: data[0].id, title: conversationTitle }, ...prev])

        setConversationTitle("")
        alert("Đã lưu cuộc trò chuyện thành công!")
      }
    } catch (error) {
      console.error("Error saving conversation:", error)
      alert("Đã xảy ra lỗi khi lưu cuộc trò chuyện. Vui lòng thử lại sau.")
    }
  }

  const handleLoadConversation = async (conversationId: string) => {
    if (!isSupabaseConfigured()) {
      alert("Không thể tải cuộc trò chuyện. Cấu hình cơ sở dữ liệu chưa được thiết lập.")
      return
    }

    try {
      const { data, error } = await supabase.from("conversations").select("messages").eq("id", conversationId).single()

      if (error) throw error

      if (data && data.messages) {
        setMessages(data.messages)
      }
    } catch (error) {
      console.error("Error loading conversation:", error)
      alert("Đã xảy ra lỗi khi tải cuộc trò chuyện. Vui lòng thử lại sau.")
    }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      mediaRecorderRef.current = new MediaRecorder(stream)
      audioChunksRef.current = []

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorderRef.current.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" })

        // Stop all tracks to release microphone
        stream.getTracks().forEach((track) => track.stop())

        // Clear recording timer
        if (recordingTimerRef.current) {
          clearInterval(recordingTimerRef.current)
          recordingTimerRef.current = null
        }

        setIsLoading(true)

        try {
          if (!isFallbackMode && window.puter) {
            // Convert speech to text using Puter.js
            // Note: This is a hypothetical API that might not exist yet
            // You would need to implement your own speech-to-text solution
            // or use a different API

            // For now, we'll just add the audio to the chat
            const audioUrl = URL.createObjectURL(audioBlob)

            setMessages((prev) => [
              ...prev,
              {
                role: "user",
                content: "Audio message",
                timestamp: new Date(),
                isAudio: true,
                audioUrl: audioUrl,
              },
            ])

            // In a real implementation, you would convert audio to text
            // and then process it like a normal text message
          }
        } catch (error) {
          console.error("Error processing audio:", error)
        } finally {
          setIsLoading(false)
          setIsRecording(false)
          setRecordingTime(0)
        }
      }

      // Start recording
      mediaRecorderRef.current.start()
      setIsRecording(true)

      // Start timer
      recordingTimerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    } catch (error) {
      console.error("Error starting recording:", error)
      alert("Không thể truy cập microphone. Vui lòng kiểm tra quyền truy cập.")
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
    }
  }

  const formatRecordingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  const handleOcrImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setOcrImage(file)
      setOcrPreview(URL.createObjectURL(file))
      setOcrText("")
    }
  }

  const handleProcessOcr = async () => {
    if (!ocrImage) return

    setIsProcessingOcr(true)

    try {
      if (isFallbackMode || !window.puter) {
        throw new Error("Puter.js not available")
      }

      // Convert file to data URL
      const reader = new FileReader()
      reader.readAsDataURL(ocrImage)

      reader.onload = async () => {
        try {
          const dataUrl = reader.result as string

          // Use Puter.js OCR
          const text = await window.puter.ai.img2txt(dataUrl)
          setOcrText(text || "No text detected in image")

          // Add to chat history
          setMessages((prev) => [
            ...prev,
            {
              role: "user",
              content: "Nhận dạng văn bản từ hình ảnh",
              timestamp: new Date(),
            },
            {
              role: "assistant",
              content: text || "Không phát hiện văn bản trong hình ảnh",
              timestamp: new Date(),
            },
          ])
        } catch (error) {
          console.error("Error processing OCR:", error)
          setOcrText("Error processing image")
        } finally {
          setIsProcessingOcr(false)
        }
      }

      reader.onerror = () => {
        setOcrText("Error reading file")
        setIsProcessingOcr(false)
      }
    } catch (error) {
      console.error("Error with OCR:", error)
      setOcrText("OCR service unavailable")
      setIsProcessingOcr(false)
    }
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Trợ Lý AI Làng Nghề Việt Nam</h1>

      {isFallbackMode && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Chế độ dự phòng</AlertTitle>
          <AlertDescription>
            Không thể kết nối với dịch vụ AI đầy đủ. Trợ lý đang hoạt động ở chế độ dự phòng với chức năng hạn chế.
          </AlertDescription>
          <Button variant="outline" size="sm" className="mt-2" onClick={handleRetryScriptLoad} disabled={isLoading}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Thử kết nối lại
          </Button>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="chat">Trò chuyện</TabsTrigger>
          <TabsTrigger value="image" disabled={isFallbackMode}>
            Tạo hình ảnh
          </TabsTrigger>
          <TabsTrigger value="speech" disabled={isFallbackMode}>
            Văn bản sang giọng nói
          </TabsTrigger>
          <TabsTrigger value="ocr" disabled={isFallbackMode}>
            Nhận dạng văn bản
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Trò chuyện với Trợ lý AI</CardTitle>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="language" className="text-sm">
                      Ngôn ngữ
                    </Label>
                    <Select
                      value={language}
                      onValueChange={(value) => setLanguage(value as Language)}
                      disabled={isFallbackMode}
                    >
                      <SelectTrigger className="w-[120px]">
                        <SelectValue placeholder="Ngôn ngữ" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="vi-VN">Tiếng Việt</SelectItem>
                        <SelectItem value="en-US">English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="streaming" className="text-sm">
                      Streaming
                    </Label>
                    <Switch
                      id="streaming"
                      checked={streamingEnabled}
                      onCheckedChange={setStreamingEnabled}
                      disabled={isFallbackMode}
                    />
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Label htmlFor="model-select">Mô hình AI</Label>
                <Select
                  value={selectedModel}
                  onValueChange={(value) => setSelectedModel(value as AIModel)}
                  disabled={isFallbackMode}
                >
                  <SelectTrigger id="model-select">
                    <SelectValue placeholder="Chọn mô hình AI" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hybrid">
                      <div className="flex items-center">
                        <Sparkles className="h-4 w-4 mr-2 text-yellow-500" />
                        Hybrid (Tự động chọn mô hình tốt nhất)
                      </div>
                    </SelectItem>
                    <SelectItem value="gpt-4o">OpenAI GPT-4o</SelectItem>
                    <SelectItem value="gpt-4.1">OpenAI GPT-4.1</SelectItem>
                    <SelectItem value="o1-mini">OpenAI o1-mini</SelectItem>
                    <SelectItem value="o3-mini">OpenAI o3-mini</SelectItem>
                    <SelectItem value="claude-3-5-sonnet">Claude 3.5 Sonnet</SelectItem>
                    <SelectItem value="claude-3-7-sonnet">Claude 3.7 Sonnet</SelectItem>
                    <SelectItem value="deepseek-chat">DeepSeek Chat</SelectItem>
                    <SelectItem value="deepseek-reasoner">DeepSeek Reasoner</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="mb-4">
                <Label htmlFor="system-prompt">System Prompt</Label>
                <Textarea
                  id="system-prompt"
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                  className="h-24"
                  disabled={isFallbackMode}
                />
              </div>

              <ScrollArea className="h-[400px] border rounded-md p-4">
                <div className="space-y-4">
                  {messages.map((message, index) => (
                    <ChatMessage
                      key={index}
                      message={{
                        role: message.role,
                        content: message.content,
                      }}
                      language={language === "en-US" ? "en" : "vi"}
                    />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
            </CardContent>
            <CardFooter>
              <div className="flex w-full space-x-2">
                <Input
                  placeholder="Nhập tin nhắn của bạn..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSendMessage()
                    }
                  }}
                  disabled={isLoading || isRecording}
                  className="flex-1"
                />
                <Button
                  variant={isRecording ? "destructive" : "outline"}
                  size="icon"
                  onClick={isRecording ? stopRecording : startRecording}
                  disabled={isLoading || isFallbackMode}
                  className="transition-all"
                >
                  {isRecording ? (
                    <>
                      <MicOff className="h-4 w-4" />
                      <span className="sr-only">Stop Recording</span>
                    </>
                  ) : (
                    <>
                      <Mic className="h-4 w-4" />
                      <span className="sr-only">Start Recording</span>
                    </>
                  )}
                </Button>
                <Button onClick={handleSendMessage} disabled={isLoading || !input.trim() || isRecording}>
                  {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
                  Gửi
                </Button>
              </div>
              {isRecording && (
                <div className="mt-2 text-center w-full">
                  <Badge variant="outline" className="animate-pulse">
                    Đang ghi âm... {formatRecordingTime(recordingTime)}
                  </Badge>
                </div>
              )}
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Lưu và tải cuộc trò chuyện</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2 mb-4">
                <Input
                  placeholder="Tiêu đề cuộc trò chuyện"
                  value={conversationTitle}
                  onChange={(e) => setConversationTitle(e.target.value)}
                  disabled={isLoading}
                />
                <Button onClick={handleSaveConversation} disabled={isLoading || !conversationTitle.trim()}>
                  <Save className="h-4 w-4 mr-2" />
                  Lưu
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium mb-2">Cuộc trò chuyện đã lưu:</h3>
                {savedConversations.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Chưa có cuộc trò chuyện nào được lưu</p>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {savedConversations.map((convo) => (
                      <Button
                        key={convo.id}
                        variant="outline"
                        onClick={() => handleLoadConversation(convo.id)}
                        disabled={isLoading}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        {convo.title}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="image">
          <Card>
            <CardHeader>
              <CardTitle>Tạo hình ảnh với AI</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="image-prompt">Mô tả hình ảnh</Label>
                  <Textarea
                    id="image-prompt"
                    placeholder="Mô tả chi tiết hình ảnh bạn muốn tạo..."
                    value={imagePrompt}
                    onChange={(e) => setImagePrompt(e.target.value)}
                    className="h-24"
                    disabled={isLoading}
                  />
                </div>

                <Button onClick={handleGenerateImage} disabled={isLoading || !imagePrompt.trim()} className="w-full">
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <ImageIcon className="h-4 w-4 mr-2" />
                  )}
                  {isLoading ? "Đang tạo hình ảnh..." : "Tạo hình ảnh"}
                </Button>

                {generatedImage && (
                  <div className="mt-4">
                    <h3 className="text-lg font-medium mb-2">Hình ảnh đã tạo:</h3>
                    <div className="border rounded-md overflow-hidden">
                      <img src={generatedImage || "/placeholder.svg"} alt="Generated" className="w-full h-auto" />
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="speech">
          <Card>
            <CardHeader>
              <CardTitle>Chuyển văn bản thành giọng nói</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="language-select">Ngôn ngữ</Label>
                  <Select value={language} onValueChange={(value) => setLanguage(value as Language)}>
                    <SelectTrigger id="language-select">
                      <SelectValue placeholder="Chọn ngôn ngữ" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vi-VN">Tiếng Việt</SelectItem>
                      <SelectItem value="en-US">English (US)</SelectItem>
                      <SelectItem value="fr-FR">Français</SelectItem>
                      <SelectItem value="de-DE">Deutsch</SelectItem>
                      <SelectItem value="es-ES">Español</SelectItem>
                      <SelectItem value="it-IT">Italiano</SelectItem>
                      <SelectItem value="ja-JP">日本語</SelectItem>
                      <SelectItem value="ko-KR">한국어</SelectItem>
                      <SelectItem value="zh-CN">中文</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="text-to-speak">Văn bản</Label>
                  <Textarea
                    id="text-to-speak"
                    placeholder="Nhập văn bản bạn muốn chuyển thành giọng nói..."
                    value={textToSpeak}
                    onChange={(e) => setTextToSpeak(e.target.value)}
                    className="h-24"
                    disabled={isLoading || audioPlaying}
                  />
                </div>

                <div className="flex space-x-2">
                  <Button
                    onClick={handleTextToSpeech}
                    disabled={isLoading || !textToSpeak.trim() || audioPlaying}
                    className="flex-1"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Volume2 className="h-4 w-4 mr-2" />
                    )}
                    {isLoading ? "Đang xử lý..." : "Phát giọng nói"}
                  </Button>

                  {audioPlaying && (
                    <Button variant="outline" onClick={handleStopAudio}>
                      Dừng
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ocr">
          <Card>
            <CardHeader>
              <CardTitle>Nhận dạng văn bản từ hình ảnh (OCR)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="ocr-image">Tải lên hình ảnh</Label>
                  <Input
                    id="ocr-image"
                    type="file"
                    accept="image/*"
                    onChange={handleOcrImageChange}
                    disabled={isProcessingOcr}
                    className="mt-1"
                  />
                </div>

                {ocrPreview && (
                  <div>
                    <Label>Xem trước hình ảnh</Label>
                    <div className="mt-1 border rounded-md overflow-hidden">
                      <img
                        src={ocrPreview || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-[300px] max-w-full mx-auto"
                      />
                    </div>
                  </div>
                )}

                <Button onClick={handleProcessOcr} disabled={isProcessingOcr || !ocrImage} className="w-full">
                  {isProcessingOcr ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <FileText className="h-4 w-4 mr-2" />
                  )}
                  {isProcessingOcr ? "Đang xử lý..." : "Nhận dạng văn bản"}
                </Button>

                {ocrText && (
                  <div>
                    <Label>Văn bản đã nhận dạng</Label>
                    <div className="mt-1 p-3 border rounded-md bg-muted">
                      <pre className="whitespace-pre-wrap">{ocrText}</pre>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
